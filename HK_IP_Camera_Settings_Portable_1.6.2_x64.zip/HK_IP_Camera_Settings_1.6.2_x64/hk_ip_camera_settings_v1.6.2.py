#!/usr/bin/env python3
"""
HK's IP Camera Settings - find, inspect, snapshot and manage Dahua IP cameras
=============================================================================

How devices are discovered
--------------------------
1. The tool lists every network adapter of this PC (name, IPv4 address, subnet mask)
   and works out the address range each adapter can reach.
2. Only those ranges are scanned for Dahua HTTP-API devices.
3. After login, each device is verified: it must be a DAHUA device AND an IP CAMERA
   (device class IPC / dome / PTZ / thermal). NVRs, DVRs, door stations, other brands
   and anything that cannot be verified are NOT written to the "Cameras" sheet; they are
   listed on the "Scan Info" sheet with the reason, so nothing disappears silently.

Version history
---------------
1.5.0  More detailed logs (every failed request with the camera's reply, session id, system info, crash log,
       optional full request trace, one-click diagnostic bundle); edit a camera's name and device name; bulk
       stream settings (resolution, FPS, bitrate, codec, CBR/VBR, GOP for main and sub streams) with
       capability check, preview, read-back verification and undo.
1.6.2  SNMP v3 column: "No" when the camera has no SNMP section (it answers "Bad Request"), "Unknown" only when
       it does not answer at all.
1.6.1  Start IP / End IP are read-only table columns; new column "SNMP v3" (Yes / No / Unknown = does the camera
       offer SNMP v3; not whether it is enabled).
1.6.0  New look: network adapters full width with evenly spaced columns and editable Start IP / End IP, one-line
       login row with grouped buttons (only Scan + Fetch is highlighted), larger entry fields and rows,
       filter box above the device table, collapsible log.
1.5.1  Layout: Network adapters and Scan & login side by side, Notes column removed, bigger device table,
       Status and Web columns moved to the end, Extra ranges / Ports moved to Settings; Sync PC Time can
       also set the camera's time zone to the PC's (option next to the button).
1.4.3  Fix: Excel export / snapshot folder no longer stop when Windows cannot open its file dialog
       ("Unspecified error") - Tk's own dialog is used, then a default folder; Sync PC Time now checks the
       camera's reply strictly, reads the clock back several times and retries once, and reports the
       real reason when a camera keeps its old time; system info added to the log.
1.4.2  Packaging: native 64-bit HK_IP_Camera_Settings.exe launcher (own name and icon in Task Manager),
       64-bit installer, portable x64 package. Application logic unchanged from 1.4.1.
1.4.1  ITC (traffic / ANPR) cameras are now accepted as IP cameras; "Sync PC Time" now verifies the
       result and explains cameras that keep a wrong time (usually NTP enabled on the camera);
       whole-second rounding bias removed from the clock difference; new fields Time Zone,
       NTP Enabled, NTP Server, NTP Tolerance.
1.4.0  Renamed "HK's IP Camera Settings"; persistent log file (daily, 90 days) + settings file;
       live device date/time with difference to the PC clock (re-read every minute); "Sync PC Time"
       for all ticked cameras; Settings page (choose visible fields, Excel scope, snapshot folder);
       "Open" button in every device row; modern hover scrollbars; animated dark mode; idle
       progress bar hidden; Windows .exe build kit (portable + installer).
1.3.0  Modern app logo; unified tick boxes (adapters, table, options); every column can be
       resized (Status no longer locked); "Open Web Interface" button (also double-click /
       right-click a row); "Take Snapshot" for ticked cameras - JPEG with the camera name in the
       bottom-right corner, named "YYYY-MM-DD HHMMSS <serial>.jpg"; CLI --snapshot-dir.
1.2.0  GUI redesign: centered table, tick boxes with Select all / Deselect all, Status column
       first, both found cameras always listed (failed ones in red with the reason), HTTP 403
       reported as probable account lockout, lockout guard (rejected credentials are not retried),
       centered Excel cells, version shown in title / CLI / Excel.
1.1.0  Discovery by network adapter ranges; output limited to verified Dahua IP cameras
       (device class + vendor check); excluded devices listed on the "Scan Info" sheet.
1.0.0  First release: network scan, one-shot login, stream / WDR / firmware details, Excel export.

Install:    pip install requests openpyxl psutil pillow
GUI:        python hk_ip_camera_settings.py
CLI:        python hk_ip_camera_settings.py --user admin --out cameras.xlsx
            python hk_ip_camera_settings.py --list-adapters
            python hk_ip_camera_settings.py --user admin --snapshot-dir C:\\Snapshots
            (password is prompted, or set env DAHUA_PASSWORD)

ACCOUNT LOCKOUT: Dahua devices lock an account after several wrong passwords. This tool
makes exactly ONE login attempt per device and never retries a rejected password.

Based on: "API of HTTP Protocol Specification V4.04" (Dahua).
"""

import argparse
import getpass
import ipaddress
import faulthandler
import json
import logging
import logging.handlers
import os
import queue
import re
import socket
import sys
import platform
import threading
import time
import uuid
import zipfile
from collections import Counter
from concurrent.futures import ThreadPoolExecutor, as_completed
from dataclasses import dataclass, field
from datetime import datetime, timedelta
from urllib.parse import quote

import requests
from requests.auth import HTTPBasicAuth, HTTPDigestAuth

try:
    requests.packages.urllib3.disable_warnings()  # cameras use self-signed certs
except Exception:
    pass

try:    # Dahua cameras expect key names such as Encode[0].MainFormat[0] with LITERAL brackets (as in the spec);
    # urllib3 would otherwise rewrite them as %5B0%5D.
    import urllib3.connectionpool as _urlcp
    _orig_encode_target = _urlcp._encode_target
    _urlcp._encode_target = lambda target: _orig_encode_target(target).replace("%5B", "[").replace("%5D", "]")
except Exception:
    pass

__version__ = "1.6.2"
APP_NAME = "HK's IP Camera Settings"
APP_SLUG = "HK_IP_Camera_Settings"

DEFAULT_PORTS = "80,8080,443"
HTTPS_PORTS = {443, 8443}
MAX_HOSTS = 65536
MAX_ADAPTER_HOSTS = 4096          # larger adapter networks are narrowed to the /24 around the PC

# --------------------------------------------------------------------------- #
# Excel column layout
# --------------------------------------------------------------------------- #
STREAM_FIELDS = ["Resolution", "FPS", "Bitrate (kbps)", "Codec", "Bitrate Mode", "GOP", "Profile"]
STREAM_NAMES = ["Main", "Sub1", "Sub2", "Sub3"]

COLUMNS = (
    ["IP Address", "Port", "Network Adapter", "Channel", "Camera Name", "Device Name", "Model",
     "Device Class", "Serial Number", "Firmware Version", "Build Date", "Hardware Version",
     "MAC Address", "DHCP", "Subnet Mask", "Gateway"]
    + [f"{s} {f}" for s in STREAM_NAMES for f in STREAM_FIELDS]
    + ["Smart Codec (Main)", "WDR Mode (Day)", "WDR % (Day)", "WDR Mode (Night)",
       "WDR % (Night)", "Day/Night Mode", "Exposure Mode", "Anti-Flicker",
       "Brightness", "Contrast", "Saturation", "Device Time", "Time Diff vs PC (s)", "Time Zone", "NTP Enabled", "NTP Server", "NTP Tolerance (s)",
       "ONVIF Version", "SNMP v3",
       "Vendor", "Status"]
)

EXPOSURE_MODES = {"0": "Auto", "1": "Low noise", "2": "Anti-smear", "4": "Manual (range)",
                  "5": "Aperture priority", "6": "Manual (fixed)", "7": "Gain priority",
                  "8": "Shutter priority", "9": "Flash light matching"}
ANTI_FLICKER = {"0": "Outdoor", "1": "50 Hz", "2": "60 Hz"}

# App logo (128x128 PNG) - used for the window icon and header
LOGO_PNG_B64 = (
    "iVBORw0KGgoAAAANSUhEUgAAAIAAAACACAYAAADDPmHLAABNLklEQVR42u29d5xc1Xk3/n3OOffeqdu1q15ADUlISKIIGRBgOsYO"
    "xOAWd2Mb24ljJ3HLayNi/2LHceISN0yMgwvGgAu2wYANRoDpSBQh1Lu02tX26ffec57fH/dO3dndWVGS93Xm87na0cycmXPP0zvh"
    "5XkQsE4CG/zyS+tUZE7rKWT85YLEKjCvZHATkVgEcLCkuJRQ/X8ARNX/L38OY66l4uuNrKWaNWPso/xdE++NhGAv49LcC07uPu8b"
    "12xOH8nYQgkGAUJKLn6LEJL7t+2Lb7ttw4zuJ7d1ZHtHIiQIKmqDga1gpEByExnaCOC5wfb4k9hwXfls112rsGG9BoiroMBMIOIP"
    "dnOngfdmYtPCEjkYCCIoBvUUuuwf30SUZ2YiIqaXFfDzL3KiWXUBJN5AwKkAlhEpIgpAHmzSVBxcfWBRFSBqgUMVH69YU/e7al+r"
    "BX49QI+/luogROn7QgRY+o4Ldr/muqt2+FlIocB+HsLPucL4mkCAIMkqZhuhwOkjw/auOx/v3HvvU9OGdnU3M0uoqA0iARgGG80Q"
    "tBmgJ5jFHUPZ7L3Y+R+FsRGBCSB+z1FOKt99I4B5DE4zQJLgMNG+Qvbwz26aNy9AgmOH/TpVBHy887IuY5lrSNCbieQikAgAzRoA"
    "DEAcwIiofFqjKY2qDraWIutTKY1BpcFrtb9RSfNjUHgtohWpexzOU/td0rb9WGdrtml2Z6ZzxfFDnSfNH2ldMDMbabM940K4aVca"
    "1yeAoGK2sZNS+wXQvj9sat9y8wOz+p7f0w5mUlFHA5AgBZAKidzfBsYtrhbfyWz+Yk8ZEcocokjdf83suD3+JYbNCgjOwgBCUMwY"
    "7Hfzh2++ad68PB0b1Qe/E+86v9Mo+0Mg+qCQqisEugHIABABGo/FUivAPQ6wxgd8LRDGRxoa7/vHWEsNiYWatYZhtAHrQNSpqM3x"
    "ztZs5+oF/bPOOenotNULR2JttufmIN1UThrfkLAER1qiPhjYc8+m9i23bJjT9/zeNiKCdCzNhhlgQcIWEBbYuD0g+q6t3W/3PPdv"
    "vQHlAyVuEIoDALi617uY2KxhwxkSYDYUJ4E98YJ96yQR4EoJ3KYBIDbz0vcA+DxJezqzD2L2AQiABBo8NGqAwmvXUl1gja8fUAMU"
    "Pr4YqkWa+mtLCEYEIuLi59kwGd/A+BrCUkhM78h0rZrff9ylpx2Zvnr+iLDB+SFX+XlPCCU40hr1AeDFWx6e+uJPHpg3cqg/riIW"
    "SBAHiECGhFQkHRjfPUyEzw5s+ucbAxDdKnHbVbqIBNeuB113HZmre/MXE9MaNpwBAEGIgOkQTRb40VnnTQciNwqhLmTWIDY+QLLM"
    "wyc+NJpAmau3lhpUBCs/U63gTSTjx9M/xl9LdfdRs5aIiQjMIONpGN9AORa3L5kzOP8Naw/OPufEgVhH1MsPusovBIgQa416+ZSn"
    "Nn7rt3N3/PLRuawNqYjFbJgAMBgaUimSDth37yEU3tO/6V8PVyEBmJgBIuISEoAzbEBgWDQZeR+beemFDPqBkGoaG8+nuoAf+9DG"
    "1uzHXkvjAGssdk91FL7xxVAtUja2tj5Sjq9bUA0yaNcHG6Bp1pTMgstfs3/xla854iRtPzuQs1gbko5lIh22d3DDjtYnv3rHoqEd"
    "R5qsmM1MoFCzZjA0qahi9ruZ/XcPbvzne6r1gmokgKbTAM5SzS7HeFwrgOtMbPalVwPqewQDsNGAkHUpfBJm03iHNimTrsh2J6Lw"
    "Mfc2gf5RF/DjK5rjmpyVnC0UFdo1pD2NtkUzRpa/58Jd8y5Y3m98kDuSkwAQaYv6fkGLx754+4Lddz09S1gSQsmAGxABzBrCkiQU"
    "SHvv79v4TzcUYVdEgmuvDcTBB47kL2emlRCcogZMPB2b/brPEcR6sDHhDYlRwKtz4DQm6xz70GiSZtkxm3RUrR006gegBq2T+nur"
    "s5YqzooE64JPzIwZpy/uWXnNpbunrJieyve5lvE1CVtypM32Xrz5sekbv/27xV7WVSpqMeuiAsiGSIKEEmB/fd9T//RPWHetxIbr"
    "dMApgs+9c+9ex4lMfwszz6KJ2H501qXrpYxeyzofyPoqQ3gSLPW/w6QbYy3R5PSP0i9NUnehSTixSr8jAvHgZT2y4o6/9G1n7z7x"
    "fefvNz7IzwbcIDYl6vVtORJ/6LM/PXFoZ2/STtjMzOEXMoNJC6dZGXfouv6nP7++ShyE1sFfdXfH49T6PhpP4YvNuPRqkup7YOOB"
    "oCo0mj8bk44mpX/UehcbX1vLLUkSs2by8z46T5o38JrPvWVL03GtuXxfzoIJREK2Z8Te8I83L+vbfKBNRS1mUzbRQeSTsC347vv7"
    "Nq6/odY6ABG//xB30FjAj0+77HzY6l6wb8p39+do0jWuu5CgQDpyoJkFStr4a8fzLBbNST/nk9OWcE/52Ou3zH/D8t6iSFAR26iY"
    "1A984uZl++57YZqdtKuRAIJJOcJ46QsGnv7876utg+Aha6AvgC0mPu+yLgbdS4R4cBdClG6gROEU+nrqHHDJ4UfVVEVUYo0EUYFT"
    "NAZQy3hHVUAJ10JUH1rN2mBvNMbe6q+lkpyn0eKDyvddfU8BIHXeg5vOB74wISCUBAlZsYfy2uDra7lW7bkF3yxtxTrnqf1/3Dw1"
    "35cTM886oZ8Nk3Z9YTwWx7/upCPDu3tj/dt6kspRDAaBBKEo9ElemJz12h9l7r0mFSiGG0rOohoEuFIAV5LVdOQXQlrLwzuR5RsV"
    "VZhLdYE19oFTpZxvaC3KyFIF+BpqqUG2+nsbf2014BtbW0JlEjCuxrJ3XYCZZyyFsBT8rIvCSBZ+tgAwIC0FksWjpDHuvRYZwvtm"
    "kJACUknueXpv68j+vsjxl67oAYtqJNjVG+vfHiIBiIiIwMYIK5pk7a/IHj7zJ7hyKWHLbQECXHddJQcI5f6spncIGfk7Np4PEqoW"
    "I6upimqkQ/1Dqwb8eGvLFE5UAfi6WjzVtTpoHCqth2z19zbxWqr8PwBSEms+eRXmX7YCs89ZjXkXnowZpy9GvKsVXraAbO8w/KwL"
    "aVsgJTEWR609D0IVFyMVsXhwR0/T4cd2ts56zQl9Tkvc97OuMD6L4y9dcWRoV29saNfRpLIlgynETt8XVmKBM9Xfk/v9hzbhyltl"
    "EQkq7u5aSk5/ttVIbIagzlCAif816SYw6YjAnka0oxkX3fgxqIgdgNKxoBwFkoCXdtHzzG7suXsjDmzYjMJwFioegbStgMnWM6HH"
    "c3RJwV7Ko5YFXanzvv7ujZGWuO+mc1IoyXbS9u+++vsnH33uYKuVsEOvIZkgmGR6Cya+LPVk3yCwngFiWab+bxurZcEnSUVeB9Y6"
    "dO/W0VBr2FPloVVgM41BpdVrqymNqhTDxtYS1XH5jqN/IBQpVJfzjL22zCuqqZSEgJfzMGXZXCx7xxkQygJJBeNp+LkC/JwPEgIt"
    "x3Vh9mtPxKwzliLa3oThPb3I9Y1ARmyQlCWFsUTxdbhiSQwzSEYszvamnMNP7GiffeaSXisR0dr1BSBo5tpFfd1P7WrL9WUcaUkG"
    "SICNFla8SXAmlzv02T/iyqUSW27jkBdt4cS013Wwsn4IcLR4umOy1HEOjYpadxXwxLhIUz7cemy3/tqyElUjTlAHWYvIUnK4NK67"
    "UKi7jKVoAgShBLx0HgM7e1EYTEMoAac5BqclCmFZML6Gny1AFzRiU5ow4/T5mH32cvgFD4O7jsDLurAiTg0HnUDvYZByFGeOpJy+"
    "LQeaFl6x+pDxWWjXF9GOuDflxLmDe/+weZrxjSAhCAAxGxCJE0XXhTe6f7g6CzDJwOGzz9gdS/6BhHMJ2DdEQtAEFF574FVKFMSY"
    "Mq1WjtKo7x9/bX0dZHxZWuIsk9BdqFaEjbOWSEAXPPQ9tw8HNmwOWf0LSB0cgFAKsSlNcFojgAH8nAs/78NpimLe+Seia+V8ZLuH"
    "MLynF9JWICHLCVNj6h/h3hikIorTh4ejgzt7Y/MuWN7DhslNFVTLvJacFY0WDv5pZ5dQkomIiKGlFU9YlM9mDv7hAayDksA+njnz"
    "ymiW+HoitFRna/z5mXT1xRCNYXWU1wopoKIOVMQBGMj1jeDI07uw555NOPzoNhRG8khOb0d8agJsCLrgwc9pNM1sx3GXroKdjKL7"
    "8Z0wnoZ0rAofQr29VXBFBklb8sDWnqSXzoq55y8+6ud86WV9Oe202UMjBwadga1HmmWoFIZO4zltMy+6YeRPn/EkAHDr4guEtD8S"
    "ZDCESRx/piZdQ2ZZjRgqreOykiotBRV1IJREpncYBx9+Efv/uBluykXL3E7EOhKBnlDwwNpg2qnHofOk43D0uX3I9gxDRZ0K5VDU"
    "1T8qZYZyFPe90N2amNqemnLi9JSf86UusJh15uK+gw9t68wNZB1pSYIxTFa0zdP6keyhe3dIAHBalnwCUq2EMQaiMqHjz8ykw8Rm"
    "WUXCxwRiqKy9S9uCFY3Ay7o4/Og27LvveZCS6FwxF8JS0AUfOu+jeU4H5rz2RAzv6cXQrt4gN5DRGKERETOh95l9bTNfs6jXaY17"
    "uuAJFbNNclZ7av8DW6eH64yQDoG9XPbgvb+RmPPOiEXuF0DUGWQTEdX1dNVlp/VYthglS8em8PoKX8P6R1WItjHrpK4sHW9tzboy"
    "xTcmhgAChfkbJAVUzIGfc3Fgw4s4+vx+tB7fhaa5bdAFDT/vQ0VtzL90FXJ9afRs3As7HgHzaMVztDIKCEuyl3bVwPbDyYWXrTzs"
    "u0bogifaT5iSyfVm1NHnD7dKRzGDBLOJZI9fc6OMti1cJUh8MswmFX/OJt14a6kq0aQxEVbXpOPAaWRFHQzt6cW++zbDaYqjc/ls"
    "sDFgT8NogznnLEF+MIsjG/fAikXKOkEdhCtxSyaStuTUoZEoCHrWWcf1e9lAFEw/Zd7gvj9unVpIFWwhwESy3fGs30q7ZemlQqrX"
    "gw2HKP7na9LVWVsWReOIMNQCvnZvo/UeZkBFbRjN2HffZhSGspixdiFICLBfgQQDGfRs3Acr5tRNZqHRYoeEEtz3YnfL1FXH9yWm"
    "trhepiCd1ogPIr/7sX2dQpEhaUtBeErarUs/TKRWAoGR+Odu0pUpXoz2fk5kDpb2JhrTPxgQQsCK2OjZtBe9z+zH7LMWQ8UdmEIl"
    "J8jg6HMHoaJ2wEFGnVuNEiwFvJwW2Z6RyHEXL+nWrhF+Xsupq2YNH358T3vmyEhUOhFi7fdJp23pP4LEDAQhJPpzN+kajtJV7U2U"
    "AV83DY3GMemCz1nxCIb3HkXvcwcw++wlUDEbpigOzj4BfS8cwtCuo7BidsA+xtNdAJKW5JEDQ/Gm2W2pjqVTU17aVVbM0ipieQce"
    "2jVNWAow2pdW64l/J0h0UImn/HmbdJOK0pUA35hlM55Jx4ZhxRykDgyg97n9mH32YsiIDfY1ghSxBTj0yA4UBrMQljVGok3FuYXe"
    "wpF9A/G55y/tFlLAy/mybdHUdPdTe1uyR7JRUiIlI23L/6MiKe1/TbpJRekwjpI6Wu+huokm5f0zA1bMxsj+AfRtOYzjL1kBMGA8"
    "A6clhrb5U7Hn9y8EoX4am0hDpCRhSc72ZBw7YRdmrJk9WBhxlZ2wtIo43sGHd04VSkyRTtuJ6//fMumqLYwi8gXZOhWy/VhNupJm"
    "T2PsbbTeQzVFI3WRJnzOBrBiDkb29cEdyWP22YthPA1d8NEyrx3SsXDw4R1QEbtO7UR43tXfT5kjI7HZ5yw5Ii3JXs6XHYu6Mgce"
    "2tmZ7cva0mlbvv7/BZNOCAkhCFKKKo7jaQPDgDEMY4K/zIClJIgEhChe4+kHDUbpapBmtCjChHpPwLoZKmKjZ9N+xLua0bliJvyc"
    "D+1pdJ00G0c3H8bIvv6Sy7i+tRbINGER5wfydtOs5tSUE6eNuGlXWc2Wdkc86tl4cIp02pev/7/LpAv2IUhAygDozECu4COX95HO"
    "unA9A08zSAi0t8Q56liIRmxEoxbiURsRW2E4VaCCp5HJecgVfLh+4MdVSkIqCUE1ia6NRumqzm18jjquSUcEaSsceWovpq6ah3hX"
    "E7TrQ1gSTbPasPe+rXW40WgiJRCMBhWGc/a8C5d2G98XxheUnNGc2//A9mnq/5rEyzDpUggBYkLe9ZAvFMAAmhJRLFs4Xc+c1qpP"
    "WDDVX3Rcl5k9vU3HojYvOq5TG81V5WK+MdiyvVsZZmzZ2aN27e0X2/b0qn2Hh+TeQ4MilypASYFoxIZjy5CDoIHCj8ZS2RuqnWCA"
    "lIKbymPTdx/Aa//9TSAp4WVddK6YgXnnLcGOXz8LpyUWFqHWP28GSDqSB3ccbel95lBT54oZI4WRrBWbknC7TprVS8n5b+e65dn/"
    "3bV0NYCXUsD3DNJZFwBw/JwOs3LJbO+is5e6a1bO8xcd3xUUP4xdzVz7GPXZXN4TW3b2yA2P77Luf3Sn/fy2bnWoJ0W2pZCI2yBB"
    "0JrHqU2YXIZRI+XwQgkURvI4+W/Px+I3rkZhOA/pKBQGM7j3wz+Fm8qHKWZjn7cQxF5W0/EXLz5w+j+e92LmSNZxkhG/b2tPgpIL"
    "3s7/I2vpioAXAgVXI5UuoKMtjrPWLHT/8sKTCpdftLIQjViVQCStDQxzyXqgUhGTqU58RqAXBB45LokgKUUVYhw5mpK3/OYZ57cP"
    "bLUfe2a/VfA0mhMRSCmgwy+oTm1vrGiEGuCopbVEYN/ATkZw0fVvh90UhS74iLRF8Nx/Popnv/9wNReoUztBBGifEZ+azF747Tc9"
    "HhaQAIJYRtpXrv+faNIpJaF9xuBwDjOmtpgPvvWs/NfWX5X+8DvW5U5cPMO3lCRfazKGiRkkBAVKYKjUBbURgGEDZlRcwUGJ0Ceh"
    "pCwpgYGSaMgYQ8ygpkSE16yc473j8tX5tSvn+oII2/b2qcGRAmIRG1IQSgU5Dbij65rQE6wlEIQtke/PwE44mH7aXPj5oBI/0hbD"
    "3vu2I8DmsbyyYdaSFFxIuXbb4imDbcd1ZL28L4kA6bSftP5/kkknpIAggcHhHFqao/ypay7K3fClt6cuO+/E/JS2BPt+AHRAQMoy"
    "sI0x0MaAjQn0hPDAhRBc1vTLF4VZ01obGKNhjAHAoWJZRAgDXxsCQMfNatOvP2+J+4bXLnELrqZNW7pV3jOIRhS4Sqsf7ayiCU1o"
    "GsPcFBUAlBjeP4hZZy2ElXCgCx4SU5swsm8Q/S8egYoVQ8f1nWQkCNo1ZEUsb/bZ8456GU+SEJBOx8o6foD/HpPOkhL5vIds3seb"
    "33By4eZvvHfk9ectz0cjFnmeJgCkVAAgZkBrH8aYItC4TP2gwcEhymSz9OTTz1q79+yTe/cdlHv3HZC79uyTff2DIh6Pcz7vUiwW"
    "qUIQAOT5PsABMkghIIjga0PaGOpsT5jXnbu4cOYp8/ytu46qbXsGhGMrKCXDsG1NlG6coFE9d3R9kw4QtkKuL41YZxJTV8+Cn/Ug"
    "bQXpKOx/YAeklONz4/BNL+tac85d1C2EAAyg6mutr3ItHRGUEOgfymLJgmn6q597Y/q8M05wAcD1tFCSYFmBomOMgdYGlqUghGIA"
    "yOXyYvML29RjT21Szz//onrhxe3qwIHDkgEcPdpPxpgKl6uBE3HQ3trCQgrMP26uv2zpIv+k5Uv8005Z5S9edLy2lDIAKBQHEEpB"
    "BfoBtDZkmOmM1XPcDT95n3f9T5+MXPvN++OpjEdNCQe+b+qUqjdYDj/OeTMzZMTC/gd2YMEbVkBYEn7OQ+eJ09E6rwNDFX6BsWAl"
    "FCHXn40O7e6PTVkyLe1lClI1DviXv5YOACQJGGb0DWXx5tefXLjhS29Lx6OO8X1NRAS7LuAF+75Pd9+7wbnjt/fYDz78uH3w8BGR"
    "zWQBItiWBcu2QABiseho9Z8N+geGCGAcPNht/eH+hywiQnNTEvPmzdYXnneW+4bXXVhYc9oqr5IrWEpBSgEJwPcNCSHwgbeckj3r"
    "1Lneuz/9q+TGF46o9pYITKhvvKTaidrzNoCK2Bjc1YeBbT2YsnwGvFQBkdYopp46B/07jkJFRZjVVx9WQhD7OUP9W3qap500bcRN"
    "GymdjlXr64dnX/konRISrh9o5F/+9BWZL3/6irRtKXi+JkvJ0DsH+L4fsGMpzMDgkPjK166PffTvr038x3d+EN246XmVzeXJsW3E"
    "YzFEoxFYllVi6cw86gIQfp+E4ziIx6KIRCMwzOju6RUbHnzMuvlnd0Tu/cMGmwg4acVSLYVgAOT7fklHIAJcT9PUjoR5z1+uLBzp"
    "T4vHnjmsHFuBhKjPBSdMtBnrvAP9yM96iLbHMf20OfBzPoStwIax/4GdkMWKo5q1VOGV1D5IRZQ/+5zje92Mp6TTsXo9/huidFIK"
    "ZAsemhIRvuumDw9fcdHKvNZGMBhKBlTva10EJA8ODouvfO278fd/+FPJO359tz2SyohkMoFoNAIZAtrUAHlU0kZtQ4uQtZqKNbZt"
    "Ix6PQgiB3Xv2y1/++m7njt/c40QjEV6xfIkOuI8uBU+lFPB9Q1IKXHr2wsLUjgT/+o/bbUtJCBLgCWsnJg5WVZ43geDnPMw5dxFI"
    "BrqQFbGwf8POoAhFisrK4qosJioaR1Jg4RVLDkglISNTVq2nVzlKJ5VEruCjKRHlu2/6yPDqE+d4rucLq8IF63keLKUYAH37+pui"
    "b3vXXzfd8dt7ba0NNTUloJSEMaYOsEWFtUIANJhN6AsIroDLyVLiR8kuLiJEaOM7joNoNIrDR3rE7b+8y7njt/c48+bO1gvnz9NE"
    "VMUNAhHFdPKJ090ZXUn+5R922JYtg8hdbZ1fAzkTY5l0pATclIsZa49DtD0OnffhJB0c2XgIqYNDQe0h6vRJopIPHbrgy55nupt3"
    "/PrFmTLScfL6VyVKF/5fKolc3kcyHuG7b/rI8IolMz3X88m2VIWs17Asy2x5cbv1+je+t/l73/9JRDNTUzIJIgoBX+n0CvbD7IO5"
    "AGNyIeB9CBGDFDGQsCGEAykjYPZhTA7MLozJh0ghQSRHIQMzl7jC4e4e8eObfx7ZvmOXuvD8s71IxGHP86kYgBKC4PmaVi8tI4Fj"
    "KYhiu8RJZBhVx2EqsrKlgJt20XFCFzqWdsF4BrEpFtKHMuh+8kCYMIKx8x4EgTVE6mA6nuvPRdWr2R5FCoFszgsp/8Mh8HUJ+Frr"
    "kkl3049vi37sE/+USKXS1N7eBq01fN8f1VWD2YfWWQACSrXBicxGJDIPTmQuhIhC2Z0QMhq2qAWIJHxvANofge8PopDfi3xuN1z3"
    "MLQ/DJCAEBFQ0FGxhJTGALFoFBQj/OSWXzkbN21W//WfX0udevIKz/d16IgSsJSE52vxrstXZAHgw5+/N5GI2eH3YYKC14k6n5Tv"
    "++jz3Zhz7nyMHBjCkY1pDGw/CitqVTiFxoEVEVQk9Bo0n/ABfjXaowgiuL5BMu7wb3/woeGVJeCH8t7XUIFPmz/8t/+Y/Pb1P4wk"
    "mxKwlAWtdQ3gBYxxwSYPqVoQT6xCMnkqnNjxkFYLSNoADJiCVnqMqrYZIMjAT8EEMMHoPLTbh1xmK1IjjyKX3QJj8hAyVoUIxYdS"
    "CplMFkSEr39lffrq97w1Z4whAEVfAjxfw1LS/Ncvn4199J/vS0QjVk3wgRoIwNV3qTMzlGPBilsoDBfgpV0IJSAj1mhYTdCVRUam"
    "nLL+VUm8FISCp3H7t983snbVca7r+aJI+b7vQynF2WxOnHfpW5tv/8VdTltbSxDKNKaG1RtonYJSbWjteD06p70XzW3nworNBFkK"
    "RvgwwoWRPlj6YBGIew4vSICFBgsfRngw5AICEFYSkfgCJJvXIpFYCYDhFg7A6AxI2KHM5hJHcJzA0rj9F3fZff398tKLX1sgItIm"
    "aM0thYDraVq9dJrLYLr74b1WImaHMYhJJovU9mgQgbnnZbzAhxK1ICwZdosdOzupXr6njHSesv6VS7ws+/X7h7K49m8uzr7zjWty"
    "1cDXUEpxLpcXr734Lc1/evQpq6OjFb6vq+mFJHw/DSnjaOu4HF3T34dE6xqQZUPLAlj4YEWAJQAlwSr4CykAJYK/pYsAGbxHQgKS"
    "wMIEyEAayu5AomkN4vGTANYo5HcD8CGEXaUfEBFisSgefOAR1XO0T77u4vMKgoiMCRRNkgJGG1p3ymz36S1H7Bd2Dch4xApDUzTG"
    "uY1vfhc1eyIRaPxBPUBFCGt0dtJor2xFoUvzkg9xfTk/foSPGvIOAkoKDI7kceGZJ3i/vfGDQ8YEDpTQqwYpBTKZHJ13yVuaH39y"
    "k2pvb4Hn+TXfx9A6g6amM9DedRWc2FxoysKQDgAqBFgEXKZ4XkwVB0GjPEHBgXHYWtkE/yfDwXOtAc0QbEMYC9nUM+jr+Qlyue2Q"
    "sqkmuhiIhP6jffjgB96R/843vpjSOjALK++xfyhHa992c+vRwZyIWLIkqo/pvMdplgk0KsJDERCdcur6+hkvLz3xkkjA9Qymdzab"
    "u35wzXAsasMYLjl4AqOU+C+uem/zAw/8yeqY0lYFfCIJZg8Ao7Pr7eia8U4WTgJaZIksYrIlWAliKcCWABQBSlRwgpDaFYVUX7zC"
    "9wQF1mARcYpIRCJgs+TDcAFOZBaSydNhdBr57LZQJJQBZYxBsimBB+9/WEnborPPOr3guh4VM5Y83yARs3nZ/A79s99ti1iWLAeQ"
    "Jjhvqnfeo7ixGBV2pwZL+GSk87T19Tfy0mvplBIYThfw1c9enjl91TzX9QIPX9HOV0qZf/j0F5I//MntTseU9mrKJwmjM5Ayjllz"
    "PoVE6zqMFLLkkSEtFTwIyhpJwiLIiGAjBcEKAM6yFvg1IkCUEYGLz0vAr/gbIoLhAkhINCXXQskk0iOPh1E+WSESDGLJBH5/34PW"
    "siUn6GVLF3qeFyCBDM3D42e3+vu6R9Rjzx1Riahd5gJ1zntUIGlc8xt1ElYbLOFrWfoRfiU6XioZAP+cNfO9u2/60FAlW/Q8H5al"
    "zC/vuCdy5ds+0NTUlKxR9iS0zsFxZmP6rGvA1vEQdobPPqOj/4J1U/oTcWE8DXrkuZGmux4dnnI0ra1YjNiEhQdculeq5/wrc/AS"
    "6w+eF0UAaQbCizSDtAF8A/I1JCeQGnwIvd03wpg8KOi9E0TsBMF1fSQSMX7i4d8Ozp45Xfu+psBpFTTb6xvM0WlvubltOO2RZYmK"
    "ws+K/MNXsdEmtSz7a35lOl4G53vfjz8ytGrZTM/XhpQURZnIe/cdkqevu6w1lc6SbauS9w0QMCYHy+rCvPlf4KxuooULOfOVzy3Z"
    "OX9uLFMrzVMZ3/nMfx6c85snU1OSMWZNgberBHyE+kDlLosGuQn0gTLgw01XAl4zyA8uaAP4HixuQXbkWRzc9/mge26FhaCUxNBw"
    "CmtPX+0/eO/tQ5W/6/kGlhL8vduei/7tlx9KtDY5pRSzY2602WDO5ijzvph4Gulcs742xfml1tIpKTEwksfbLz+l8P63rM16vhZF"
    "1s8cJGz81Xv+pvmZZ7fIZDIOrU2FjetDyjhmzP44GzWd5s4z2Z99d9WWrg4n77pGMbMw4eUblrGI1Jesaenf2ZOPvtDtx50IsVGS"
    "KmU91+oAQlQ/D+U/iwrtu0LsVWRZAyRgdBaOPQtKNCGdeirkAkV9gBGPR7H1hW3CiURw5mtOLRRFAYkAZKuXdvm/2bDb6T6aE0U/"
    "SOONNmtMuoZcynVqF8PvElUZPy9HLR0FufhtLTH++HvPyQZma1VUj2/9+Z2Ru+99wGptbR5l7jFrTJvxYUSTJ8BDDp/8yPx90Yh0"
    "83lt2bZgpQQrGVy2EuxrIwCIL75r5t72NssrCEmwCWwLGFuAw+dVlxO+ZgmwRWBbgi0JWKEyaVHwukXhZ8KriFS2BZ/SaOm4BO0d"
    "V0DrVKgPoGTaJlta8LX/uCG6Z+9BZVkWa20gQi4AgP/6rSuzvs/V9QgNFJyMm2gz6drF4NuqExVfYi2dlAKpjIdzTpvvLTqu0/N9"
    "TTI0+5RSAED/35e/HlNKVQVyArmfRnvHFUi0nIK0N0LHHR/PnXlq6wgMVCQiTb3UXiUFu74Ryah0X7MsPpQXAmQLZlsAtoCxZDXw"
    "rfA1q/K1EGFKwA7fVwJGBUoly/L/IQVgKfg0gvbONyKROBlaZ0IgIYwfKPT29tMXvvT1OAAu6jjhWdBfnj+/MHd60uQLJiz1Gr/g"
    "ZPzaiTprqwA/tkUnRlWvvMRaOjYE25b4wNtek6tMHw41fPPDH9/uPP/8VplIxCoUPwGt04jHV6C9643QIs1aWJjSYbsAjGYz/mCL"
    "MGlm1hQ7ry0ZULQSMIrBisGKKi6AFcMoVFB/gARVlK+Kr1VwhdC8NKH4YEkwitE1/Woo2RKarFTiAs0tTfj5r+5ytm3fZVmWYq01"
    "hAi4QMSW5m2vW5zPFXSIFC/dpBtThI+ZdEohyo7FeibZHkUIQrbgY/FxXfq1axd6AKiYSmVZCsZAfPWb/xmzbbtC6UMYjYugo+tN"
    "YClgBJG0BXqHtQ1ASCkYEz/owLCOwCIYYcBRG9TSCmprB5qSwZVMAM3NoLYOUHMz2FFgaULKl2VWr4p+hRAJFAVAL4oBRSVPoxEu"
    "VHQq2qZcDmMKVYqcUhIjIyn861evjwWMIcxIDriAeOMF8wvJuA1f4+Ux6RoR4TUKo0Jx+Mc4mic1MBYmQIAgh/+KC5cXAJii8lc0"
    "+2657VfRZ599Qba1l129gYt3BC2t5yGSWAqfUoC0YFvEu4640QefHmo6a3XLQL6g7YgzWgz42pAthRnJ+fYDe7MtkeYoEI2QHjiA"
    "/Pb74XbvgHd4G9j4ABuIaBPsGSfAnrYIztyVUMkOmEwaXMgDQoCIwWRAAjAQoX5vQCxgYCBM4HplBmAIZBS0yaGp9VwMD96PQuEA"
    "hIgAMIEukEzi57+60/n033/IOv74ubroGdTaYMHsZn/tSVO9Pzx+2GqKW9AGL8PshAlG2tWk/anGTLrGzEFfM5qTUVx5yYpCgOiy"
    "ZB8DoB//9BcRWSP7i1p/S9vFgS9eSrAkkAxk2BdvPjznlKVN6WhEeq5vlKBqc96WwgAwn7yzb+6A3WpZRzfz0d/+jHIvPgB/sDsI"
    "A4sKTZsNMht/C0gFu2s+YisuRHLNVVDNnTCpobCSWAbfzqaMBJYBMYFZhL4DA5ggs5a1B2nF0dp+MboPfQtApLRHy5Lo7x/ET372"
    "K+dzn/nbtDFGSClgOIhLvfGC+fm7HzlsBdyVx+DE45l0jeVs1vZ2KJfJ1G3kMPn2KEIQCq7G8bPb9cI5U3Sg8BR94RLbtu9Sf3r0"
    "SSsej1WYfYHDJ9m0Fk78+BABAk+dEUSRKPH2w17syi/sXLLjcD5uK+ErWb5sKbyRjKuu+dXAgl/tFR3uA9/gQ994G6X+9BPozBBE"
    "rBki3goRTYZXovyak4B3dC+G7voaur/+JqSf/x1ES3vA3iVCuS/K7L9oUsqiUhh+ThKgJDRySDSvRSQ6P0wyEeXIYSSCX9zxOweA"
    "sMIgWFEMnHxCp9+aDMWAoGMw6RrPMKpNEQOJYlr4GLN0xk1eqMwSCrTbvKtxzpr5LkSZ/Qd5+8L8+q4/RFMjaVSyf8BACAtNLevA"
    "pEuKVfHyiSgeJ2w94sZf/8+7lp+7qqn/4pUt/fEoGZ9BD+3ONP16N6b0DI1Yuds/wZnNf6QigMEGMHp8pcFyIJwYdLofR3/4Mbj7"
    "n0PrpX8PZHNg6CDKZgjEYU6AIZChMLMseA+aw2CUB2kl0NT8GvTmdoIoCg7L0qMRB9t37JaPPPa0WrtmtVf2DhosnNvsL5vf6j+x"
    "uU/FY1ZFkGic855ECV/12NvRnkU1mi00KkuqXZDMBCUl1q6e6yFsNF3J/u+7/yFbVLH/wOMXiy1GJLYAhgpBiLboxQs1bU2EiE3Q"
    "UtCvn812/ObFfIewBbQEfMeBI3LI/uiDnN31FIlkRxDJmwDwlVFB1j5IOSDLwdDvvwvj5tB++efAmXQQKawAfvniEPjhPk3QA9CY"
    "AhJNp2Gg79ehm1iG1UYCuWwOf7j/IXvtmtUuh4M8wsEivHpJl/fwM30qKQiGuW6EjxocaVeJNNRAdbIYzRYm3x6FKpw/q5fN8IO6"
    "TlGq2unvHxQvbtupIo5T0v6L6Vzx5GqQioCLLTFrI3OSoMO/yRg4HgU7DhCNgJubHB7+1eeR3fkkiaYpgPbHKBCeCBEMYAxkcydS"
    "G27CyJ9+BJFsCawJWRtJpGokLYWhBQx5UE4XorHFYC5bBMwMZVl49PGnrUrHWBG2a1Z0eVKGGcTHZNLVRhDF6PjNGKa7GA34ybdH"
    "IQoUwI7WOE9pS5hKtygA3rJ1uzpy5CjZtlXiAMwaQjiIRheByS9F8VgEcpUFwCIM7IRuWk1EmgQZGCDRQoMP/4TST/0aomkK4Ht4"
    "yQ+jIRLtGPrtvyO/byMongzSyopiSdRcVN5nEXFJqBABdEmPMiZILN26fZcaHk4LKQP2XzzBWV0xE3MktME4kdfxTLpjKeETlZ7A"
    "+oUIjbZHISK4nsGsaa3asVXg9hSlSlx+/oVt0nPdijyAgPotqxOWMx0Mr9SktMoXX8UJEMpaAE4E/vBhjNz3PYhIonGW34BIgBAw"
    "fgFD93wzmM2gKqm8kvJRjiVQGQmYfESjCyBEFMy6xAEsy8LRo/20a+8+WfQJFNsyzp3RpJubbPY1qjuSvtQOZxO1oyk5gsbwKTfS"
    "8bLUL98AyxZ2+ZUOjyIFPPX0c1atTsHsw7anQVhJGDIVsfhyKJcFqqiMReg0iiWQfuZ38AcPA8pBVY74y8EFIknkdzyG/L5nIKKJ"
    "QDxViqZSqLm43yJlCTA8KLsLSrUgGKge5t5JgWw2h02bnleBa5ghwtYFrUmb501Pas9jyKoU8pexwxlQtz5BvCwdLynoc5eMO1zZ"
    "YaEo4w53HxFCSlQiBrMPOzI7sLkpsH+5OBFFFJ9XhHWL+1MKppBC9tnfgazIqPSsl+VBBPZdZDbdCVhWSOHlfXFNR71KpDVkIK0k"
    "LKurCgGIADYGhw4fqfS8QQcZxxxxrDA1YLImXWMlfPU5OUEds4lR6YXiwO05a3qLqbQApAz+ZvP5Uh5g5UNUpFYV8yK4EhmJqhRD"
    "JoAcB27/Lng9u0CWU9G85+V8GJBlo7B3E0whFbRg0bqK+gMkGCOWTzK8t1q8IqTS6apUvSKxzOyKhypTWJjSsEk3MazGzvesCAe/"
    "lI6XjKDi5/jZ7boyTw4QGBgYErt375O2ZZUsgGB2jQXHmRvY/6IO0Cun1Jb2zICy4fXsAeezqHZjv4wPBkja0MM98Id7AFXRmbOW"
    "+ilUBkucgUFCwY7MAbNfEoPMDKEUnnv+RVVJJEWdeN6MpNYGo5tAjqrza6yEr34gaXTan3hZOl6WIn6mLtbXo/7gPVUvpFCDqFTB"
    "GQBICa93d+DbJ3qFEIABIWGyw/AHDoEsO9ADqvZH9fdd794qHnKMs/B8fgkmHY0RSJq4hE9NWJdewT5o3HQwcQzwOEblTbxClF8v"
    "znzMv8WTumOqUrT5VZhwXvIE1s8pr9LiJgwwiFKv2/o39zJTqvZfHfizCX/r5dv/WGfBlUMwaQKv7JhT2xsv4SvCdXQ4uC7gMe6k"
    "z1JsWY6mFmMMfN8f48ZFw8RERXlpDGTLtFdO/lcAnyJxyGQHoL3ySXCjzGsMVu/Vd1hJWavZNxbhowkKP8auDyx5AoFGGy+Pp4Aw"
    "A/3DOSpz6eCrW1qaedrUTuN5XmmzRTOwUNgHYhH61sNqndq/XPEXAHwP9rQFEHb0FbIAwnvTHmTTFKi2mWDPLZdfcc2+DIOYQSbM"
    "Nubg3tz8/rCwpSL0bQyOmzdHVyh/JVgNpdxg1vNkTboGRtqNPfcJ1X6AunPpGlBApBDwtcEL23tVpSMoKPcWPKWj3fha1zSXZBiT"
    "rWZRXOdvxWETE9gtwOqYA9k6DdDuK6MIEsF4BdjTFkFEm4FiWXq5u2SwMS4bJ7VKZO29ERGM72PWzOmm2lkW/Hlh94hSpXgAJuGV"
    "pao8wHqwGnvglyi7gic7RAm1M/NA0GMoAclkgquTQBhEEl7hSOAu5YB6iItUxGHIteY5CPBcyHgHokvPhSm8UqZgcFfxlZeERSPB"
    "VaJ0U6T4Go5gGIIFjJ+B5/VXVQ4hiAIhkYjz+L+KYzTpMMoNTJUDssfIKRQTDTFopOMlI2i69Nz2o1U2bjEYtHrVCs+M0gMkCoVD"
    "YD8XiIHSIVYjQ/mwwwIOJnAhh8SqyyCiTS9ZDBAF9h0zQwgyEAJcyMKasRjRBWvBuTSIKSweqRRR1WKgLKYkfLcPvt8f6thFbsiw"
    "HQenrF5RCpcbE7iIMzlP7DqYUUHN4LGbdGMGksaJ84hGhhhM1PGSEfTfP9gzLLUxpUTQEOC04sTFWlU4goIkUAuedwRe4QgEVADI"
    "4mEaVFB++FwX5S2Bc1k4M5YicdoVMJlBQKpjBn6h4BIRsW1bbj5XEACB/QKaz30/hJ0AXK8M+FFXjc5iDARbKOR3QesMiilxRATf"
    "99He3sIL58/TlSFhADjYkxdDaZ+UJcAVYZpXZBxejVIpGooaTdDxkjlo5HjkaFYMDOcpoP4yAiw5YaHf1tbCvl8OkQohoXUWhdwu"
    "gC3AmGoq0zWHXVmrZwicSaHlwo/CmXsSODsyaSQgInZdj1YuX7rlnjtv+cozT/z+X17/F697wBs5iuTaN3PipEthUsPBEYV7I11k"
    "/0VRYKo4VJEL5LLbq+1zIhRcF/PmztZTprRzkAlV6jzC+3szMp3VUEIALCY9Dg/HMA6vSNCi1pavNTGogbIwRoAAA8MFemHH0SDa"
    "xUH2qzEGs2dO1wvmz9P5QgGVLlAiQjq9KUywRKlAs3Tp0X+hTSCXXRfSiqH9TV+AiLeA85nJIAFrrampOTlyz123/GzdmWsOz59/"
    "XPqOW2/4xUmXvXNH4sKPEQp5QwZVhaJVyGhM+LzMHYSR0O4QspktEMIutZYRguC5Lk47ZaUHwBQ9pkXP+KZtQ0objDFUa/w2fI2P"
    "8q3PyUW9cqGJ5tLVU0AEBUmhjz17yKq2BAIsP+P0U7zqnAADISLIZjbDze2HYLt8qGNQfokD+AZkBExqBM7Uxeh833chk+0wmaEA"
    "CSZQDImIfV9j+vRpvVOmtI/0D6eS/RnPAbQ482/+bQ/sFlAhHxSL+sVC0corVAp1MTs4aCohEEEmvQmu213dTcQwlFI4+8zTq9Pl"
    "Qig8sXnACiwAvASTbmJY1Ss5F6N9zxMnIIzqeBk+t22FBx7fbwMgWSH/ANBfXHZhwXGK1bBlf7nWKaRGHoWAHVJ3vQOvLtsuVu4K"
    "ljAjQ4hMX4ZpH70FsSVnw6T6wW4u2LOQZWqpuJiI7EiE9+zaM/veO345s705OdAet1KAdB7dfGSFKuQAH0TahKXhZe6D0l7KHKAo"
    "Blj7SA09XNURjIiQL7iYPXuGOffstV5R/hcVwCN9Ofn8rhEVcWTQen7SJt3EsBo77W9UUujk+gBUJoUaBiK2wgu7+mX30bScNiVh"
    "jEGx8xetOW2Vf+Kyxfr5zVtlLBYNe/0FXGB48H40t54HEWmC0QyI0RcVA00kwBREGokNhCXBqRRktBWd7/4W0k/fgdSfboZ7eCvY"
    "d0FSAdKuED0G7LsEo1mriH31t+5/1zUdF97XYRXSP3k6e3Zfmrosz2X4TPC5DPwqTmDKosEw4GsIjiKX2oRM5jkIES3lKUgpkMvl"
    "cOF5Z7nxeEz7vi+UUvC1gYDgp7cNqZ4Bj1oSVmBGE43vlT2m/P+x1yqqbRbdgE+Z6vijmcMiiOEC3f3wbvvdly/PaaNJiHJl0Fuu"
    "ekP+qSc3xYO6wMCAFMKG5/ViePA+tE97K4weAQmrAvimIlnEhD8bptKUQsQCnCsArovkKW9E/KRLkd/9BHJbH4LXsxPe0f1h2pgB"
    "OXFYU+bBnr6IYsvOhexa3P6dPw1dRX4AVNtzAc2EIqD9UOQUOYE/unlEETEG++9EsRFduaMYw7YtvPOvrszXQAsA+M6He5zKUbJj"
    "zyGicdPF6wO+nnlfE+eZsubLPD7gUeWMGC8BQQqBVNbD6Sum+/f+51WDxYZQJhzi0N8/SCtPv6htYGCYLKuYIl7sCZDArHlfgIy2"
    "wigDWBJGCcCmUq0eSwLssHZPhsWaMqj/LyZuAgawFCgaB5QC+y50dqA0MoSUDRFrBQkJLhRAhRyDwQGVG4IGoQT4iu4gbogIvgF5"
    "AUcinwHPg9RRZAefwqEDXw7LwrhE/SMjaZx37hne7+740ZDWmoKE0CDI2DtQEGuv3tCazWtSYd/fl9KVheqafeMjjTj2IQajFRDN"
    "QCxq4dntfWrLrj4lhGCtg7iA5/lob2/VV7/7rblMOl2cz1PBBfowcPR2SI4Avg70AW0AL6QyL2S7nikdPnkcACd8TXgGpAnkGvDw"
    "CHiwH0hnIGUCUiUhrWYIOMDIMHggeA8eEwpGwDWCfKbgu4oALn53jT5S0gk0SBPgFdDXe8soKgtyTAmf+Pg12Ur/f1gVbe5+rMfu"
    "G/LIVmHTqGM26WonnDcyyrdcQI56teX18v8nnKkbRgRH0i6uv/XZaNEcLFIDAPGRD74rN3PWdM7n3Qq5rCFlAsNDGzAy8CAUJwDP"
    "Lx+4F7LcEBgBEmiQHwK9ziU0QD4FiJJ3QTkXlCuA8h7IB0gThB98pwgBDdeUAR++B49LCIHw/0KbQCH0fEiOoa/np8jn95SKQsvU"
    "n8K5Z7/GO2fdWlfroBoIAJQKzuLG3+yLWkoG4m3MRtyNm3TjIs2opFBRtALEGLZlI10rR3e8NAaIx2z87qG9zmCqIC0lQpYXcIHW"
    "1mb9ofe/I5fJZCq4QHHvEr1HboSXOwDJ0RAJKoBRIZdRARQqAsk1weUZwNUVCFHu80N+8Dnhhe+7FYCvvSrlvzYBwvihJeD5sNCM"
    "9MBDGBy4E1LGqxJUA51I4VN//+Eq6vdDs/jBTX3W5t0ZGYtIsHl5TLqJeghUzyEq+QEwRkfwRoYYVMqroluYELEV9h/J0Hd/9mwU"
    "gNHF7hiBo0Z8+h8+kl2xfIlOpbNVooDIgtYpdB/6JkxhGELLMhLoSoAHVFsSB54OL1NCBOEyqGDCS1dfrgEKpowwlQjg1/l/kfMU"
    "tX/PgzQR5FIvoOfI90FUnQBqWQqDA4N425uvKKw7c03B8/wS9Ye1APj6rbtjxiBsj/9STLqJewiMJ8LFyzHEoJbtaMNIxm3c+IsX"
    "on2D+QougGJhKP/7v3wujYre/EXnkJQx5LJbceTgNyGMDeGHSFBJ6SHwRfh/eBwoaUVkcE0FQlSsq+AUoijni7pDEehuHcAXP+MV"
    "gR+DLgzi8IF/g9aZMP+v3Pwhm81hztxZ5l++8Ok0ggYXJeqXAnz/00ftBzcOWk1xhaBJWGP5/9RgzmbjE84JMjHrovXUQFnYRHPp"
    "qrxVINiWQM9AngZHCvJ16+blfW1Ihi3VPc+n+cfP9QHQ7+6+30okEhXtYhhSRlEoHIDn9iIeXw5BdpBhG/4uhy1eqZQngIpWr6hK"
    "0Kh0IhWvQIaj5FWssvH9st5R/L8ILATA9yFNFH7uMLoPfA2uewRSRqtYPxFQKLi49cffGVm6ZKFfSf3FQtl3XPdMc/+IJ4I+gZPN"
    "/8eYU8rrD6YYby0g47MvXj9euLCRIQb16tUMA7GIwjPb+tSZq6b7c2c0ac8PkCCMEdDZZ53uPvHUM/bzL2yr6RnEILKRy21FLvMi"
    "kolToGSy1IKFStk5qMohoDBMW4rZ64omkDWu3FHP/TLwyedA3ofPi00iLTQhn9qKg/s+D8/rqXL4FFn/QN8Arv0/H8++6+1X5jzP"
    "L/UD8HwDKcj8+093xW+974jTkrCqagFrx9qMrvNrrC3c5CacE6jzNV8fww+AxocYjLFWCkImq7F6yRT/vu9fPojQdS5EZaPoLK1e"
    "e0nr7j37RVNToqptXNA5LAvbnoqu6R9ELHkifMqAJQNSlSt3iz3+SoWa1YfDtSnbRY2sIqULBoGSWeQiJdevD2EsCGNjuP/3ONrz"
    "IzC7EMIp1f4BgG1bOHrkKN70pje4t/zo28NFm78YD5FS8P6enDz3Q4+25l0mKana91/J7sf1x6CBpNDGR/nK+JxL1ten+LHy/8c3"
    "B6kil50ZiDoK2w+MiHTWF+etmVkoi4IgRh6JOHzmGaf6t//iTieTyZJt2xV5dIGPQOsRjAw/BIKFaGQBBEUA45byA4qZOWSq276W"
    "s3fqRBmLQaUiF/DD90rOHx/kExTHYQojONr9A/QdvRVCSBBZoyi/f2AIa05b7f/yZzeMBE4uoOzzD87oLZ/d1LLrUE5GI2G38JfD"
    "pKua6DqZuU9FDnDGN7i2xTtNMh99dNlS9VohCKmMhx9/8fyR1589N+96utQhM3QT87PPbbEuuOxtzalUmmKxaE0DyeKgiAxisRPQ"
    "3nklookTASlhkA84ghDhFVJ85eHVaxePcr4hlRJQAnOPWEByFMbLIDX0Jwz0/Rye1wshEhWJihXA7x/Caaec5N9/98+Go9GIKXYA"
    "KbJ+Swnzf67flvzGbfuiHc1W0A5m1DDpiTnqhF7ZRlrL1s577Dzjmzyq1m8So93HZlkVjYiEgOcbxKMWP3zT5YMzOuPa8w1ZgUME"
    "ruvBti1+9rkt1oWXva15YHCYmpuTNXMDAhNK6zwARjy+HK3tlyKaXA6SFgxcsPDKwBeihopqEKCUz2dCxZFAsCDYgvHSSA0/iqH+"
    "36GQ3wMSDoSwqkbHEAUdUfqO9uP0tSf79911Swh8n8KGmHA9A9sS5jcP90Te9fnnm5JxGcZAGu3KgtG9GBoVw1SDLGO4lKnzzG/y"
    "sYx2n+wQg6CDqI9Vi9v9u759yXDUUcb3DYVesRInOHioW175V9c0PfbIk6p9Sju0rh0NV2y+lAFBIhJbhKamMxBLroCyp4CkQuDc"
    "D+YMMEwYPayYUcCylDolWAV5hjoPN38Y6dQTSI88hnx+H4RQECIS/j5XITSzwVD/EN773rfmv/etf0kXp5kWgV9sDP38zhHrik9v"
    "bM7mmSxFMEADrVtGN3cOBlUGegMblLOHx1lLEwb4AOo681s8MRaNB3iMMR51NNJYSmBwxMMpSzv8O7918ZhIoLWmD/3NZxI3/OCn"
    "kUQiDtu2RvUUBokw/ToPsIZSrXAi8xCJLUAkchxsZ3pAuSoRZOcgtBTCZs9G56F1Cm7+EPK5HcjndqJQ2A+t0xDhiLlawBdZfiqV"
    "gVIS/3zdJzN/8+H3ZAGQr3Vp4GUt8FNZQxEnkPs0bpSumogEUdhZFMi7wYRVQYSII2EpKiYi49hFOEBdZ32HyyHM8VhKzWSrCZoX"
    "VrOs8mcsJTAw7OGUZR3+nd+8aBQShAOkAID/60e3Rf7+U59PDAwNUWtLc2WG0aiaxGAWoBu2ZpGQsglEEpbdCSFiFWPjBHx/EL4/"
    "DOYCtE6HjgUFIZwwmWM04JWS8H2N4cFhLFm6UP/g+q+mTj1lhau1FsVJqNXATwXAzxmKOqIiebmxKJ2SAtm8Rt4zaGtWWDwnjkRE"
    "IZ3X2Lo/i4FhjYgtEYuErWUwGRFefEmCOs/81lYh7EVsfK5ISsMrNsQAgGUJDAy7ASf45oXDUUeZSp0gmNNnoJTiffsPyc987kvx"
    "W3/+GwcgJJOJoHBnFCKU7edAYvjh4Ec/1Ngrx9QoADK0mWW57Kym2QSVil40hodTaG5O4m8+9O7sZz7x17lIxDGe51PRzq+Q+fz8"
    "zpR1+ac3NqdzhoLePzyKSsdT+JQUGEz5OGFeDB+9Yg4uXd2OeGt5X5lB4M6nB/D1Xx7Ai3vzaG2ygkSahkU4M0mHjPa2UeeZ33lC"
    "SOcUNq4pOaorDvOVGmJgKYGBEQ+nLG33f/uNC4ZjkWokqBQJAHD/A3+yv/K170X/8MeHbGMMEvF4OD6Wq6aNjNJV6hZ2jl/gVxwH"
    "67oeUukMmpuSuOqKS/N/97cfyC1aeLwHQFRwqiCV0RgoJcxzO1P2X35mU3M6qylaavxUbz916vxAkIrQP+zjXZd04asfWADfyeLm"
    "3gfxyMA2DLhptNkJrG1bhLd2ngXlxvCx7+3GTXf1ob3Zqka08UQ4syEVE0bnnqTOs66/UViRd7OXD3jnBCbdeFyAJpG1UsT0VMbH"
    "cTOT+vrPrk2dfEKHq7URxcaTxfIyBqCkrEKEhx95wk6NpOFEHUQj4QBpYNSU8EaqdakiF1JrjWw2B8/z0NnZwa+/9PzC3weA90Ok"
    "JClFqfbR16ZYFMs339sd+cfrdyQKrqGILcqevoZMuuA8BkZ8vOOSLnztr+fjd/1P4lPbb8S+Qg9soSAo6CPoGh9znC58aeF7cHH7"
    "KfjYt/bgh7/rR2uTgtYT6W7BbQorKY2X/gF1nvXd9wsVvZ79goEgMZFJV095aawuHXU7XkpJyIYt09d/4KTMNVcuyoaytIobBDUF"
    "gAwRYfML29SPf/qLyL1/eNDeun2XzOVyICFg2xZsy0aN/320FRjKec/z4boeXC+oAG5ubsJJK5Z6l138Wvctb3pDYdrULh3sxydB"
    "hKJ3L3AZBPJeG0N/941tiZt+1x1JRCWUDGU+NW7SCSLkXIN50x08+PVVuC/1FN6y+UtIqAhiwoGBKWlqAgJZU0Daz+Onyz6F1yZP"
    "xlkffx57uz1E7UonE+rkewbbF1ZcaJ39AHWd+Z1TSdqPBJ2PiRox6SYzl652bb2Ol0WP2VDax1Xnzyn828dWp9uaHRNo16aq7LwG"
    "EdgYI57e+Lx65PGnrMce36i27ditDh7sFkPDIwQAnuuhWskNnEaWUhBCoKO9lefMnamXLlrgn7H2VO+0U1f6RWoHQMXS9iLgKxQ9"
    "ADDP70zZH/3a1sTGbSnV1myVyhnHU5apDkeVktA/4uHGTy7BxWfbWPPoP2DQDCMiHGge3QZPkkTeFNAqmvHY6V/G3Rs03vOVnWhv"
    "skIuMJa1FjjDQcrA89bSnHU/iOTJf1oIZ0lZDxjfpKMGvVX1kxvrIw0RIKTAcMpHZ5tjPvHOpdmrL5+fD4o4DHEoMko8TGsYwwiV"
    "sKoZ8nv3HRS79+yTxhg88dQzVrEiiSiY6dve2sLLTzzBJyIsOWGBP6WjvUrtN8aQNgZSlFl9hZwHAJPK+vKLP9wdu+mu7qivGYmY"
    "rPbwjSHjx2rdrg1g2YQt3zsVt+d/jw+98B1Mc1rh8djNMCxS6C4M4ttLP4g3Ri7A0muehecFyFQvwTTotcOGrJgwfn4L29HVat+G"
    "d+ennv2fj0DaJ4A9U66qmNikG4u11fUsThBw4rCAsjlpIZXV4uP/vjFx2+/3Rz579bLMmSs73eKng6iagJQSRaLUWpNhDrvIKcyd"
    "M1PPnTNTA8B5557p1tH2qm4itDqopPkHE8zD7wYMBxQvhGAA9NPfd0f/5Yd74vt6CqIpoWDbqHHv1kfwsbiiEIRMXmP5ggScBPDg"
    "wS1wpIKZoAWegYEjFR7sexFvW3wBlsyJ4oktOSRjoiLPoPp2mYSRMkJGFx7Zd9O8vAqdKr8E8D5weYbQyzWXrr4ZMjYlGBNYCG3N"
    "Dp7eNqTe8HcPNZ97ylT3fW84Ln/+aV2upURRNATt9YvIUHkwxlC5IxmPMgWoIkYgwiZWJUqvAHqAaGAJwYMpT975p6PODb8+GHtu"
    "Z5DK1dpsQWuGMS81SkfQTGhOKDABA2660d4pEAg+zwQ0xy1ok69vDlIpEiqYDTGLX4aFIUwqd9sf/UhmN6QzD8Y3RX/rsc+le2lF"
    "DAxAG0Y8qgAG7n+y17738V77pIXN+qrzZuUvWjvNnT8zUTVg2NemJOqJRCkUMFaPp6LlyBxo8hw2A5VSACHQAdCTLw5bdz1y1PnF"
    "A73Ovp68iNgSrU0KhimQtWPY9w35TkJk4DB0PpLRIAba7ETD7S8Ngs8TA8NZHbD/UTUGpX8MqSgZP71b+7E/AkwK6x6QBzdclZt6"
    "7o0/FCqy3rgpU9U3sEGTDqOyhI61iKH8flGTTsQtEIAX96Tlp775Qvxff7Qjvm5Vh3v68nbv3NWd7qK5Sa2CuUKjXJpls6jC9A/n"
    "P1RohaV3Cq4Wz+5Mqwc29dsPPztsPbll2Mq5jHhEoK3JAjOhYszhKK54LFE6ZiBqS7y4P4dCGjir4wTc0rMBQgnocVBBQKCgfZzV"
    "cQIKGeDFA3lEbFG2Akb9rmFpxYTOF3548LbZOVzLKpw9Dkxb9712lrGtRNQWlLxWhtEaM+le2hCDidcKQeEcXkYmb6A10JxUmDMt"
    "pk9e3OodNyOuF89N+nOnx0xXm2MsSYhFVN0THM54ghnY152Te7tzYtv+jNp+ICOf2Z6yDvUVRDbPcCyBWERCCFRo969AlC40h/tT"
    "Pm78hwW4aJ3Cmkc/MTkr4EHGe7+yF+3NKkTQUUUjTMICGzOgjF68/aeL+svvXskSt5Geds5N64XTdK3xRnxAqGMx6V6OIQZjm5sV"
    "BQ0y2JvWQME1KHgMBkFJQlNcIR5RJhYRmDc9pjVXDkgj+Iax62BGGQMMpjXlCga+AZQkOJaAYwlIQaUC5cmadMcSpSv6AeZOt/Hg"
    "vy+blB/gvOTJOOsftmNvt49oiQNU742ZfRVpV35h4Lo9P1m0HreyxFWkS9N1gfU0/bUrWplymwHZCfZR7Rpu0KQbQ+GjSbqUx/Qs"
    "1llbDJUWS/ICJS64XI9H75MAxwqyZ5QKuIqgcnSNG3TbNuIkm0yUTirC4IjGOy5qx1c/PGd8T2CkC19aEHgCP/6dQ/jhPUNobZIl"
    "vaSmLZ+hIIWt1yZn2dbjbhjEdevDtlvFR8gFpr72R++UdtN/GS/lA6Qm1uzHDwu/8h0va5VPqthGCNiaKttSO5+SsjQ53YUacJLV"
    "y79rJEonpUD/iI93XtSOr149G76dwc29D1XHAloX4a1dZ0K5cXz8+4dw0z1DaE8GrL/e3CcGfBVpVzrf967dP1l0UxHWoyMlV94q"
    "cdsLPPW8hXcLFT+f/bQGFTPajm0u3bjc4WXpeNlI4sN/b+LlZBNtlAw4weK5Dj76F9NwyapmxFsqooFDwF2bUvj6HUewda+HtiLl"
    "1+PGbLRwWqQppH6/e/7xF2ELqAj8OqGyawVwnek89+YuqeSzBNGJIEwsXu669Je742Wja6lBJfVYTbr6SDn5RJsgRsLIuwZtzRKL"
    "Z0UQj0pk8gZbD+QxMMKIWALxmnyAKu7DbEg6BOZe4+kVe26Z3xO6/A3GjJVeeavEbVfpaefefL5wEveyzocjswS9FJNurLVjm5sT"
    "sfrGxdB/X+JlY2vrJ9oETqpgIBeQ90xYXUWI2AK2EhUZQfXOmxmQLOy40O7wBXt+vPD3lawf4wTLy0hwwc1XCxn7HmvXA1ihGCx8"
    "RYcYjH1oNEkx9D8l8XIs3aXRrizFOAaVmnFQZfvJOmuZQdIXKmL5hcz799684IZ6wC9nWNY+brtKY90fVfe9b73B+IXrZKTDAgmN"
    "cnPUV3CIQc3acTtevtq1dLV7EzUl3cCxNNqcaG2QvEwwHFw8btk4GBBaxaZa2s1ct/fmBTesu5ZVPeCPzQGK7637o8SGs/X0i37+"
    "ORLOetaeCZo8VjpYX16Trr65+XK2R3l1TDrQsUVF63FFatTBBjYgCaEiwujC+t0/nPNPWPeAxIazdVhBOSkECPVCFriOzLQLbrta"
    "2vHvsfEB7elwwjImGjhxLCbdq9Ue5ZU16capnThWE3qctQzWQjhSSAfGS79/14+Ou6EIu3EzohqKOKz7o8KGc/yZF95+IUvnB0I6"
    "04yf9gGSo5XD/zXpGq+deAkmdFnTZwZp5TQr4+e7YXLv3vWjBffgWla4jiacrNF4r/VQMZx13s3Tjd10o1DRC9nPgdn3w1xC+l+T"
    "brK1E/W40UQmdPG7mJlJC2kraSVgvPQ9hULvew7csvrwWArfS0OACiQAgJkX/eY9LMXnhRWfzl4WzL5PQYWj+F+TrrGciXETbca6"
    "Jw683EJaSlpN0F76MJH57M7/mn1jpUe3UZAew7SFUkcD7jr/553Kjn2IQB8UVrSLdQGsXQMiE5YXi4lzBv68TLqx9zbeWhgmMsQs"
    "SEWFVDEYL9PDoO+yzn1794/n94K5+IWTmsR17OM21l2rsOE6HwA6L7ujy0LsGsH8ZlLOIpAAGw+sCwDDgIoTFkE0pkNp/IITajDS"
    "NrEsHQsZarT0hlzZtUpr47oLjcPawcTlMyNBKgohnHDcfWEbA7cYlf/Onu8f31Opox0LGF/ivBWmwMwIfnz+RXc5Bce+wGjzBkF0"
    "KoOXkXSISACsgxsw3ihl8X+MSTdJ3eXlN+kAEk7APGU4aV3nGZCbATxBQt2BZOrenf+xsFAG/Ngm3quAAPURobi56a10imSznEiu"
    "YuOvBOsmCLmonDdNDSpRjfkBJmM2jW/STZTT0IhYOAaTjiTAehuEGiFhb2LojSSs52bO6npyQ4VGv27dH9WGlwj44uP/B4bzfVmV"
    "FCxoAAAAAElFTkSuQmCC"
)

# Device classes (magicBox.cgi?action=getDeviceClass) that count as an IP camera.
CAMERA_CLASS_PREFIXES = ("IPC", "SD", "PTZ", "TPC", "PT", "ITC")
CAMERA_MODEL_RE = re.compile(r"(^|[-_ ])(IPC|SD|PTZ|TPC|ITC)")


# --------------------------------------------------------------------------- #
# Data folder, persistent log file, settings
# --------------------------------------------------------------------------- #
def base_dir():
    return os.path.dirname(os.path.abspath(sys.executable if getattr(sys, "frozen", False) else __file__))


def data_dir():
    """Where logs and settings live. A 'portable.txt' (or 'data' folder) next to the program keeps
    everything beside it (portable mode); otherwise the user's application-data folder is used."""
    env = os.environ.get("HK_DATA_DIR")
    if env:
        path = env
    elif os.path.exists(os.path.join(base_dir(), "portable.txt")) or os.path.isdir(os.path.join(base_dir(), "data")):
        path = os.path.join(base_dir(), "data")
    elif sys.platform.startswith("win"):
        path = os.path.join(os.environ.get("APPDATA") or os.path.expanduser("~"), APP_SLUG)
    elif sys.platform == "darwin":
        path = os.path.join(os.path.expanduser("~/Library/Application Support"), APP_SLUG)
    else:
        path = os.path.join(os.environ.get("XDG_DATA_HOME") or os.path.expanduser("~/.local/share"), APP_SLUG)
    os.makedirs(path, exist_ok=True)
    return path


def log_dir():
    path = os.path.join(data_dir(), "logs")
    os.makedirs(path, exist_ok=True)
    return path


LOG = logging.getLogger("hkcam")
LOG_FILE_NAME = "hk_ip_camera_settings.log"


SESSION_ID = uuid.uuid4().hex[:6]     # one id per program start, written in every log line
LOG_HTTP = False                       # True = log every single request to a camera (switch in Settings)
_crash_file = None


def set_http_trace(on):
    global LOG_HTTP
    LOG_HTTP = bool(on)


class _SessionFilter(logging.Filter):
    def filter(self, record):
        record.sid = SESSION_ID
        return True


def setup_logging():
    """Everything the app does is appended to a daily-rotated log file (90 days kept). A second file,
    crash.log, receives low-level crash dumps (faulthandler)."""
    global _crash_file
    if LOG.handlers:
        return
    LOG.setLevel(logging.DEBUG)
    LOG.propagate = False
    handler = logging.handlers.TimedRotatingFileHandler(
        os.path.join(log_dir(), LOG_FILE_NAME), when="midnight", backupCount=90, encoding="utf-8")
    handler.setFormatter(logging.Formatter("%(asctime)s [%(levelname)s] [%(sid)s] %(message)s"))
    handler.addFilter(_SessionFilter())
    LOG.addHandler(handler)
    try:
        _crash_file = open(os.path.join(log_dir(), "crash.log"), "a", encoding="utf-8")
        faulthandler.enable(file=_crash_file, all_threads=True)
    except Exception as e:  # logging must never stop the program
        LOG.warning("Crash log could not be opened: %s", e)

    def hook(exc_type, exc, tb):
        LOG.error("Uncaught exception", exc_info=(exc_type, exc, tb))
        sys.__excepthook__(exc_type, exc, tb)
    sys.excepthook = hook
    LOG.info("=" * 70)
    LOG.info("%s v%s started (python %s, %s) - data folder: %s", APP_NAME, __version__,
             sys.version.split()[0], platform.platform(), data_dir())


def system_info(extra=None):
    """Facts about this PC and program that help to understand a problem report."""
    lines = [f"App: {APP_NAME} v{__version__}", f"Session: {SESSION_ID}",
             f"Time: {datetime.now():%Y-%m-%d %H:%M:%S}", f"OS: {platform.platform()}",
             f"Machine: {platform.machine()} ({platform.architecture()[0]})",
             f"Python: {sys.version.split()[0]}", f"Program: {sys.executable}",
             f"Script: {os.path.abspath(__file__)}", f"Data folder: {data_dir()}"]
    try:
        import psutil
        lines.append(f"CPU cores: {psutil.cpu_count()} | RAM: {psutil.virtual_memory().total / 1e9:.1f} GB")
    except Exception:
        pass
    try:
        for a in list_adapters():
            lines.append("Adapter: " + a.describe())
    except Exception as e:
        lines.append(f"Adapters: could not be read ({e})")
    return lines + list(extra or [])


def build_diagnostic_bundle(path, extra=None, settings=None):
    """One zip with the logs, the settings (user name removed) and the system information."""
    for h in LOG.handlers:
        h.flush()
    with zipfile.ZipFile(path, "w", zipfile.ZIP_DEFLATED) as z:
        for name in sorted(os.listdir(log_dir())):
            p = os.path.join(log_dir(), name)
            if os.path.isfile(p):
                z.write(p, "logs/" + name)
        clean = {k: v for k, v in (settings or {}).items() if k != "user"}
        z.writestr("settings.json", json.dumps(clean, indent=2, ensure_ascii=False))
        z.writestr("system_info.txt", "\n".join(system_info(extra)))
        z.writestr("README.txt",
                   f"Diagnostic bundle created by {APP_NAME} v{__version__}.\n"
                   "It contains the log files, the program settings (without the user name) and information\n"
                   "about this PC. Passwords are never stored. The logs DO contain device information such as\n"
                   "IP addresses, models and serial numbers - share the bundle only with people you trust.\n")
    LOG.info("Diagnostic bundle written to %s", path)
    return path


def tail_log(n=120):
    """Last n lines of the current log file (shown in the window at start-up)."""
    try:
        with open(os.path.join(log_dir(), LOG_FILE_NAME), "r", encoding="utf-8", errors="replace") as f:
            return f.readlines()[-n:]
    except OSError:
        return []


def say(cb, msg):
    """Write to the log file AND hand the message to the UI / console."""
    LOG.info(msg)
    cb("log", msg)


def load_settings():
    try:
        with open(os.path.join(data_dir(), "settings.json"), "r", encoding="utf-8") as f:
            data = json.load(f)
        return data if isinstance(data, dict) else {}
    except (OSError, ValueError):
        return {}


def save_settings(data):
    try:
        with open(os.path.join(data_dir(), "settings.json"), "w", encoding="utf-8") as f:
            json.dump(data, f, indent=2, ensure_ascii=False)
    except OSError as e:
        LOG.warning("Could not save settings: %s", e)


# --- device clock helpers ---------------------------------------------------- #
TIME_RE = re.compile(r"(\d{4})-(\d{1,2})-(\d{1,2})\s+(\d{1,2}):(\d{1,2}):(\d{1,2})")


def parse_dev_time(text):
    """Dahua answers like '2011-7-3 21:02:32' (no zero padding)."""
    m = TIME_RE.search(text or "")
    if not m:
        return None
    try:
        return datetime(*[int(x) for x in m.groups()])
    except ValueError:
        return None


def fmt_time(dt):
    return dt.strftime("%Y-%m-%d %H:%M:%S")


def calc_offset(dev_dt, t0, t1):
    """Seconds the device clock is ahead of the PC. Cameras report whole (truncated) seconds, so 0.5 s is
    added to remove the average rounding bias."""
    return (dev_dt - (t0 + (t1 - t0) / 2)).total_seconds() + 0.5


TZ_NAMES = {0: "GMT+00:00", 1: "GMT+01:00", 2: "GMT+02:00", 3: "GMT+03:00", 4: "GMT+03:30", 5: "GMT+04:00",
            6: "GMT+04:30", 7: "GMT+05:00", 8: "GMT+05:30", 9: "GMT+05:45", 10: "GMT+06:00", 11: "GMT+06:30",
            12: "GMT+07:00", 13: "GMT+08:00", 14: "GMT+09:00", 15: "GMT+09:30", 16: "GMT+10:00",
            17: "GMT+11:00", 18: "GMT+12:00", 19: "GMT+13:00", 20: "GMT-01:00", 21: "GMT-02:00",
            22: "GMT-03:00", 23: "GMT-03:30", 24: "GMT-04:00", 25: "GMT-05:00", 26: "GMT-06:00",
            27: "GMT-07:00", 28: "GMT-08:00", 29: "GMT-09:00", 30: "GMT-10:00", 31: "GMT-11:00",
            32: "GMT-12:00", 33: "GMT-04:30", 34: "GMT+10:30", 35: "GMT+14:00", 36: "GMT-09:30",
            37: "GMT+08:30", 38: "GMT+08:45", 39: "GMT+12:45"}


def pc_tz_index():
    """-> (index into TZ_NAMES, 'GMT+04:00') for this PC's current UTC offset, or (None, text) if the camera has no such zone."""
    off = time.localtime().tm_gmtoff // 60                  # minutes east of UTC (includes daylight saving)
    sign = "+" if off >= 0 else "-"
    text = f"GMT{sign}{abs(off) // 60:02d}:{abs(off) % 60:02d}"
    idx = next((k for k, v in TZ_NAMES.items() if v == text), None)
    return idx, text


def fmt_offset(sec):
    text = f"{sec:+.0f} s"
    return ("\u26a0 " + text) if abs(sec) >= 5 else text


# --------------------------------------------------------------------------- #
# Helpers
# --------------------------------------------------------------------------- #
def parse_kv(text):
    """Parse Dahua 'key=value' bodies. Keys are lower-cased and 'table.' is removed."""
    out = {}
    for line in text.replace("\r", "").split("\n"):
        line = line.strip()
        if "=" not in line:
            continue
        k, v = line.split("=", 1)
        k = k.strip().lower()
        if k.startswith("table."):
            k = k[6:]
        out[k] = v.strip()
    return out


def g(d, key, default=""):
    return d.get(key.lower(), default)


def parse_targets(text):
    """'192.168.1.0/24, 10.0.0.5, 10.0.1.10-20, 10.0.2.1-10.0.2.50' -> list of IP strings."""
    hosts, seen = [], set()

    def add(ip):
        if ip not in seen:
            seen.add(ip)
            hosts.append(ip)

    for tok in re.split(r"[,\s;]+", text.strip()):
        if not tok:
            continue
        if "/" in tok:
            net = ipaddress.ip_network(tok, strict=False)
            it = net.hosts() if net.num_addresses > 2 else iter(net)
            for h in it:
                add(str(h))
        elif "-" in tok:
            a, b = tok.split("-", 1)
            start = ipaddress.ip_address(a)
            end = ipaddress.ip_address(b if "." in b else a.rsplit(".", 1)[0] + "." + b)
            n = int(start)
            while n <= int(end):
                add(str(ipaddress.ip_address(n)))
                n += 1
                if len(hosts) > MAX_HOSTS:
                    break
        else:
            add(str(ipaddress.ip_address(tok)))
        if len(hosts) > MAX_HOSTS:
            raise ValueError(f"Too many addresses (limit {MAX_HOSTS}).")
    return hosts


def parse_ports(text):
    return [int(p) for p in re.split(r"[,\s;]+", text.strip()) if p]


def ip_sort_key(ip):
    try:
        return int(ipaddress.ip_address(ip))
    except Exception:
        return 0


# --------------------------------------------------------------------------- #
# Network adapters
# --------------------------------------------------------------------------- #
VIRTUAL_HINTS = ("vmware", "virtualbox", "vbox", "vethernet", "hyper-v", "docker", "veth",
                 "br-", "virbr", "wsl", "tailscale", "zerotier", "hamachi", "vpn", "tap",
                 "tun", "utun", "loopback", "bluetooth")


@dataclass
class Adapter:
    name: str
    ip: str
    netmask: str
    network: str            # the adapter's real subnet, e.g. 192.168.1.0/24
    scan_range: str         # what will actually be scanned (== network unless narrowed)
    note: str = ""
    virtual: bool = False
    start: str = ""         # first / last address that will be scanned (editable in the window)
    end: str = ""

    def __post_init__(self):
        if not (self.start and self.end):
            try:
                net = ipaddress.ip_network(self.scan_range, strict=False)
                lo, hi = int(net.network_address), int(net.broadcast_address)
                if hi - lo >= 2:                     # skip network / broadcast address
                    lo, hi = lo + 1, hi - 1
                self.start, self.end = str(ipaddress.ip_address(lo)), str(ipaddress.ip_address(hi))
            except ValueError:
                pass

    @property
    def label(self):
        return f"{self.name} ({self.ip})"

    def describe(self):
        extra = f"  [{self.note}]" if self.note else ""
        virt = "  [virtual/VPN]" if self.virtual else ""
        return f"{self.name}  -  {self.ip}/{self.netmask}  ->  scan {self.scan_range}{virt}{extra}"


def list_adapters():
    """All usable IPv4 adapters of this PC (up, not loopback, not link-local)."""
    adapters = []
    try:
        import psutil
        stats = psutil.net_if_stats()
        for name, addrs in psutil.net_if_addrs().items():
            st = stats.get(name)
            if st is not None and not st.isup:
                continue
            for a in addrs:
                if a.family != socket.AF_INET or not a.address or not a.netmask:
                    continue
                adapters.append(_make_adapter(name, a.address, a.netmask))
    except ImportError:
        # fallback without psutil: only the adapter used for the default route
        try:
            s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
            s.connect(("10.255.255.255", 1))
            ip = s.getsockname()[0]
            s.close()
            adapters.append(_make_adapter("Default adapter", ip, "255.255.255.0"))
        except Exception:
            pass
    return [a for a in adapters if a]


def _make_adapter(name, ip, mask):
    try:
        addr = ipaddress.ip_address(ip)
        if addr.is_loopback or addr.is_link_local or addr.is_unspecified:
            return None
        net = ipaddress.ip_interface(f"{ip}/{mask}").network
    except ValueError:
        return None
    if net.prefixlen >= 31:
        return None
    scan, note = net, ""
    if net.num_addresses > MAX_ADAPTER_HOSTS:
        scan = ipaddress.ip_network(f"{ip}/24", strict=False)
        note = f"large network {net} - narrowed to the /24 around this IP"
    virtual = any(h in name.lower() for h in VIRTUAL_HINTS)
    return Adapter(name, ip, mask, str(net), str(scan), note, virtual)


def build_scan_plan(adapters, extra_ranges=""):
    """-> (host_map {ip: adapter label}, own_ips). Own addresses are never scanned."""
    host_map, own = {}, {a.ip for a in list_adapters()} | {a.ip for a in adapters}
    for a in adapters:
        for h in parse_targets(a.scan_range):
            if h not in own:
                host_map.setdefault(h, a.label)
    if extra_ranges.strip():
        for h in parse_targets(extra_ranges):
            if h not in own:
                host_map.setdefault(h, "Manual range")
    return host_map


# --------------------------------------------------------------------------- #
# Discovery
# --------------------------------------------------------------------------- #
@dataclass
class Device:
    ip: str
    port: int
    scheme: str
    auth: str  # "digest" | "basic" | "none"
    realm: str = ""
    adapter: str = ""

    @property
    def base(self):
        return f"{self.scheme}://{self.ip}:{self.port}"


def tcp_open(ip, port, timeout):
    try:
        with socket.create_connection((ip, port), timeout=timeout):
            return True
    except OSError:
        return False


PROBE_PATH = "/cgi-bin/magicBox.cgi?action=getDeviceType"


def probe(ip, port, timeout=3.0):
    """Return a Device if this ip:port answers like a Dahua HTTP-API endpoint."""
    schemes = ["https", "http"] if port in HTTPS_PORTS else ["http", "https"]
    for scheme in schemes:
        try:
            r = requests.get(f"{scheme}://{ip}:{port}{PROBE_PATH}", timeout=timeout,
                             verify=False, allow_redirects=False)
        except requests.exceptions.RequestException:
            continue
        hdr = r.headers.get("WWW-Authenticate", "")
        low = hdr.lower()
        if r.status_code == 401 and ("digest" in low or "login to" in low):
            realm = re.search(r'realm="([^"]*)"', hdr)
            return Device(ip, port, scheme, "digest" if "digest" in low else "basic",
                          realm.group(1) if realm else "")
        if r.status_code == 200 and r.text.strip().lower().startswith("type="):
            return Device(ip, port, scheme, "none")
    return None


def scan_network(host_map, ports, cb=lambda *a: None, conn_timeout=0.6):
    targets = list(host_map)
    pairs = [(ip, p) for ip in targets for p in ports]
    say(cb, f"Scanning {len(targets)} addresses on ports {ports} ...")
    open_pairs, done = [], 0
    with ThreadPoolExecutor(max_workers=256) as ex:
        futs = {ex.submit(tcp_open, ip, p, conn_timeout): (ip, p) for ip, p in pairs}
        for f in as_completed(futs):
            done += 1
            if f.result():
                open_pairs.append(futs[f])
            if done % 25 == 0 or done == len(pairs):
                cb("progress", done, len(pairs))
    say(cb, f"{len(open_pairs)} open web ports found - identifying Dahua devices ...")

    port_rank = {p: i for i, p in enumerate(ports)}
    found = {}
    with ThreadPoolExecutor(max_workers=64) as ex:
        futs = [ex.submit(probe, ip, p) for ip, p in open_pairs]
        for f in futs:
            dev = f.result()
            if dev and (dev.ip not in found or port_rank[dev.port] < port_rank[found[dev.ip].port]):
                found[dev.ip] = dev
    devices = sorted(found.values(), key=lambda d: ip_sort_key(d.ip))
    for d in devices:
        d.adapter = host_map.get(d.ip, "")
    counts = Counter(d.adapter for d in devices)
    for label in dict.fromkeys(host_map.values()):
        say(cb, f"  {label}: {counts.get(label, 0)} Dahua-style device(s) found")
    say(cb, f"Total: {len(devices)} Dahua-style device(s) (not yet verified as IP cameras).")
    return devices


# --------------------------------------------------------------------------- #
# Camera client
# --------------------------------------------------------------------------- #
class AuthError(Exception):
    pass


class CameraClient:
    def __init__(self, dev, user, password, timeout=8):
        self.dev, self.timeout = dev, timeout
        self.session = requests.Session()
        self.session.verify = False
        if dev.auth == "basic":
            self.auth = HTTPBasicAuth(user, password)
        else:  # digest (also used when the probe saw no auth at all)
            self.auth = HTTPDigestAuth(user, password)

    def get(self, path):
        url = f"{self.dev.base}/cgi-bin/{path}"
        where = f"{self.dev.ip}:{self.dev.port}"
        t0 = time.time()
        try:
            r = self.session.get(url, auth=self.auth, timeout=self.timeout)
        except requests.exceptions.RequestException as e:
            LOG.warning("HTTP %s %s -> %s: %s (%d ms)", where, path[:200], type(e).__name__, str(e)[:160],
                        (time.time() - t0) * 1000)
            raise
        ms = int((time.time() - t0) * 1000)
        if r.status_code >= 400:
            LOG.warning("HTTP %s %s -> %s (%d ms) reply=%r", where, path[:200], r.status_code, ms, r.text[:200])
        elif LOG_HTTP:
            LOG.debug("HTTP %s %s -> %s (%d ms, %d bytes) reply=%r", where, path[:200], r.status_code, ms,
                      len(r.content), r.text[:160])
        if r.status_code == 401:
            raise AuthError("Wrong username/password")
        if r.status_code in (403, 429):
            raise AuthError(f"Access refused (HTTP {r.status_code}) - the account is most likely LOCKED "
                            "after failed logins (wait ~30 min or reboot the camera), or this user "
                            "has no permission")
        if r.status_code >= 400:
            raise RuntimeError(f"HTTP {r.status_code}")
        return r.text

    def kv(self, path):
        return parse_kv(self.get(path))

    def get_time(self):
        """-> (device datetime, seconds the device clock is ahead of this PC)."""
        t0 = datetime.now()
        raw = self.kv("global.cgi?action=getCurrentTime")
        t1 = datetime.now()
        dt = parse_dev_time(g(raw, "result"))
        if dt is None:
            raise RuntimeError("the device returned no time")
        return dt, calc_offset(dt, t0, t1)

    def set_time(self, dt):
        """Set the device clock (spec 4.6.3). The camera's time zone is not touched."""
        text = self.get("global.cgi?action=setCurrentTime&time=" + fmt_time(dt).replace(" ", "%20"))
        if not re.match(r"\s*ok\s*$", text, re.I):
            raise RuntimeError(f"the camera did not accept the new time - it answered: {text.strip()[:100]!r}")

    def set_cfg(self, params):
        """setConfig with several key=value pairs (spec 4.2.1). The camera must answer exactly 'OK'."""
        query = "&".join(f"{k}={quote(str(v), safe='')}" for k, v in params.items())
        text = self.get("configManager.cgi?action=setConfig&" + query)
        LOG.info("SET %s %s -> %r", self.dev.ip, params, text.strip()[:60])
        if not re.match(r"\s*ok\s*$", text, re.I):
            raise RuntimeError(f"the camera did not accept the change - it answered: {text.strip()[:100]!r}")

    def snapshot(self, channel=1):
        """JPEG snapshot of a video channel (snapshot.cgi, spec section 4.4.2)."""
        t0 = time.time()
        r = self.session.get(f"{self.dev.base}/cgi-bin/snapshot.cgi", params={"channel": channel},
                             auth=self.auth, timeout=self.timeout)
        if r.status_code >= 400 or LOG_HTTP:
            LOG.log(logging.WARNING if r.status_code >= 400 else logging.DEBUG,
                    "HTTP %s:%s snapshot.cgi channel=%s -> %s (%d ms, %d bytes)", self.dev.ip, self.dev.port,
                    channel, r.status_code, (time.time() - t0) * 1000, len(r.content))
        if r.status_code == 401:
            raise AuthError("Wrong username/password")
        if r.status_code in (403, 429):
            raise AuthError(f"Access refused (HTTP {r.status_code})")
        if r.status_code >= 400:
            raise RuntimeError(f"HTTP {r.status_code}")
        if "image" not in r.headers.get("Content-Type", "") and r.content[:2] != b"\xff\xd8":
            raise RuntimeError("the camera did not return a JPEG image")
        return r.content

    def cfg(self, name):
        return self.kv(f"configManager.cgi?action=getConfig&name={name}")

    def opt_kv(self, path):
        """Optional call: returns {} on anything except an auth failure."""
        try:
            return self.kv(path)
        except AuthError:
            raise
        except Exception:
            return {}

    def opt_cfg(self, name):
        return self.opt_kv(f"configManager.cgi?action=getConfig&name={name}")


def snmp_v3_support(c, ip=""):
    """Does the camera OFFER SNMP v3 (not: is it enabled)?  -> 'Yes' / 'No' / 'Unknown'.
    Seen on real cameras: models with SNMP return the SNMP section (with V1Enable / V2Enable / V3Enable ...);
    models without SNMP answer 'HTTP 400 Bad Request' for it.
      Yes      = SNMP section returned and it contains a v3 setting
      No       = the camera answers 400 (no SNMP section in this firmware), or the section has only v1 / v2 settings
      Unknown  = no usable answer (timeout, other error, empty or unrecognised reply)
    The signal that was used is written to the log."""
    try:
        text = c.get("configManager.cgi?action=getConfig&name=SNMP")
    except AuthError:
        raise
    except RuntimeError as e:
        if str(e).strip() == "HTTP 400":
            LOG.info("SNMP v3 check %s: camera answers 400 for the SNMP section (no SNMP in this firmware) -> No", ip)
            return "No"
        LOG.info("SNMP v3 check %s: %s -> Unknown", ip, e)
        return "Unknown"
    except Exception as e:
        LOG.info("SNMP v3 check %s: %s: %s -> Unknown", ip, type(e).__name__, str(e)[:120])
        return "Unknown"
    cfg = parse_kv(text)
    if not cfg:
        LOG.info("SNMP v3 check %s: empty SNMP reply -> Unknown", ip)
        return "Unknown"
    keys = [k.lower() for k in cfg]
    if any(re.search(r"v3|version3|snmpv3", k) for k in keys):
        result = "Yes"
    elif any(re.search(r"v1|v2", k) for k in keys):
        result = "No"
    else:
        result = "Unknown"
    LOG.info("SNMP v3 check %s: %s (keys: %s)", ip, result, ", ".join(sorted(cfg))[:600])
    return result


def parse_firmware(version_line):
    """'2.800.0000000.17.R, build : 2023-02-24' -> ('2.800.0000000.17.R', '2023-02-24')"""
    m = re.match(r"\s*(.*?)\s*,\s*build\s*:?\s*([\d\-/\.]+)", version_line, re.I)
    if m:
        return m.group(1), m.group(2)
    return version_line.strip(), ""


def classify(dev_class, model, vendor):
    """Decide whether a logged-in device is a Dahua IP camera. -> (ok, reason)."""
    if vendor and "dahua" not in vendor.lower():
        return False, f"Not Dahua (vendor reports '{vendor}')"
    c = dev_class.strip().upper()
    if c:
        if c.startswith(CAMERA_CLASS_PREFIXES):
            return True, ""
        return False, f"Not an IP camera (device class '{dev_class}', model '{model}')"
    if CAMERA_MODEL_RE.search(model.upper()):
        return True, ""
    return False, f"Could not verify as IP camera (no device class, model '{model}')"


def stream_info(enc, ch, kind, idx):
    p = f"encode[{ch}].{kind}[{idx}].".lower()
    if not any(k.startswith(p) for k in enc):
        return None
    enabled = g(enc, p + "VideoEnable", "true").lower() == "true"
    if not enabled:
        return {f: ("Disabled" if f == "Resolution" else "") for f in STREAM_FIELDS}
    w, h = g(enc, p + "Video.Width"), g(enc, p + "Video.Height")
    res = g(enc, p + "Video.resolution") or (f"{w}x{h}" if w and h else "")
    return {
        "Resolution": res,
        "FPS": g(enc, p + "Video.FPS"),
        "Bitrate (kbps)": g(enc, p + "Video.BitRate"),
        "Codec": g(enc, p + "Video.Compression"),
        "Bitrate Mode": g(enc, p + "Video.BitRateControl"),
        "GOP": g(enc, p + "Video.GOP"),
        "Profile": g(enc, p + "Video.Profile"),
    }


def wdr_fields(back, ch, scene):
    mode = g(back, f"VideoInBacklight[{ch}][{scene}].Mode")
    level = g(back, f"VideoInBacklight[{ch}][{scene}].WideDynamicRange")
    if mode.lower() == "widedynamic":
        return "WDR", level
    return (mode or "n/a"), "Off"


def collect(dev, user, password):
    """Log in to one device. -> (rows, state, detail)
    state: 'ok' (rows = one per video channel) | 'skipped' | 'auth' | 'error'."""
    c = CameraClient(dev, user, password)
    base = {col: "" for col in COLUMNS}
    base["IP Address"], base["Port"], base["Network Adapter"] = dev.ip, dev.port, dev.adapter
    try:
        sn = c.kv("magicBox.cgi?action=getSerialNo")          # first call = login test
        dev_class = g(c.opt_kv("magicBox.cgi?action=getDeviceClass"), "class")
        model = g(c.opt_kv("magicBox.cgi?action=getDeviceType"), "type")
        vendor = g(c.opt_kv("magicBox.cgi?action=getVendor"), "vendor")

        ok, why = classify(dev_class, model, vendor)
        if not ok:                                              # NVR / DVR / other brand ...
            return [], "skipped", why

        base["Serial Number"] = g(sn, "sn")
        base["Model"], base["Device Class"], base["Vendor"] = model, dev_class, vendor
        base["Device Name"] = g(c.opt_kv("magicBox.cgi?action=getMachineName"), "name")
        fw, build = parse_firmware(g(c.opt_kv("magicBox.cgi?action=getSoftwareVersion"), "version"))
        base["Firmware Version"], base["Build Date"] = fw, build
        base["Hardware Version"] = g(c.opt_kv("magicBox.cgi?action=getHardwareVersion"), "version")
        t0 = datetime.now()
        raw_time = g(c.opt_kv("global.cgi?action=getCurrentTime"), "result")
        t1 = datetime.now()
        dev_dt = parse_dev_time(raw_time)
        if dev_dt:
            off = calc_offset(dev_dt, t0, t1)
            base["Device Time"], base["Time Diff vs PC (s)"], base["_offset"] = fmt_time(dev_dt), f"{off:+.0f}", off
        else:
            base["Device Time"] = raw_time
        base["ONVIF Version"] = g(c.opt_kv("IntervideoManager.cgi?action=getVersion&Name=Onvif"), "version")
        base["SNMP v3"] = snmp_v3_support(c, dev.ip)

        net = c.opt_cfg("Network")
        iface = g(net, "Network.DefaultInterface", "eth0")
        base["MAC Address"] = g(net, f"Network.{iface}.PhysicalAddress")
        base["Subnet Mask"] = g(net, f"Network.{iface}.SubnetMask")
        base["Gateway"] = g(net, f"Network.{iface}.DefaultGateway")
        dhcp = g(net, f"Network.{iface}.DhcpEnable")
        base["DHCP"] = {"true": "Yes", "false": "No"}.get(dhcp.lower(), dhcp)

        ntp = c.opt_cfg("NTP")
        ntp_on = g(ntp, "NTP.Enable")
        base["NTP Enabled"] = {"true": "Yes", "false": "No"}.get(ntp_on.lower(), ntp_on)
        base["NTP Server"] = g(ntp, "NTP.Address")
        base["NTP Tolerance (s)"] = g(ntp, "NTP.Tolerance")
        tz = g(ntp, "NTP.TimeZone")
        base["Time Zone"] = TZ_NAMES.get(int(tz), tz) if tz.lstrip("-").isdigit() else tz

        titles = c.opt_cfg("ChannelTitle")
        enc = c.opt_cfg("Encode")
        smart = c.opt_cfg("SmartEncode")
        back = c.opt_cfg("VideoInBacklight")
        dn = c.opt_cfg("VideoInDayNight")
        expo = c.opt_cfg("VideoInExposure")
        color = c.opt_cfg("VideoColor")
    except AuthError as e:
        return [], "auth", str(e)
    except requests.exceptions.RequestException as e:
        return [], "error", f"Unreachable: {type(e).__name__}"
    except Exception as e:
        return [], "error", f"Error: {e}"

    channels = sorted({int(m.group(1)) for k in enc for m in [re.match(r"encode\[(\d+)\]\.", k)] if m}) or [0]
    rows = []
    for ch in channels:
        r = dict(base)
        r["Channel"] = ch + 1
        r["Camera Name"] = g(titles, f"ChannelTitle[{ch}].Name") or base["Device Name"]
        for sname, (kind, idx) in zip(STREAM_NAMES, [("MainFormat", 0), ("ExtraFormat", 0),
                                                     ("ExtraFormat", 1), ("ExtraFormat", 2)]):
            info = stream_info(enc, ch, kind, idx)
            if info:
                for f, v in info.items():
                    r[f"{sname} {f}"] = v
        se = g(smart, f"SmartEncode[{ch}].Enable")
        r["Smart Codec (Main)"] = {"true": "On", "false": "Off"}.get(se.lower(), se)
        r["WDR Mode (Day)"], r["WDR % (Day)"] = wdr_fields(back, ch, 0)
        r["WDR Mode (Night)"], r["WDR % (Night)"] = wdr_fields(back, ch, 1)
        r["Day/Night Mode"] = g(dn, f"VideoInDayNight[{ch}][0].Mode")
        em = g(expo, f"VideoInExposure[{ch}][0].Mode")
        r["Exposure Mode"] = EXPOSURE_MODES.get(em, em)
        af = g(expo, f"VideoInExposure[{ch}][0].AntiFlicker")
        r["Anti-Flicker"] = ANTI_FLICKER.get(af, af)
        r["Brightness"] = g(color, f"VideoColor[{ch}][0].Brightness")
        r["Contrast"] = g(color, f"VideoColor[{ch}][0].Contrast")
        r["Saturation"] = g(color, f"VideoColor[{ch}][0].Saturation")
        r["Status"] = "OK"
        rows.append(r)
    return rows, "ok", ""


RESULT_TEXT = {"skipped": "Excluded", "auth": "Login failed", "error": "Error"}


def fetch_all(devices, user, password, cb=lambda *a: None):
    """-> (camera_rows, excluded). Only verified Dahua IP cameras end up in camera_rows."""
    rows, excluded = [], []
    done = 0
    with ThreadPoolExecutor(max_workers=32) as ex:
        futs = {ex.submit(collect, d, user, password): d for d in devices}
        for f in as_completed(futs):
            d = futs[f]
            done += 1
            try:
                r, state, detail = f.result()
            except Exception as e:  # defensive
                r, state, detail = [], "error", f"Error: {e}"
            if state == "ok":
                rows.extend(r)
                say(cb, f"{d.ip}: IP camera OK ({r[0]['Model']}, {r[0]['Serial Number']})")
                for row in r:
                    LOG.info("CAMERA %s", json.dumps({k: v for k, v in row.items() if k in COLUMNS and v not in ("", None)},
                                                     ensure_ascii=False))
            else:
                excluded.append({"IP Address": d.ip, "Port": d.port, "Network Adapter": d.adapter,
                                 "Result": RESULT_TEXT.get(state, state), "Detail": detail})
                say(cb, f"{d.ip}: not included - {detail}")
            cb("progress", done, len(devices))
    rows.sort(key=lambda r: (ip_sort_key(r["IP Address"]), r.get("Channel") or 0))
    excluded.sort(key=lambda r: ip_sort_key(r["IP Address"]))
    return rows, excluded


# --------------------------------------------------------------------------- #
# Excel export
# --------------------------------------------------------------------------- #
def export_xlsx(rows, excluded, adapters_scanned, path, columns=None):
    from openpyxl import Workbook
    from openpyxl.styles import Alignment, Font, PatternFill
    from openpyxl.utils import get_column_letter

    cols = [c for c in COLUMNS if columns is None or c in columns]
    wb = Workbook()
    ws = wb.active
    ws.title = "Cameras"
    ws.append(cols)
    for r in rows:
        ws.append([r.get(c, "") for c in cols])

    head_fill = PatternFill("solid", fgColor="1F3864")
    for cell in ws[1]:
        cell.font = Font(bold=True, color="FFFFFF")
        cell.fill = head_fill
        cell.alignment = Alignment(wrap_text=True, vertical="center", horizontal="center")
    ws.row_dimensions[1].height = 32
    center = Alignment(horizontal="center", vertical="center")
    for row in ws.iter_rows(min_row=2):
        for cell in row:
            cell.alignment = center
    ws.freeze_panes = "D2"
    ws.auto_filter.ref = ws.dimensions

    tints = {"Main": "DDEBF7", "Sub1": "E2EFDA", "Sub2": "FFF2CC", "Sub3": "FCE4D6"}
    for ci, name in enumerate(cols, start=1):
        for s, color in tints.items():
            if name.startswith(s + " "):
                for ri in range(2, ws.max_row + 1):
                    ws.cell(row=ri, column=ci).fill = PatternFill("solid", fgColor=color)
    for ci, name in enumerate(cols, start=1):
        longest = max([len(str(name))] + [len(str(ws.cell(row=ri, column=ci).value or ""))
                                          for ri in range(2, ws.max_row + 1)])
        ws.column_dimensions[get_column_letter(ci)].width = min(max(10, longest + 2), 42)

    # ---- Scan Info ----
    ws2 = wb.create_sheet("Scan Info")
    bold = Font(bold=True)
    cam_ips = {r["IP Address"] for r in rows}
    ws2.append(["Generated by", f"{APP_NAME} v{__version__}"])
    ws2.append(["Generated", datetime.now().strftime("%Y-%m-%d %H:%M:%S")])
    ws2.append(["Dahua IP cameras exported", len(cam_ips)])
    ws2.append(["Devices not included (see below)", len(excluded)])
    ws2.append([])
    ws2.append(["Network adapters scanned"])
    ws2["A6"].font = bold
    ws2.append(["Adapter", "Scan range", "IP cameras found", "Other devices not included"])
    for cell in ws2[7]:
        cell.font = bold
    for a in adapters_scanned:
        label, rng = a["label"], a["range"]
        ws2.append([label, rng,
                    len({r["IP Address"] for r in rows if r["Network Adapter"] == label}),
                    sum(1 for e in excluded if e["Network Adapter"] == label)])
    ws2.append([])
    start = ws2.max_row + 1
    ws2.append(["Devices that answered like Dahua but are NOT in the Cameras sheet"])
    ws2.cell(row=start, column=1).font = bold
    ws2.append(["IP Address", "Port", "Network Adapter", "Result", "Detail"])
    for cell in ws2[ws2.max_row]:
        cell.font = bold
    for e in excluded:
        ws2.append([e["IP Address"], e["Port"], e["Network Adapter"], e["Result"], e["Detail"]])
    for col, w in zip("ABCDE", (34, 24, 30, 26, 70)):
        ws2.column_dimensions[col].width = w

    wb.properties.title = f"Dahua IP cameras - {APP_NAME} v{__version__}"
    wb.properties.creator = f"{APP_NAME} v{__version__}"
    wb.save(path)
    return path


# --------------------------------------------------------------------------- #
# Web interface + snapshots
# --------------------------------------------------------------------------- #
def device_url(dev):
    """Address of the camera's web interface (default ports are left out)."""
    default = (dev.scheme == "http" and dev.port == 80) or (dev.scheme == "https" and dev.port == 443)
    return f"{dev.scheme}://{dev.ip}" + ("" if default else f":{dev.port}")


def open_folder(path):
    try:
        if sys.platform.startswith("win"):
            os.startfile(path)  # type: ignore[attr-defined]
        elif sys.platform == "darwin":
            os.system(f'open "{path}"')
        else:
            os.system(f'xdg-open "{path}" >/dev/null 2>&1 &')
    except Exception:
        pass


def add_name_overlay(jpeg_bytes, text):
    """Write the camera name small in the bottom-right corner. -> (jpeg bytes, (w, h))."""
    import io
    from PIL import Image, ImageDraw, ImageFont
    im = Image.open(io.BytesIO(jpeg_bytes)).convert("RGB")
    w, h = im.size
    size = max(14, int(h * 0.024))
    font = None
    for name in ("segoeui.ttf", "arial.ttf", "DejaVuSans.ttf",
                 "/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf", "Helvetica.ttc"):
        try:
            font = ImageFont.truetype(name, size)
            break
        except OSError:
            continue
    if font is None:
        try:
            font = ImageFont.load_default(size=size)
        except TypeError:
            font = ImageFont.load_default()
    layer = Image.new("RGBA", im.size, (0, 0, 0, 0))
    d = ImageDraw.Draw(layer)
    bb = d.textbbox((0, 0), text, font=font)
    tw, th = bb[2] - bb[0], bb[3] - bb[1]
    pad, margin = int(size * 0.45), int(h * 0.018)
    x1, y1 = w - margin, h - margin
    x0, y0 = x1 - tw - 2 * pad, y1 - th - 2 * pad
    d.rounded_rectangle([x0, y0, x1, y1], radius=pad, fill=(0, 0, 0, 140))
    d.text((x0 + pad - bb[0], y0 + pad - bb[1]), text, font=font, fill=(255, 255, 255, 255))
    out = Image.alpha_composite(im.convert("RGBA"), layer).convert("RGB")
    buf = io.BytesIO()
    out.save(buf, "JPEG", quality=95, subsampling=0)
    return buf.getvalue(), (w, h)


def _safe_name(text):
    return re.sub(r'[\\/:*?"<>|]+', "_", text).strip()


def snapshot_one(t, out_dir):
    """t: dict(dev, creds, channel, name, serial, multi, main_res). -> (ok, message, path)"""
    dev = t["dev"]
    try:
        raw = CameraClient(dev, *t["creds"], timeout=20).snapshot(t["channel"])
    except AuthError as e:
        return False, f"{dev.ip}: {e}", None
    except Exception as e:
        return False, f"{dev.ip}: snapshot failed - {e}", None
    note = ""
    try:
        data, (w, h) = add_name_overlay(raw, t["name"] or t["serial"])
    except ImportError:
        data, (w, h) = raw, (0, 0)
        note = " (no name overlay: install Pillow with 'pip install pillow')"
    except Exception as e:
        data, (w, h) = raw, (0, 0)
        note = f" (overlay failed: {e})"
    if w and t.get("main_res") and f"{w}x{h}" != t["main_res"].lower().replace(" ", ""):
        note += f" [image {w}x{h}, main stream is {t['main_res']}]"
    stamp = datetime.now().strftime("%Y-%m-%d %H%M%S")
    base = _safe_name(f"{stamp} {t['serial']}" + (f" ch{t['channel']}" if t["multi"] else ""))
    path, n = os.path.join(out_dir, base + ".jpg"), 2
    while os.path.exists(path):
        path = os.path.join(out_dir, f"{base} ({n}).jpg")
        n += 1
    with open(path, "wb") as f:
        f.write(data)
    return True, f"{dev.ip}: saved {os.path.basename(path)}{note}", path


def take_snapshots(targets, out_dir, cb=lambda *a: None):
    os.makedirs(out_dir, exist_ok=True)
    ok = fail = done = 0
    with ThreadPoolExecutor(max_workers=8) as ex:
        futs = [ex.submit(snapshot_one, t, out_dir) for t in targets]
        for f in as_completed(futs):
            good, msg, _ = f.result()
            ok, fail, done = ok + good, fail + (not good), done + 1
            say(cb, msg)
            cb("progress", done, len(targets))
    return ok, fail


# --------------------------------------------------------------------------- #
# Device clock: read / synchronise
# --------------------------------------------------------------------------- #
SYNC_TOLERANCE = 2.5      # seconds: the camera reports whole seconds, so +-2 s is "in sync"


def read_offsets(targets):
    """-> {ip: seconds the camera clock is ahead of this PC} for every camera that answers."""
    def one(t):
        try:
            return t["dev"].ip, CameraClient(t["dev"], *t["creds"], timeout=8).get_time()[1]
        except Exception:
            return t["dev"].ip, None
    with ThreadPoolExecutor(max_workers=16) as ex:
        res = dict(ex.map(one, targets))
    return {k: v for k, v in res.items() if v is not None}


SYNC_READ_DELAYS = (0.7, 1.5, 2.5)    # seconds to wait before each read-back of the camera clock


def sync_one(t, with_tz=False):
    """Set one camera's clock to the PC time and VERIFY it (read back several times, one automatic
    second attempt). -> (state, ip, message, new_offset)
    state: 'ok' (in sync) | 'warn' (accepted but the clock did not move) | 'fail'"""
    dev = t["dev"]
    readings, attempts, tz_note = [], 0, ""
    try:
        c = CameraClient(dev, *t["creds"], timeout=10)
        before = c.get_time()[1]
        if with_tz:                                  # set the time zone FIRST: the camera reads the new time in it
            idx, tz_text = pc_tz_index()
            if idx is None:
                return "fail", dev.ip, f"{dev.ip}: time zone {tz_text} of this PC is not available on the camera", None
            old = g(c.opt_cfg("NTP"), "NTP.TimeZone")
            if old != str(idx):
                c.set_cfg({"NTP.TimeZone": idx})
                back = g(c.opt_cfg("NTP"), "NTP.TimeZone")
                if back != str(idx):
                    return "fail", dev.ip, (f"{dev.ip}: time zone not changed (wanted {tz_text}, camera kept "
                                            f"{TZ_NAMES.get(int(back), back) if back.isdigit() else back or '?'})"), None
                tz_note = f", time zone {TZ_NAMES.get(int(old), old) if old.isdigit() else old or '?'} -> {tz_text}"
            else:
                tz_note = f", time zone already {tz_text}"
        for attempts in (1, 2):
            now = datetime.now()
            target = now.replace(microsecond=0) + timedelta(seconds=1 if now.microsecond >= 500000 else 0)
            c.set_time(target)                       # raises if the camera does not answer exactly 'OK'
            for delay in SYNC_READ_DELAYS:
                time.sleep(delay)                    # some cameras apply the new time a moment later
                readings.append(c.get_time()[1])
                if abs(readings[-1]) <= SYNC_TOLERANCE:
                    break
            if abs(readings[-1]) <= SYNC_TOLERANCE:
                break
        after = readings[-1]
    except AuthError as e:
        return "fail", dev.ip, f"{dev.ip}: time sync refused - {e}", None
    except Exception as e:
        return "fail", dev.ip, f"{dev.ip}: time sync failed - {e}", None
    if abs(after) <= SYNC_TOLERANCE:
        return "ok", dev.ip, f"{dev.ip}: in sync with the PC (was {before:+.0f} s, now {after:+.0f} s{tz_note})", after
    seq = ", ".join(f"{r:+.0f}" for r in readings)
    why = ("the camera accepted the change (reply 'OK') but its clock did not move - it may be kept in time by "
           "an NVR/recorder or another time service (check the NVR's time-sync option)")
    try:
        ntp = c.cfg("NTP")
        if g(ntp, "NTP.Enable").lower() == "true":
            why = (f"NTP is enabled on this camera (server {g(ntp, 'NTP.Address') or '?'}, "
                   f"tolerance {g(ntp, 'NTP.Tolerance') or '?'} s) so it follows its NTP server - "
                   "check that server/time zone or disable NTP on the camera")
    except Exception:
        pass
    return "warn", dev.ip, (f"{dev.ip}: clock still {after:+.0f} s off after {attempts} attempt(s) "
                            f"(was {before:+.0f} s; read-backs: {seq} s) - {why}"), after


def sync_times(targets, cb=lambda *a: None, with_tz=False):
    """Set every camera's clock to this PC's time. -> ({ip: new offset}, summary dict)"""
    offsets, done = {}, 0
    summary = {"ok": 0, "warn": 0, "fail": 0, "problems": []}
    with ThreadPoolExecutor(max_workers=8) as ex:
        futs = [ex.submit(sync_one, t, with_tz) for t in targets]
        for f in as_completed(futs):
            state, ip, msg, off = f.result()
            done += 1
            summary[state] += 1
            if state != "ok":
                summary["problems"].append(msg)
            (LOG.info if state == "ok" else LOG.warning)(msg)
            cb("log", msg)
            cb("progress", done, len(targets))
            if off is not None:
                offsets[ip] = off
    say(cb, f"Time sync finished: {summary['ok']} in sync, {summary['warn']} still off, "
            f"{summary['fail']} failed (of {len(targets)}).")
    return offsets, summary


# --------------------------------------------------------------------------- #
# Changing camera settings: names and stream parameters
# --------------------------------------------------------------------------- #
RES_NAMES = {"D1": "704x576", "HD1": "352x576", "BCIF": "704x288", "2CIF": "704x288", "CIF": "352x288",
             "QCIF": "176x144", "NHD": "640x360", "VGA": "640x480", "QVGA": "320x240", "SVCD": "480x480",
             "QQVGA": "160x128", "SVGA": "800x592", "SVGA1": "800x600", "WVGA": "800x480", "FWVGA": "854x480",
             "DVGA": "960x640", "XVGA": "1024x768", "WXGA": "1280x800", "WXGA2": "1280x768", "WXGA3": "1280x854",
             "WXGA4": "1366x768", "SXGA": "1280x1024", "SXGA+": "1400x1050", "WSXGA": "1600x1024",
             "UXGA": "1600x1200", "WUXGA": "1920x1200", "ND1": "240x192", "720P": "1280x720", "1080P": "1920x1080",
             "QFHD": "3840x2160", "1_3M": "1280x960", "2_5M": "1872x1408", "5M": "3744x1408", "3M": "2048x1536",
             "5_0M": "2432x2048", "1_2M": "1216x1024", "5_1M": "2560x1920", "960H": "960x576", "DV720P": "960x720"}
STREAM_SLOTS = [("Main", "MainFormat", 0), ("Sub1", "ExtraFormat", 0), ("Sub2", "ExtraFormat", 1),
                ("Sub3", "ExtraFormat", 2)]
STREAM_FIELDS_API = {"Resolution": "resolution", "FPS": "FPS", "Bitrate (kbps)": "BitRate", "Codec": "Compression",
                     "Bitrate Mode": "BitRateControl", "GOP": "GOP"}


def norm_resolution(token):
    """'1080P' / '2048 x 1536' / 'D1' -> '1920x1080' / '2048x1536' / '704x576' (None if unknown)."""
    t = (token or "").strip().replace(" ", "")
    if not t:
        return None
    m = re.fullmatch(r"(\d+)[xX*](\d+)", t)
    if m:
        return f"{int(m.group(1))}x{int(m.group(2))}"
    key = t.upper()
    if key in RES_NAMES:
        return RES_NAMES[key]
    if key in ("720", "1080"):
        return RES_NAMES[key + "P"]
    return None


def _split(text):
    return [t.strip() for t in (text or "").split(",") if t.strip()]


def parse_stream_caps(caps, ch, fmt, idx):
    """What one stream of one camera supports (from encode.cgi?action=getCaps, spec 4.5.2)."""
    out = {"compression": [], "resolutions": [], "bitrate": None, "fpsmax": None}
    for n in (ch, 0):
        p = f"caps[{n}].{fmt}[{idx}].video.".lower()
        if any(k.startswith(p) for k in caps):
            out["compression"] = _split(g(caps, p + "CompressionTypes"))
            out["resolutions"] = [r for r in (norm_resolution(t) for t in _split(g(caps, p + "ResolutionTypes"))) if r]
            nums = re.findall(r"\d+", g(caps, p + "BitRateOptions"))
            if len(nums) >= 2:
                out["bitrate"] = (int(nums[0]), int(nums[-1]))
            fm = g(caps, p + "FPSMax")
            out["fpsmax"] = int(float(fm)) if re.fullmatch(r"\d+(\.\d+)?", fm or "") else None
            break
    return out


def check_stream_value(field, value, cap):
    """-> (value to send to the camera, problem text or '')."""
    v = str(value).strip()
    if field == "Resolution":
        n = norm_resolution(v)
        if not n:
            return v, f"'{v}' is not a valid resolution (use e.g. 1920x1080)"
        if cap["resolutions"] and n not in cap["resolutions"]:
            more = " ..." if len(cap["resolutions"]) > 5 else ""
            return n, "not supported by this camera (it offers: " + ", ".join(cap["resolutions"][:5]) + more + ")"
        return n, ""
    if field == "FPS":
        try:
            f = float(v)
        except ValueError:
            return v, "FPS must be a number"
        if f <= 0:
            return v, "FPS must be greater than 0"
        if cap["fpsmax"] and f > cap["fpsmax"]:
            return v, f"above this camera's maximum of {cap['fpsmax']} fps"
        return (str(int(f)) if f == int(f) else str(f)), ""
    if field == "Bitrate (kbps)":
        if not v.isdigit() or int(v) <= 0:
            return v, "bitrate must be a whole number (kbps)"
        b = int(v)
        if cap["bitrate"] and not (cap["bitrate"][0] <= b <= cap["bitrate"][1]):
            return v, f"outside this camera's range ({cap['bitrate'][0]}-{cap['bitrate'][1]} kbps)"
        return str(b), ""
    if field == "Codec":
        if cap["compression"]:
            match = next((c for c in cap["compression"] if c.upper() == v.upper()), None)
            if not match:
                return v, "not supported by this camera (it offers: " + ", ".join(cap["compression"]) + ")"
            return match, ""
        return v, ""
    if field == "Bitrate Mode":
        if v.upper() not in ("CBR", "VBR"):
            return v, "use CBR or VBR"
        return v.upper(), ""
    if field == "GOP":
        if not v.isdigit() or not 1 <= int(v) <= 100:
            return v, "GOP must be a whole number from 1 to 100"
        return str(int(v)), ""
    return v, "unknown setting"


def same_value(field, a, b):
    """Is the value the camera reports (a) the same as the requested one (b)?"""
    try:
        if field == "Resolution":
            return norm_resolution(a) == norm_resolution(b) and norm_resolution(a) is not None
        if field == "FPS":
            return abs(float(a) - float(b)) < 0.01
        if field in ("Bitrate (kbps)", "GOP"):
            return int(float(a)) == int(float(b))
    except (TypeError, ValueError):
        return False
    return str(a).strip().upper() == str(b).strip().upper()


def plan_camera(t, wanted):
    """Compare the wanted stream settings with what one camera has and supports.
    t: dict(dev, creds, channel, name);  wanted: {slot: {field: value}}  -> list of change dicts."""
    dev, ch = t["dev"], t["channel"] - 1
    c = CameraClient(dev, *t["creds"], timeout=10)
    enc = c.cfg("Encode")
    caps = c.opt_kv("encode.cgi?action=getCaps")
    out = []
    for slot, fmt, idx in STREAM_SLOTS:
        if slot not in wanted:
            continue
        exists = any(k.startswith(f"Encode[{ch}].{fmt}[{idx}].".lower()) for k in enc)
        cap = parse_stream_caps(caps, ch, fmt, idx)
        for field, value in wanted[slot].items():
            key = f"Encode[{ch}].{fmt}[{idx}].Video.{STREAM_FIELDS_API[field]}"
            row = {"ip": dev.ip, "channel": t["channel"], "name": t.get("name", ""), "slot": slot, "field": field,
                   "key": key, "old": g(enc, key), "new": str(value), "send": None, "status": "ok", "detail": ""}
            if not exists:
                row.update(status="bad", detail="this stream does not exist on the camera")
            else:
                send, problem = check_stream_value(field, value, cap)
                if problem:
                    row.update(status="bad", detail=problem)
                elif same_value(field, row["old"], send):
                    row.update(status="same", detail="already set")
                else:
                    row["send"] = send
            out.append(row)
    return out


def preview_stream_changes(targets, wanted, cb=lambda *a: None):
    """Read capabilities + current values of every target and build the change list (nothing is written)."""
    rows, done = [], 0

    def one(t):
        try:
            return plan_camera(t, wanted)
        except Exception as e:
            LOG.warning("%s: could not read the stream settings - %s", t["dev"].ip, e)
            return [{"ip": t["dev"].ip, "channel": t["channel"], "name": t.get("name", ""), "slot": "-",
                     "field": "-", "key": "", "old": "", "new": "", "send": None, "status": "bad",
                     "detail": f"could not read the camera: {e}"}]
    with ThreadPoolExecutor(max_workers=8) as ex:
        for part in ex.map(one, targets):
            rows.extend(part)
            done += 1
            cb("progress", done, len(targets))
    order = {s[0]: i for i, s in enumerate(STREAM_SLOTS)}
    rows.sort(key=lambda r: (ip_sort_key(r["ip"]), r["channel"], order.get(r["slot"], 9)))
    LOG.info("Stream preview: %d change(s) ready, %d already set, %d not possible",
             sum(r["status"] == "ok" for r in rows), sum(r["status"] == "same" for r in rows),
             sum(r["status"] == "bad" for r in rows))
    return rows


def _apply_group(t, group):
    """Write all pending changes of one camera channel with ONE request, then read them back."""
    dev = t["dev"]
    params = {r["key"]: r["send"] for r in group}
    try:
        c = CameraClient(dev, *t["creds"], timeout=15)
        c.set_cfg(params)                     # raises unless the camera answers exactly 'OK'
        time.sleep(0.6)
        enc = c.cfg("Encode")
    except Exception as e:
        for r in group:
            r.update(status="fail", detail=str(e))
        LOG.warning("%s ch%s: stream change failed - %s", dev.ip, t["channel"], e)
        return
    for r in group:
        got = g(enc, r["key"])
        r["got"] = got
        if same_value(r["field"], got, r["send"]):
            r.update(status="done", detail="applied and confirmed")
        else:
            r.update(status="adjusted", detail=f"the camera stored {got!r} instead")
        LOG.info("STREAM-CHANGE %s ch%s %s %s: %r -> %r (%s)", dev.ip, r["channel"], r["slot"], r["field"],
                 r["old"], r["send"], r["status"])


def apply_stream_changes(targets, rows, cb=lambda *a: None):
    """Apply every row with status 'ok'. -> list of undo entries for the rows that were written."""
    by_t = {(t["dev"].ip, t["channel"]): t for t in targets}
    groups = {}
    for r in rows:
        if r["status"] == "ok" and (r["ip"], r["channel"]) in by_t:
            groups.setdefault((r["ip"], r["channel"]), []).append(r)
    done = 0
    with ThreadPoolExecutor(max_workers=8) as ex:
        futs = [ex.submit(_apply_group, by_t[k], grp) for k, grp in groups.items()]
        for f in as_completed(futs):
            f.result()
            done += 1
            cb("progress", done, len(futs))
    return [{"ip": r["ip"], "channel": r["channel"], "slot": r["slot"], "field": r["field"], "key": r["key"],
             "old": r["old"]} for r in rows if r["status"] in ("done", "adjusted") and r["old"] != ""]


def undo_stream_changes(targets, entries, cb=lambda *a: None):
    """Write the previous values back. -> (restored, failed)"""
    by_t = {(t["dev"].ip, t["channel"]): t for t in targets}
    groups = {}
    for e in entries:
        groups.setdefault((e["ip"], e["channel"]), []).append(e)
    ok = bad = 0
    for k, grp in groups.items():
        t = by_t.get(k)
        if not t:
            bad += len(grp)
            continue
        try:
            c = CameraClient(t["dev"], *t["creds"], timeout=15)
            c.set_cfg({e["key"]: e["old"] for e in grp})
            ok += len(grp)
            LOG.info("STREAM-UNDO %s ch%s restored %d value(s)", k[0], k[1], len(grp))
        except Exception as ex:
            bad += len(grp)
            LOG.warning("STREAM-UNDO %s ch%s failed - %s", k[0], k[1], ex)
        cb("progress", ok + bad, sum(len(v) for v in groups.values()))
    return ok, bad


def check_name(name, what):
    n = (name or "").strip()
    if not n:
        return "", f"{what} cannot be empty"
    if len(n) > 64:
        return n, f"{what} is too long (maximum 64 characters)"
    if any(ord(ch) < 32 for ch in n):
        return n, f"{what} contains control characters"
    return n, ""


def rename_camera(t, camera_name=None, device_name=None):
    """Write the camera (video channel) title and / or the device name and read them back.
    -> list of (what, ok, message)"""
    dev, ch = t["dev"], t["channel"] - 1
    c = CameraClient(dev, *t["creds"], timeout=12)
    results = []
    jobs = []
    if camera_name is not None:
        jobs.append(("Camera name", {f"ChannelTitle[{ch}].Name": camera_name}, "ChannelTitle",
                     f"ChannelTitle[{ch}].Name"))
    if device_name is not None:
        jobs.append(("Device name", {"General.MachineName": device_name}, "General", "General.MachineName"))
    for what, params, section, key in jobs:
        value = next(iter(params.values()))
        try:
            before = g(c.cfg(section), key)
            c.set_cfg(params)
            after = g(c.cfg(section), key)
        except Exception as e:
            results.append((what, False, str(e)))
            LOG.warning("%s: %s change failed - %s", dev.ip, what, e)
            continue
        if after == value:
            results.append((what, True, f"changed from {before!r} to {after!r}"))
        else:
            results.append((what, False, f"the camera stored {after!r} instead of {value!r}"))
        LOG.info("RENAME %s ch%s %s: %r -> %r (camera now has %r)", dev.ip, t["channel"], what, before, value, after)
    return results


# --------------------------------------------------------------------------- #
# Themes
# --------------------------------------------------------------------------- #
LIGHT = dict(bg="#eef1f6", card="#ffffff", text="#1b2433", sub="#5b6b82", title="#1f3864", border="#d3dae6",
             accent="#1f3864", accent_h="#2b4c87", accent_fg="#ffffff", btn_bg="#e8ecf3", btn_h="#d9e1ee",
             entry_bg="#ffffff", head_bg="#1f3864", head_h="#2b4c87", head_fg="#ffffff", tree_bg="#ffffff",
             tree_sel="#bcd0f0", ok="#e6f4ea", bad="#fde7e7", pend="#fff8e1", trough="#eaeff6", thumb="#b9c4d8",
             thumb_h="#7f90ad", log_bg="#fbfcfe", track="#c7d2e5", knob="#ffffff", icon="#f59e0b",
             disabled="#9aa7bd")
DARK = dict(bg="#0e1420", card="#161f31", text="#e6ecf7", sub="#8fa0bd", title="#9cc0ff", border="#27344f",
            accent="#3b82f6", accent_h="#5b9aff", accent_fg="#ffffff", btn_bg="#222f48", btn_h="#2c3c5c",
            entry_bg="#0e1420", head_bg="#22314f", head_h="#2c3f66", head_fg="#e6ecf7", tree_bg="#161f31",
            tree_sel="#2b4a85", ok="#143626", bad="#44202a", pend="#463d17", trough="#1c2840", thumb="#3a4e75",
            thumb_h="#5873a6", log_bg="#0e1420", track="#2b3a58", knob="#e6ecf7", icon="#93c5fd",
            disabled="#52617d")


def _hex_to_rgb(h):
    h = h.lstrip("#")
    return int(h[0:2], 16), int(h[2:4], 16), int(h[4:6], 16)


def lerp_hex(a, b, t):
    ra, rb = _hex_to_rgb(a), _hex_to_rgb(b)
    return "#%02x%02x%02x" % tuple(int(round(x + (y - x) * t)) for x, y in zip(ra, rb))


def lerp_palette(p1, p2, t):
    return {k: lerp_hex(p1[k], p2[k], t) for k in p1}


# --------------------------------------------------------------------------- #
# Table fields (what the Settings page lets the user show / hide)
# --------------------------------------------------------------------------- #
FIELD_GROUPS = [
    ("Identity", ["Status", "Camera Name", "Device Name", "Model", "Device Class", "Serial Number",
                  "Firmware Version", "Build Date", "Hardware Version", "Vendor", "ONVIF Version"]),
    ("Device clock", ["Device Time", "Time Diff vs PC (s)", "Time Zone", "NTP Enabled", "NTP Server",
                       "NTP Tolerance (s)"]),
    ("Network", ["Network Adapter", "Port", "Channel", "MAC Address", "DHCP", "Subnet Mask", "Gateway", "SNMP v3"]),
    ("Main stream", [f"Main {f}" for f in STREAM_FIELDS]),
    ("Sub stream 1", [f"Sub1 {f}" for f in STREAM_FIELDS]),
    ("Sub stream 2", [f"Sub2 {f}" for f in STREAM_FIELDS]),
    ("Sub stream 3", [f"Sub3 {f}" for f in STREAM_FIELDS]),
    ("Image & WDR", ["Smart Codec (Main)", "WDR Mode (Day)", "WDR % (Day)", "WDR Mode (Night)",
                     "WDR % (Night)", "Day/Night Mode", "Exposure Mode", "Anti-Flicker",
                     "Brightness", "Contrast", "Saturation"]),
]
TABLE_FIELDS = [f for _, fs in FIELD_GROUPS for f in fs]          # canonical table order
DEFAULT_VISIBLE = ["Status", "Camera Name", "Model", "Serial Number", "Firmware Version", "Build Date",
                   "Device Time", "Time Diff vs PC (s)", "Network Adapter", "Main Resolution", "Main FPS",
                   "Main Bitrate (kbps)", "Sub1 Resolution", "Sub1 FPS", "Sub1 Bitrate (kbps)", "WDR % (Day)"]
FIELD_WIDTH = {"Status": 220, "Camera Name": 150, "Device Name": 150, "Model": 170, "Serial Number": 150,
               "Firmware Version": 210, "Build Date": 100, "Hardware Version": 120, "Network Adapter": 190,
               "Device Time": 160, "Time Diff vs PC (s)": 125, "Time Zone": 110, "NTP Enabled": 105, "NTP Server": 150,
               "NTP Tolerance (s)": 130, "MAC Address": 140, "Subnet Mask": 120,
               "Gateway": 120, "SNMP v3": 90, "Vendor": 90, "ONVIF Version": 110, "Smart Codec (Main)": 140}


def field_heading(name):
    return (name.replace("Resolution", "Res.").replace("Bitrate (kbps)", "Bitrate (kbps)")
            .replace("Time Diff vs PC (s)", "Time Diff vs PC"))


# --------------------------------------------------------------------------- #
# GUI
# --------------------------------------------------------------------------- #
def run_gui(history=None):
    import math
    import tkinter as tk
    import webbrowser
    from tkinter import filedialog, messagebox, ttk

    try:                                    # crisp text on Windows high-DPI screens
        import ctypes
        ctypes.windll.shcore.SetProcessDpiAwareness(1)
    except Exception:
        pass

    ON, OFF = "\u2611", "\u2610"            # ONE checkbox look everywhere
    FONT, BOLD = ("Segoe UI", 10), ("Segoe UI", 10, "bold")
    WEB_TEXT = "\U0001F310 Open"

    # ------------------------------------------------------------------ widgets
    class TickBox(tk.Label):
        """Stand-alone checkbox with the same glyphs as the table checkboxes."""
        def __init__(self, parent, text, variable, command=None, p=LIGHT, bg_key="card"):
            super().__init__(parent, font=FONT, cursor="hand2", anchor="w")
            self.text, self.var, self.command, self.bg_key = text, variable, command, bg_key
            self.p = p
            self.bind("<Button-1>", self._toggle)
            self.var.trace_add("write", lambda *_: self._render())
            self.retheme(p)

        def retheme(self, p):
            self.p = p
            self.configure(bg=p[self.bg_key], fg=p["text"])
            self._render()

        def _render(self):
            self.configure(text=f"{ON if self.var.get() else OFF}  {self.text}")

        def _toggle(self, _event=None):
            self.var.set(not self.var.get())
            if self.command:
                self.command()

    class CheckGroup:
        """Tick-box behaviour for a Treeview whose first displayed column is the checkbox."""
        def __init__(self, tree, on_change):
            self.tree, self.on_change, self.checked = tree, on_change, {}
            tree.bind("<Button-1>", self._click, add="+")
            tree.bind("<space>", self._space)

        def refresh(self, iid):
            vals = list(self.tree.item(iid, "values"))
            vals[0] = ON if self.checked.get(iid) else OFF
            self.tree.item(iid, values=vals)

        def set_all(self, value):
            for iid in self.tree.get_children():
                self.checked[iid] = value
                self.refresh(iid)
            self.on_change()

        def ticked(self):
            return [i for i in self.tree.get_children() if self.checked.get(i)]

        def _click(self, event):
            if self.tree.identify_column(event.x) != "#1":
                return None
            region = self.tree.identify_region(event.x, event.y)
            if region == "heading":
                ids = self.tree.get_children()
                self.set_all(not (ids and all(self.checked.get(i) for i in ids)))
                return "break"
            if region == "cell":
                iid = self.tree.identify_row(event.y)
                if iid:
                    self.checked[iid] = not self.checked.get(iid, False)
                    self.refresh(iid)
                    self.on_change()
                return "break"
            return None

        def _space(self, _event):
            for iid in self.tree.selection():
                self.checked[iid] = not self.checked.get(iid, False)
                self.refresh(iid)
            self.on_change()
            return "break"

    class ModernScrollbar(tk.Canvas):
        """Slim rounded scrollbar that thickens and lights up on hover."""
        def __init__(self, parent, orient="vertical", command=None, p=LIGHT):
            self.vertical = orient == "vertical"
            super().__init__(parent, width=14 if self.vertical else 1, height=1 if self.vertical else 14,
                             highlightthickness=0, bd=0)
            self.command, self.p = command, p
            self.lo, self.hi = 0.0, 1.0
            self.hover, self.grab, self.thick = 0.0, None, 5.0
            self._anim = None
            self.bind("<Configure>", lambda e: self._draw())
            self.bind("<Enter>", lambda e: self._set_hover(1.0))
            self.bind("<Leave>", lambda e: self._set_hover(0.0) if self.grab is None else None)
            self.bind("<Button-1>", self._press)
            self.bind("<B1-Motion>", self._drag)
            self.bind("<ButtonRelease-1>", self._release)
            self.retheme(p)

        def retheme(self, p):
            self.p = p
            self.configure(bg=p["card"])
            self._draw()

        def set(self, lo, hi):
            self.lo, self.hi = float(lo), float(hi)
            self._draw()

        def _len(self):
            return max(1, self.winfo_height() if self.vertical else self.winfo_width())

        def _thumb(self):
            pad, span = 4, self._len() - 8
            a = pad + self.lo * span
            b = pad + self.hi * span
            if b - a < 30:
                b = min(pad + span, a + 30)
                a = b - 30 if b - a < 30 else a
            return a, b

        def _draw(self):
            self.delete("all")
            p, L = self.p, self._len()
            mid = (self.winfo_width() if self.vertical else self.winfo_height()) / 2
            if self.hi - self.lo >= 0.9999:
                return
            def line(a, b, w, color):
                if self.vertical:
                    self.create_line(mid, a, mid, b, width=w, fill=color, capstyle="round")
                else:
                    self.create_line(a, mid, b, mid, width=w, fill=color, capstyle="round")
            line(5, L - 5, 3 + 2 * self.hover, p["trough"])
            a, b = self._thumb()
            color = lerp_hex(p["thumb"], p["thumb_h"], max(self.hover, 1.0 if self.grab is not None else 0))
            line(a + self.thick / 2, max(a + self.thick / 2, b - self.thick / 2), self.thick, color)

        def _set_hover(self, target):
            if self._anim:
                self.after_cancel(self._anim)

            def step():
                d = target - self.hover
                if abs(d) < 0.08:
                    self.hover = target
                    self._anim = None
                else:
                    self.hover += d * 0.4
                    self._anim = self.after(16, step)
                self.thick = 5.0 + 4.0 * self.hover
                self._draw()
            step()

        def _axis(self, e):
            return e.y if self.vertical else e.x

        def _press(self, e):
            if self.hi - self.lo >= 0.9999:
                return
            a, b = self._thumb()
            pos = self._axis(e)
            if a <= pos <= b:
                self.grab = pos - a
            elif self.command:
                self.command("scroll", -1 if pos < a else 1, "pages")
            self._draw()

        def _drag(self, e):
            if self.grab is None or not self.command:
                return
            span = self._len() - 8
            self.command("moveto", (self._axis(e) - self.grab - 4) / max(1, span))

        def _release(self, _e):
            self.grab = None
            self._draw()

    class ModernProgress(tk.Canvas):
        def __init__(self, parent, p=LIGHT):
            super().__init__(parent, width=200, height=10, highlightthickness=0, bd=0)
            self.p, self.value, self.maximum = p, 0, 1
            self.bind("<Configure>", lambda e: self._draw())
            self.retheme(p)

        def retheme(self, p):
            self.p = p
            self.configure(bg=p["bg"])
            self._draw()

        def set(self, value, maximum):
            self.value, self.maximum = value, max(1, maximum)
            self._draw()

        def _draw(self):
            self.delete("all")
            w, h = self.winfo_width(), self.winfo_height()
            if w < 10:
                return
            self.create_line(5, h / 2, w - 5, h / 2, width=8, fill=self.p["trough"], capstyle="round")
            end = 5 + (w - 10) * min(1.0, self.value / self.maximum)
            if end > 5.5:
                self.create_line(5, h / 2, end, h / 2, width=8, fill=self.p["accent"], capstyle="round")

    class ThemeSwitch(tk.Canvas):
        """Sun / moon pill switch; the knob glides while the whole UI fades between themes."""
        W, H = 64, 30

        def __init__(self, parent, on_toggle, dark=False, p=LIGHT):
            super().__init__(parent, width=self.W, height=self.H, highlightthickness=0, bd=0, cursor="hand2")
            self.on_toggle, self.p, self.dark = on_toggle, p, dark
            self.pos = 1.0 if dark else 0.0
            self._job = None
            self.bind("<Button-1>", lambda e: self.toggle())
            self.retheme(p)

        def retheme(self, p):
            self.p = p
            self.configure(bg=p["bg"])
            self._draw()

        def _draw(self):
            self.delete("all")
            p, W, H = self.p, self.W, self.H
            r = H / 2
            self.create_oval(0, 0, H, H, fill=p["track"], outline="")
            self.create_oval(W - H, 0, W, H, fill=p["track"], outline="")
            self.create_rectangle(r, 0, W - r, H, fill=p["track"], outline="")
            x = 3 + self.pos * (W - H)
            self.create_oval(x, 3, x + H - 6, H - 3, fill=p["knob"], outline="")
            cx, cy = x + (H - 6) / 2 + 0.5, H / 2
            if self.pos < 0.5:                                  # sun
                self.create_oval(cx - 4, cy - 4, cx + 4, cy + 4, fill=p["icon"], outline="")
                for k in range(8):
                    ang = k * math.pi / 4
                    self.create_line(cx + 6.5 * math.cos(ang), cy + 6.5 * math.sin(ang),
                                     cx + 9 * math.cos(ang), cy + 9 * math.sin(ang), fill=p["icon"], width=1.6)
            else:                                               # moon
                self.create_oval(cx - 7, cy - 7, cx + 7, cy + 7, fill=p["icon"], outline="")
                self.create_oval(cx - 1, cy - 8, cx + 10, cy + 4, fill=p["knob"], outline="")

        def toggle(self):
            self.dark = not self.dark
            self.glide(1.0 if self.dark else 0.0)
            self.on_toggle(self.dark)

        def glide(self, target, steps=16):
            if self._job:
                self.after_cancel(self._job)
            start, i = self.pos, 0

            def tick():
                nonlocal i
                i += 1
                u = i / steps
                self.pos = start + (target - start) * (0.5 - 0.5 * math.cos(math.pi * u))
                self._draw()
                self._job = self.after(22, tick) if i < steps else None
            tick()

    # ------------------------------------------------------------------ app
    class App(tk.Tk):
        def __init__(self):
            super().__init__()
            self.settings = load_settings()
            self.title(f"{APP_NAME} v{__version__}")
            w = min(1440, self.winfo_screenwidth() - 40)
            h = min(980, self.winfo_screenheight() - 70)
            self.geometry(f"{w}x{h}+10+10")
            self.minsize(1180, 680)
            self.devices, self.results, self.status_full = [], {}, {}
            self.rejected, self.creds, self.offsets = {}, {}, {}
            self.last_stream_change = None
            set_http_trace(self.settings.get("log_http"))
            self.adapters, self.scanned, self.display = [], [], []
            self.snap_dir = self.settings.get("snap_dir") or os.path.join(os.path.expanduser("~"), "Pictures")
            self.export_dir = self.settings.get("export_dir") or os.path.join(
                os.path.expanduser("~"), "Documents", "HK IP Camera Settings")
            vis = list(self.settings.get("visible") or DEFAULT_VISIBLE)
            if not self.settings.get("snmp_col_added"):        # v1.6.1: show the new column once, user can hide it
                vis.append("SNMP v3")
                self.settings["snmp_col_added"] = True
            self.visible = [f for f in TABLE_FIELDS if f in vis]
            self.q = queue.Queue()
            self.busy, self.themed, self._theme_job = False, [], None
            self.dark = self.settings.get("theme") == "dark"
            self.p = dict(DARK if self.dark else LIGHT)
            self.style = ttk.Style(self)
            self.style.theme_use("clam")
            self._logo()
            self._build()
            self.apply_theme(self.p)
            self.refresh_adapters()
            self.apply_visible()
            self._show_history(history or [])
            for line in system_info(self._screen_info()):
                LOG.info("SYSINFO %s", line)
            LOG.info("Window opened (theme=%s, visible fields=%d)", "dark" if self.dark else "light", len(self.visible))
            self.protocol("WM_DELETE_WINDOW", self.on_close)
            self.after(100, self._poll)
            self.after(1000, self._tick_clock)
            self.after(60000, self._refresh_offsets_job)

        def report_callback_exception(self, exc, val, tb):
            LOG.error("Unhandled error in the window", exc_info=(exc, val, tb))
            self._show(f"Unexpected error: {val} (details are in the log file)")

        # ------------------------------------------------------------ logo / theme
        def _logo(self):
            self.logo = None
            try:
                self.logo = tk.PhotoImage(data=LOGO_PNG_B64)
                self.iconphoto(True, self.logo)
            except Exception:
                pass

        def _reg(self, widget):
            self.themed.append(widget)
            return widget

        def apply_theme(self, p):
            self.p = p
            st = self.style
            self.configure(bg=p["bg"])
            st.configure(".", font=FONT, background=p["bg"], foreground=p["text"])
            st.configure("TFrame", background=p["bg"])
            st.configure("Card.TFrame", background=p["card"])
            st.configure("TLabel", background=p["bg"], foreground=p["text"])
            st.configure("Card.TLabel", background=p["card"], foreground=p["text"])
            st.configure("Muted.TLabel", background=p["card"], foreground=p["sub"])
            st.configure("Sub.TLabel", background=p["bg"], foreground=p["sub"])
            st.configure("Title.TLabel", background=p["bg"], foreground=p["title"], font=("Segoe UI", 16, "bold"))
            st.configure("Summary.TLabel", background=p["card"], foreground=p["title"], font=BOLD)
            st.configure("Field.TLabel", background=p["card"], foreground=p["sub"], font=("Segoe UI", 9))
            st.configure("TLabelframe", background=p["card"], bordercolor=p["border"],
                         lightcolor=p["card"], darkcolor=p["card"])
            st.configure("TLabelframe.Label", background=p["card"], foreground=p["title"], font=BOLD)
            for name, key, fg in (("TButton", "btn_bg", "text"), ("Accent.TButton", "accent", "accent_fg")):
                st.configure(name, background=p[key], foreground=p[fg], bordercolor=p[key],
                             lightcolor=p[key], darkcolor=p[key], focuscolor=p[key], relief="flat")
            st.configure("TButton", padding=(14, 8), bordercolor=p["border"])
            st.configure("Accent.TButton", font=BOLD, padding=(18, 9))
            st.map("TButton", background=[("active", p["btn_h"])], foreground=[("disabled", p["disabled"])])
            st.map("Accent.TButton", background=[("active", p["accent_h"]), ("disabled", p["disabled"])],
                   foreground=[("disabled", p["bg"])])
            st.configure("TEntry", padding=(9, 7), fieldbackground=p["entry_bg"], foreground=p["text"], insertcolor=p["text"],
                         bordercolor=p["border"], lightcolor=p["border"], darkcolor=p["border"])
            st.configure("Treeview", font=FONT, rowheight=34, background=p["tree_bg"], fieldbackground=p["tree_bg"],
                         foreground=p["text"], bordercolor=p["border"], lightcolor=p["tree_bg"], darkcolor=p["tree_bg"])
            st.configure("Treeview.Heading", font=BOLD, background=p["head_bg"], foreground=p["head_fg"],
                         padding=(6, 10), relief="flat", bordercolor=p["head_bg"], lightcolor=p["head_bg"],
                         darkcolor=p["head_bg"])
            st.map("Treeview.Heading", background=[("active", p["head_h"])])
            st.map("Treeview", background=[("selected", p["tree_sel"])], foreground=[("selected", p["text"])])
            st.configure("TCombobox", fieldbackground=p["entry_bg"], background=p["btn_bg"], foreground=p["text"],
                         arrowcolor=p["text"], bordercolor=p["border"], lightcolor=p["border"],
                         darkcolor=p["border"], insertcolor=p["text"])
            st.map("TCombobox", fieldbackground=[("readonly", p["entry_bg"])], foreground=[("readonly", p["text"])],
                   selectbackground=[("readonly", p["entry_bg"])], selectforeground=[("readonly", p["text"])])
            self.option_add("*TCombobox*Listbox.background", p["entry_bg"])
            self.option_add("*TCombobox*Listbox.foreground", p["text"])
            self.option_add("*TCombobox*Listbox.selectBackground", p["accent"])
            self.option_add("*TCombobox*Listbox.selectForeground", p["accent_fg"])
            st.configure("TNotebook", background=p["bg"], bordercolor=p["border"], lightcolor=p["bg"],
                         darkcolor=p["bg"])
            st.configure("TNotebook.Tab", background=p["btn_bg"], foreground=p["text"], padding=(16, 7),
                         bordercolor=p["border"], lightcolor=p["btn_bg"], darkcolor=p["btn_bg"])
            st.map("TNotebook.Tab", background=[("selected", p["card"])], foreground=[("selected", p["title"])])
            for w in self.themed:
                try:
                    w.retheme(p)
                except tk.TclError:
                    pass
            for tree in (getattr(self, "tree", None),):
                if tree is not None:
                    for tag, key in (("ok", "ok"), ("bad", "bad"), ("pending", "pend")):
                        tree.tag_configure(tag, background=p[key])
            if hasattr(self, "log"):
                self.log.configure(bg=p["log_bg"], fg=p["text"], insertbackground=p["text"])
                self.log.tag_configure("hist", foreground=p["sub"])
            if hasattr(self, "menu"):
                self.menu.configure(bg=p["card"], fg=p["text"], activebackground=p["accent"],
                                    activeforeground=p["accent_fg"])

        def on_theme_toggle(self, dark):
            """Fade every colour from the current palette to the new one."""
            self.dark = dark
            self.settings["theme"] = "dark" if dark else "light"
            save_settings(self.settings)
            LOG.info("Theme changed to %s", "dark" if dark else "light")
            target, start, steps, i = (DARK if dark else LIGHT), dict(self.p), 16, 0
            if self._theme_job:
                self.after_cancel(self._theme_job)

            def tick():
                nonlocal i
                i += 1
                u = i / steps
                self.apply_theme(lerp_palette(start, target, 0.5 - 0.5 * math.cos(math.pi * u)))
                self._theme_job = self.after(22, tick) if i < steps else None
            tick()

        # ------------------------------------------------------------ widgets helpers
        def _make_tree(self, parent, cols, height):
            wrap = ttk.Frame(parent, style="Card.TFrame")
            wrap.rowconfigure(0, weight=1)
            wrap.columnconfigure(0, weight=1)
            tree = ttk.Treeview(wrap, columns=[c for c, _, _ in cols], show="headings",
                                selectmode="extended", height=height)
            for cid, text, w in cols:
                tree.heading(cid, text=text, anchor="center")
                tree.column(cid, width=w, minwidth=(46 if cid == "sel" else 40), anchor="center", stretch=False)
            ys = self._reg(ModernScrollbar(wrap, "vertical", tree.yview, self.p))
            xs = self._reg(ModernScrollbar(wrap, "horizontal", tree.xview, self.p))
            tree.configure(yscrollcommand=ys.set, xscrollcommand=xs.set)
            tree.grid(row=0, column=0, sticky="nsew")
            ys.grid(row=0, column=1, sticky="ns")
            xs.grid(row=1, column=0, sticky="ew")
            return wrap, tree

        def _tick(self, parent, text, var, command=None, bg_key="card"):
            return self._reg(TickBox(parent, text, var, command, self.p, bg_key))

        # ------------------------------------------------------------ layout
        def _build(self):
            head = ttk.Frame(self, padding=(14, 10, 14, 2))
            head.pack(fill="x")
            if self.logo:
                self.logo_small = self.logo.subsample(3, 3)
                self._reg_lbl = tk.Label(head, image=self.logo_small)
                self._reg_lbl.retheme = lambda p: self._reg_lbl.configure(bg=p["bg"])
                self._reg(self._reg_lbl).pack(side="left", padx=(0, 10))
            ttk.Label(head, text=APP_NAME, style="Title.TLabel").pack(side="left")
            ttk.Label(head, text=f"v{__version__}", style="Sub.TLabel").pack(side="left", padx=(6, 0), pady=(8, 0))
            self.switch = self._reg(ThemeSwitch(head, self.on_theme_toggle, self.dark, self.p))
            self.switch.pack(side="right")
            ttk.Label(head, text="Dark mode", style="Sub.TLabel").pack(side="right", padx=(0, 8))
            ttk.Button(head, text="\u2699 Settings", command=self.open_settings).pack(side="right", padx=(0, 18))
            ttk.Button(head, text="\U0001F4C1 Logs", command=lambda: open_folder(log_dir())).pack(side="right", padx=8)

            # --- 1. adapters (full width, evenly spaced columns, editable Start / End IP)
            box = ttk.LabelFrame(self, text=" 1 \u00b7 Network adapters of this PC ", padding=10)
            box.pack(fill="x", padx=14, pady=(8, 4))
            tools = ttk.Frame(box, style="Card.TFrame")
            tools.pack(fill="x", pady=(0, 8))
            ttk.Button(tools, text="Select all", command=lambda: self.agrp.set_all(True)).pack(side="left")
            ttk.Button(tools, text="Deselect all", command=lambda: self.agrp.set_all(False)).pack(side="left", padx=8)
            ttk.Button(tools, text="\u21bb Refresh", command=self.refresh_adapters).pack(side="left")
            self.v_adapter_info = tk.StringVar()
            ttk.Label(tools, textvariable=self.v_adapter_info, style="Muted.TLabel").pack(side="left", padx=14)
            acols = [("sel", ON, 50), ("Adapter", "Adapter", 160), ("IP Address", "IP Address", 160),
                     ("Subnet Mask", "Subnet Mask", 160), ("Start IP", "Start IP", 160),
                     ("End IP", "End IP", 160), ("Type", "Type", 160)]
            awrap, self.atree = self._make_tree(box, acols, 2)
            awrap.pack(fill="x")
            for cid, _t, _w in acols[1:]:
                self.atree.column(cid, width=160, minwidth=110, stretch=True)   # equal share of the width
            self.agrp = CheckGroup(self.atree, lambda: None)

            # --- 2. login + discover on one line
            sett = ttk.LabelFrame(self, text=" 2 \u00b7 Scan & login ", padding=10)
            sett.pack(fill="x", padx=14, pady=4)
            self.v_extra = tk.StringVar(value=self.settings.get("extra", ""))      # edited in Settings
            self.v_ports = tk.StringVar(value=self.settings.get("ports", DEFAULT_PORTS))
            self.v_user = tk.StringVar(value=self.settings.get("user", "admin"))
            self.v_pw = tk.StringVar()
            self.v_force, self.v_show = tk.BooleanVar(value=False), tk.BooleanVar(value=False)
            row = ttk.Frame(sett, style="Card.TFrame")
            row.pack(fill="x")
            row.columnconfigure(5, weight=1)
            ttk.Label(row, text="Username", style="Field.TLabel").grid(row=0, column=0, sticky="w")
            ttk.Entry(row, textvariable=self.v_user, width=22, font=("Segoe UI", 11)).grid(row=1, column=0, sticky="w", padx=(0, 14))
            ttk.Label(row, text="Password", style="Field.TLabel").grid(row=0, column=1, sticky="w")
            self.pw_entry = ttk.Entry(row, textvariable=self.v_pw, width=22, show="*", font=("Segoe UI", 11))
            self.pw_entry.grid(row=1, column=1, sticky="w")
            self._tick(row, "Show", self.v_show,
                       lambda: self.pw_entry.configure(show="" if self.v_show.get() else "*")
                       ).grid(row=1, column=2, padx=(10, 16))
            self._tick(row, "Retry rejected logins", self.v_force).grid(row=1, column=3, padx=(0, 10))
            self.btns = []
            disc = ttk.Frame(row, style="Card.TFrame")
            disc.grid(row=1, column=6, sticky="e")
            for text, cmd, style in (("Scan", self.on_scan, "TButton"), ("Login & Fetch", self.on_fetch, "TButton"),
                                     ("Scan + Fetch", self.on_both, "Accent.TButton")):
                b = ttk.Button(disc, text=text, style=style, command=cmd)
                b.pack(side="left", padx=(8, 0))
                self.btns.append(b)

            # --- actions on the ticked cameras
            self.bar = ttk.Frame(self, padding=(14, 4, 14, 4))
            self.bar.pack(fill="x")
            ttk.Label(self.bar, text="Ticked cameras:", style="Sub.TLabel").pack(side="left", padx=(0, 10))
            for text, cmd in (("\U0001F4F7 Snapshot", self.on_snapshot), ("\U0001F310 Open Web", self.on_open_web),
                              ("\U0001F552 Sync PC Time", self.on_sync_time)):
                b = ttk.Button(self.bar, text=text, command=cmd)
                b.pack(side="left", padx=(0, 8))
                self.btns.append(b)
            self.v_sync_tz = tk.BooleanVar(value=bool(self.settings.get("sync_tz")))
            self._tick(self.bar, "Also set time zone", self.v_sync_tz, bg_key="bg").pack(side="left", padx=(0, 18))
            for text, cmd in (("Edit Camera...", self.on_edit_camera), ("Stream Settings...", self.on_stream_settings)):
                b = ttk.Button(self.bar, text=text, command=cmd)
                b.pack(side="left", padx=(0, 8))
                self.btns.append(b)
            b = ttk.Button(self.bar, text="\U0001F4CA Export Excel", command=self.on_export)
            b.pack(side="right")
            self.btns.append(b)
            self.progress = self._reg(ModernProgress(self.bar, self.p))   # only shown while busy

            # --- 3. results table
            res = ttk.LabelFrame(self, text=" 3 \u00b7 Devices & cameras ", padding=8)
            res.pack(fill="both", expand=True, padx=14, pady=4)
            tb = ttk.Frame(res, style="Card.TFrame")
            tb.pack(fill="x", pady=(0, 6))
            ttk.Button(tb, text="Select all", command=lambda: self.grp.set_all(True)).pack(side="left")
            ttk.Button(tb, text="Deselect all", command=lambda: self.grp.set_all(False)).pack(side="left", padx=8)
            self.v_checked = tk.StringVar()
            ttk.Label(tb, textvariable=self.v_checked, style="Muted.TLabel").pack(side="left", padx=12)
            self.v_filter = tk.StringVar()
            self._filter_job = None
            ttk.Entry(tb, textvariable=self.v_filter, width=26, font=("Segoe UI", 11)).pack(side="left", padx=(24, 0))
            ttk.Label(tb, text="\U0001F50D Filter", style="Muted.TLabel").pack(side="left", padx=10)
            self.v_filter.trace_add("write", lambda *a: self._schedule_filter())
            self.v_summary = tk.StringVar(value="No scan yet")
            ttk.Label(tb, textvariable=self.v_summary, style="Summary.TLabel").pack(side="right")
            self.v_pctime = tk.StringVar()
            ttk.Label(tb, textvariable=self.v_pctime, style="Muted.TLabel").pack(side="right", padx=18)
            cols = [("sel", ON, 46), ("IP Address", "IP Address", 115), ("web", "Web", 90)]
            cols += [(f, field_heading(f), FIELD_WIDTH.get(f, 110)) for f in TABLE_FIELDS]
            wrap, self.tree = self._make_tree(res, cols, 8)
            wrap.pack(fill="both", expand=True)
            self.grp = CheckGroup(self.tree, self._update_summary)
            self.tree.bind("<<TreeviewSelect>>", self._on_select)
            self.tree.bind("<Button-1>", self._on_web_click, add="+")
            self.tree.bind("<Double-1>", self._on_double)
            self.tree.bind("<Motion>", self._on_motion)
            self.tree.bind("<Button-3>", self._on_right_click)
            self.tree.bind("<Button-2>", self._on_right_click)
            self.menu = tk.Menu(self, tearoff=0)
            self.menu.add_command(label="Open web interface", command=self.on_open_web_selected)
            self.menu.add_command(label="Edit camera name...", command=self.on_edit_camera_selected)
            self.menu.add_command(label="Copy IP address", command=self._copy_ip)
            self.v_detail = tk.StringVar(value="Click a row for its full status \u00b7 click \U0001F310 Open to open a "
                                               "camera's web page \u00b7 drag column borders to resize.")
            ttk.Label(res, textvariable=self.v_detail, style="Muted.TLabel", wraplength=1200,
                      justify="left").pack(fill="x", pady=(6, 0))

            # --- log
            lf = ttk.LabelFrame(self, text=" Log (everything is also saved to the log file) ", padding=6)
            lf.pack(fill="x", side="bottom", padx=14, pady=(4, 12), before=res)
            self.log_big = False

            def toggle_log():
                self.log_big = not self.log_big
                self.log.configure(height=9 if self.log_big else 2)
                self.log_btn.configure(text="\u25bc Collapse" if self.log_big else "\u25b2 Expand")
                self.log.see("end")

            self.log_btn = ttk.Button(lf, text="\u25b2 Expand", command=toggle_log)
            self.log_btn.pack(side="right", anchor="n", padx=(8, 0))
            self.log = tk.Text(lf, height=2, state="disabled", font=("Consolas", 9), relief="flat", wrap="word",
                               highlightthickness=0, bd=0)
            ls = self._reg(ModernScrollbar(lf, "vertical", self.log.yview, self.p))
            self.log.configure(yscrollcommand=ls.set)
            self.log.pack(side="left", fill="x", expand=True)
            ls.pack(side="right", fill="y")

        # ------------------------------------------------------------ visible fields
        def apply_visible(self):
            self.display = (["sel", "IP Address"] + [f for f in TABLE_FIELDS if f in self.visible and f != "Status"]
                            + (["Status"] if "Status" in self.visible else []) + ["web"])
            self.tree.configure(displaycolumns=self.display)
            self.settings["visible"] = list(self.visible)
            save_settings(self.settings)

        def _col_id(self, event):
            try:
                n = int(self.tree.identify_column(event.x)[1:])
            except ValueError:
                return None
            return self.display[n - 1] if 1 <= n <= len(self.display) else None

        # ------------------------------------------------------------ adapters
        def refresh_adapters(self):
            self.atree.delete(*self.atree.get_children())
            self.agrp.checked.clear()
            self.adapters = list_adapters()
            for i, a in enumerate(self.adapters):
                self.agrp.checked[str(i)] = not a.virtual
                self.atree.insert("", "end", iid=str(i), values=[
                    ON if not a.virtual else OFF, a.name, a.ip, a.netmask, a.start, a.end,
                    "Virtual / VPN" if a.virtual else "Physical"])
            self.atree.configure(height=max(2, min(5, len(self.adapters))))
            self.v_adapter_info.set(
                f"{len(self.adapters)} active adapter(s) - virtual/VPN unticked"
                if self.adapters else "No active IPv4 adapters - connect to the camera network first")
            LOG.info("Adapters: %s", "; ".join(a.describe() for a in self.adapters) or "none")

        # ------------------------------------------------------------ table logic
        def _rebuild_table(self):
            self.tree.delete(*self.tree.get_children())
            self.status_full = {}
            flt = self.v_filter.get().strip().lower()
            for d in self.devices:
                res = self.results.get(d.ip)
                if res is None:
                    entries = [(f"{d.ip}|0", {"IP Address": d.ip, "Network Adapter": d.adapter,
                                              "Status": "Found - not verified yet"}, "pending")]
                elif res["state"] == "ok":
                    entries = [(f"{d.ip}|{r['Channel']}", r, "ok") for r in res["rows"]]
                else:
                    entries = [(f"{d.ip}|0", {"IP Address": d.ip, "Network Adapter": d.adapter,
                                              "Status": f"{res['excl']['Result']}: {res['excl']['Detail']}"}, "bad")]
                for iid, row, tag in entries:
                    self.grp.checked.setdefault(iid, tag != "bad")
                    full = row.get("Status", "")
                    self.status_full[iid] = full
                    if flt and flt not in " ".join([d.ip] + [str(v) for v in row.values()]).lower():
                        continue                                   # hidden rows are never ticked / acted on
                    row = dict(row, Status=full if len(full) <= 38 else full[:36] + "\u2026")
                    vals = [ON if self.grp.checked[iid] else OFF, d.ip, WEB_TEXT] + \
                           [row.get(f, "") for f in TABLE_FIELDS]
                    self.tree.insert("", "end", iid=iid, values=vals, tags=(tag,))
            self._update_summary()
            self._paint_clock()

        def _schedule_filter(self):
            if self._filter_job:
                self.after_cancel(self._filter_job)
            self._filter_job = self.after(250, self._rebuild_table)

        def _update_summary(self):
            ok = sum(1 for r in self.results.values() if r["state"] == "ok")
            bad = sum(1 for r in self.results.values() if r["state"] != "ok")
            if not self.devices:
                self.v_summary.set("No scan yet")
            elif not self.results:
                self.v_summary.set(f"{len(self.devices)} device(s) found")
            else:
                self.v_summary.set(f"{len(self.devices)} found  \u00b7  {ok} IP camera(s) OK  \u00b7  {bad} not included")
            self.v_checked.set(f"{len(self.grp.ticked())} of {len(self.tree.get_children())} row(s) ticked")

        def _on_select(self, _event):
            sel = self.tree.selection()
            if sel:
                self.v_detail.set(f"{sel[0].split('|')[0]}:  {self.status_full.get(sel[0], '')}")

        def _device(self, ip):
            return next((d for d in self.devices if d.ip == ip), None)

        def _on_web_click(self, event):
            if (self.tree.identify_region(event.x, event.y) == "cell" and self._col_id(event) == "web"):
                iid = self.tree.identify_row(event.y)
                if iid:
                    self._open_ips([iid.split("|")[0]])
                    return "break"
            return None

        def _on_motion(self, event):
            over = (self.tree.identify_region(event.x, event.y) == "cell" and self._col_id(event) == "web")
            self.tree.configure(cursor="hand2" if over else "")

        def _on_double(self, event):
            if self.tree.identify_region(event.x, event.y) == "cell" and self._col_id(event) not in ("sel", "web"):
                iid = self.tree.identify_row(event.y)
                if iid:
                    self._open_ips([iid.split("|")[0]])

        def _on_right_click(self, event):
            iid = self.tree.identify_row(event.y)
            if iid:
                self.tree.selection_set(iid)
                self.menu.tk_popup(event.x_root, event.y_root)

        def _copy_ip(self):
            sel = self.tree.selection()
            if sel:
                self.clipboard_clear()
                self.clipboard_append(sel[0].split("|")[0])

        # ------------------------------------------------------------ live device clock
        def _paint_clock(self):
            now = datetime.now()
            self.v_pctime.set(f"PC time  {now:%Y-%m-%d %H:%M:%S}")
            if not ({"Device Time", "Time Diff vs PC (s)"} & set(self.visible)):
                return
            for iid in self.tree.get_children():
                off = self.offsets.get(iid.split("|")[0])
                if off is None:
                    continue
                self.tree.set(iid, "Device Time", fmt_time(now + timedelta(seconds=off)))
                self.tree.set(iid, "Time Diff vs PC (s)", fmt_offset(off))

        def _tick_clock(self):
            self._paint_clock()
            self.after(1000, self._tick_clock)

        def _refresh_offsets_job(self):
            """Every minute re-read the real clock of each verified camera (keeps the live display exact)."""
            targets = [{"dev": d, "creds": self.creds[d.ip]} for d in self.devices
                       if d.ip in self.creds and self.results.get(d.ip, {}).get("state") == "ok"]
            if targets and not self.busy:
                threading.Thread(target=lambda: self.q.put(("offsets", (read_offsets(targets),))),
                                 daemon=True).start()
            self.after(60000, self._refresh_offsets_job)

        # ------------------------------------------------------------ thread plumbing
        def _cb(self, kind, *a):
            self.q.put((kind, a))

        def note(self, msg):
            """Message from the UI thread: shown AND written to the log file."""
            LOG.info(msg)
            self._show(msg)

        def _show(self, msg):
            self.log.configure(state="normal")
            self.log.insert("end", f"[{datetime.now():%H:%M:%S}] {msg}\n")
            self.log.see("end")
            self.log.configure(state="disabled")

        def _show_history(self, lines):
            if not lines:
                return
            self.log.configure(state="normal")
            self.log.insert("end", "\u2500\u2500 previous activity (from the log file) \u2500\u2500\n", "hist")
            for ln in lines:
                self.log.insert("end", ln.rstrip("\n") + "\n", "hist")
            self.log.insert("end", "\u2500\u2500 this session \u2500\u2500\n", "hist")
            self.log.see("end")
            self.log.configure(state="disabled")

        def _poll(self):
            try:
                while True:
                    kind, a = self.q.get_nowait()
                    if kind == "log":
                        self._show(a[0])            # core code already wrote it to the log file
                    elif kind == "progress":
                        self.progress.set(a[0], a[1])
                    elif kind == "devices":
                        self.devices, self.results = a[0], {}
                        self.grp.checked.clear()
                        self._rebuild_table()
                    elif kind == "results":
                        self._apply_results(*a)
                    elif kind == "offsets":
                        self.offsets.update(a[0])
                    elif kind == "snapdone":
                        self._snap_done(*a)
                    elif kind == "syncdone":
                        self._sync_done(*a)
                    elif kind == "done":
                        self._set_busy(False)
                    elif kind == "error":
                        self._set_busy(False)
                        LOG.error(a[0])
                        messagebox.showerror("Error", a[0])
            except queue.Empty:
                pass
            self.after(100, self._poll)

        def _apply_results(self, todo, rows, excluded, creds):
            by_ip_rows, by_ip_excl = {}, {e["IP Address"]: e for e in excluded}
            for r in rows:
                by_ip_rows.setdefault(r["IP Address"], []).append(r)
            for d in todo:
                for k in [k for k in self.grp.checked if k.startswith(d.ip + "|")]:
                    del self.grp.checked[k]
                if d.ip in by_ip_rows:
                    self.results[d.ip] = {"state": "ok", "rows": by_ip_rows[d.ip]}
                    self.rejected.pop(d.ip, None)
                    self.creds[d.ip] = creds
                    off = by_ip_rows[d.ip][0].get("_offset")
                    if off is not None:
                        self.offsets[d.ip] = off
                else:
                    e = by_ip_excl[d.ip]
                    self.results[d.ip] = {"state": "bad", "excl": e}
                    self.creds.pop(d.ip, None)
                    self.offsets.pop(d.ip, None)
                    if e["Result"] == "Login failed":
                        self.rejected[d.ip] = creds
                    else:
                        self.rejected.pop(d.ip, None)
            self._rebuild_table()

        def _set_busy(self, busy):
            self.busy = busy
            for b in self.btns:
                b.state(["disabled"] if busy else ["!disabled"])
            if busy:
                self.progress.set(0, 1)
                self.progress.pack(side="right", padx=4)
            else:
                self.progress.pack_forget()         # no empty bar when idle

        def _run(self, fn, label=""):
            if self.busy:
                return
            self._set_busy(True)

            def wrapper():
                try:
                    fn()
                except Exception as e:
                    LOG.exception("Task failed (%s)", label)
                    self.q.put(("error", (str(e),)))
                else:
                    self.q.put(("done", ()))
            threading.Thread(target=wrapper, daemon=True).start()

        # ------------------------------------------------------------ scan / fetch
        def _inputs(self):
            """Read every widget value on the UI thread."""
            return {
                "adapters": [self.adapters[int(i)] for i in self.agrp.ticked()],
                "extra": self.v_extra.get(), "ports": parse_ports(self.v_ports.get()),
                "user": self.v_user.get(), "pw": self.v_pw.get(), "force": self.v_force.get(),
                "ips": {i.split("|")[0] for i in self.grp.ticked()},
            }

        def _do_scan(self, inp):
            if not inp["adapters"] and not inp["extra"].strip():
                raise RuntimeError("Tick at least one network adapter (or enter an extra range).")
            LOG.info("Scan started: adapters=%s extra=%r ports=%s",
                     [a.label for a in inp["adapters"]], inp["extra"], inp["ports"])
            host_map = build_scan_plan(inp["adapters"], inp["extra"])
            self.scanned = [{"label": a.label, "range": a.scan_range} for a in inp["adapters"]]
            if inp["extra"].strip():
                self.scanned.append({"label": "Manual range", "range": inp["extra"].strip()})
            found = scan_network(host_map, inp["ports"], self._cb)
            self.q.put(("devices", (found,)))
            return found

        def _do_fetch(self, inp, devices=None):
            """devices=None -> use the ticked rows of the table; otherwise use the given list."""
            if devices is None:
                if not self.devices:
                    raise RuntimeError("No devices yet - run the scan first.")
                devices = [d for d in self.devices if d.ip in inp["ips"]]
                if not devices:
                    raise RuntimeError("Nothing ticked - tick at least one device in the table.")
            user, pw = inp["user"], inp["pw"]
            if not user or not pw:
                raise RuntimeError("Enter the camera username and password.")
            todo, skipped = [], []
            for d in devices:
                (skipped if self.rejected.get(d.ip) == (user, pw) and not inp["force"] else todo).append(d)
            for d in skipped:
                say(self._cb, f"{d.ip}: skipped - these credentials were already rejected (lockout protection). "
                              "Change the credentials / wait for the lock to expire, or tick 'Retry devices "
                              "that already rejected...'.")
            if not todo:
                return
            say(self._cb, f"Logging in to {len(todo)} device(s) as '{user}' and verifying IP cameras ...")
            rows, excluded = fetch_all(todo, user, pw, self._cb)
            self.q.put(("results", (todo, rows, excluded, (user, pw))))
            say(self._cb, f"Done: {len({r['IP Address'] for r in rows})} Dahua IP camera(s) OK; "
                          f"{len(excluded)} device(s) not included - see the Status column.")

        def on_scan(self):
            inp = self._inputs()
            LOG.info("Action: Scan clicked (%d adapter(s) ticked, extra=%r, ports=%s)", len(inp["adapters"]),
                     inp["extra"], inp["ports"])
            self._run(lambda: self._do_scan(inp), "scan")

        def on_fetch(self):
            inp = self._inputs()
            LOG.info("Action: Login & Fetch clicked (%d device(s) ticked, user=%s)", len(inp["ips"]), inp["user"])
            self._run(lambda: self._do_fetch(inp), "fetch")

        def on_both(self):
            inp = self._inputs()
            LOG.info("Action: Scan + Fetch clicked (%d adapter(s) ticked, extra=%r, ports=%s, user=%s)",
                     len(inp["adapters"]), inp["extra"], inp["ports"], inp["user"])

            def both():
                found = self._do_scan(inp)
                if found:
                    self._do_fetch(inp, devices=found)
            self._run(both, "scan+fetch")

        # ------------------------------------------------------------ web interface
        def _open_ips(self, ips):
            ips = list(dict.fromkeys(ips))
            if len(ips) > 5 and not messagebox.askyesno(
                    "Open web interfaces", f"This opens {len(ips)} browser tabs. Continue?"):
                return
            for ip in ips:
                d = self._device(ip)
                if d:
                    webbrowser.open(device_url(d))
                    self.note(f"Opened {device_url(d)} in the browser")

        def on_open_web_selected(self):
            self._open_ips([i.split("|")[0] for i in self.tree.selection()])

        def on_open_web(self):
            ips = [i.split("|")[0] for i in (self.tree.selection() or self.grp.ticked())]
            if not ips:
                messagebox.showinfo("Open web interface",
                                    "Tick (or highlight) at least one device in the table first.")
                return
            self._open_ips(ips)

        # ------------------------------------------------------------ verified cameras helpers
        def _ticked_cameras(self, iids=None):
            """Verified camera rows (the ticked ones, or the given row ids) -> list of dict(dev, creds, channel, row)."""
            out = []
            for iid in (self.grp.ticked() if iids is None else iids):
                ip, ch = iid.split("|")
                res, dev = self.results.get(ip), self._device(ip)
                if not res or res["state"] != "ok" or not dev or ip not in self.creds:
                    continue
                row = next((r for r in res["rows"] if str(r["Channel"]) == ch), None)
                if row:
                    out.append({"dev": dev, "creds": self.creds[ip], "channel": int(ch), "row": row,
                                "multi": len(res["rows"]) > 1})
            return out

        # ------------------------------------------------------------ file / folder pickers
        # Some PCs cannot open the native Windows file dialog ("Unspecified error"). We then try Tk's own
        # dialog, and as a last resort use a default folder, so exporting and snapshots never stop working.
        def _ask_save_path(self, title, initialfile, defext, filetypes, initialdir):
            kw = {"parent": self, "title": title, "defaultextension": defext,
                  "filetypes": list(filetypes), "initialfile": initialfile}
            if initialdir and os.path.isdir(initialdir):
                kw["initialdir"] = initialdir
            try:
                return filedialog.asksaveasfilename(**kw) or ""
            except tk.TclError as e:
                LOG.warning("Windows save dialog failed (%s) - trying Tk's own dialog", e)
            try:
                args = ["::tk::dialog::file::", "save", "-parent", str(self), "-title", title,
                        "-initialfile", initialfile, "-defaultextension", defext,
                        "-filetypes", tuple(tuple(f) for f in filetypes)]
                if initialdir and os.path.isdir(initialdir):
                    args += ["-initialdir", initialdir]
                return str(self.tk.call(*args) or "")
            except tk.TclError as e:
                LOG.warning("Tk's own save dialog failed too (%s) - using a default folder", e)
            folder = initialdir or os.path.join(os.path.expanduser("~"), "Documents", "HK IP Camera Settings")
            os.makedirs(folder, exist_ok=True)
            path = os.path.join(folder, initialfile)
            self.note(f"The file dialog is not available on this PC - saving to {path}")
            return path

        def _ask_directory(self, title, initialdir, parent=None, use_default=True):
            parent = parent or self
            kw = {"parent": parent, "title": title}
            if initialdir and os.path.isdir(initialdir):
                kw["initialdir"] = initialdir
            try:
                return filedialog.askdirectory(**kw) or ""
            except tk.TclError as e:
                LOG.warning("Windows folder dialog failed (%s) - trying Tk's own dialog", e)
            try:
                args = ["::tk::dialog::file::chooseDir::", "-parent", str(parent), "-title", title]
                if initialdir and os.path.isdir(initialdir):
                    args += ["-initialdir", initialdir]
                return str(self.tk.call(*args) or "")
            except tk.TclError as e:
                LOG.warning("Tk's own folder dialog failed too (%s)", e)
            if not use_default:
                messagebox.showinfo("Folder", "The folder dialog is not available on this PC.\n"
                                              "Please type the folder path into the box instead.", parent=parent)
                return ""
            folder = initialdir or os.path.join(os.path.expanduser("~"), "Pictures", "HK IP Camera Settings")
            os.makedirs(folder, exist_ok=True)
            self.note(f"The folder dialog is not available on this PC - using {folder} "
                      "(change it in Settings by typing a path).")
            return folder

        # ------------------------------------------------------------ time sync
        def on_sync_time(self):
            with_tz = self.v_sync_tz.get()
            cams = self._ticked_cameras()
            by_ip = {c["dev"].ip: c for c in cams}
            if not by_ip:
                messagebox.showinfo("Sync PC time", "Tick at least one verified camera (green row) first.")
                return
            if not messagebox.askyesno(
                    "Sync PC time",
                    f"Set the clock of {len(by_ip)} camera(s) to this PC's current time\n"
                    f"({datetime.now():%Y-%m-%d %H:%M:%S})?\n\n"
                    + (f"Their time zone will also be set to this PC's ({pc_tz_index()[1]})."
                       if with_tz else "The cameras' time zone settings are not changed.")):
                return
            self.settings["sync_tz"] = with_tz
            targets = list(by_ip.values())
            self.note(f"Syncing {len(targets)} camera(s) to PC time" + (" and time zone" if with_tz else "") + " ...")

            def work():
                offs, summary = sync_times(targets, self._cb, with_tz)
                self.q.put(("offsets", (offs,)))
                self.q.put(("syncdone", (summary,)))
            self._run(work, "sync time")

        # ------------------------------------------------------------ snapshots
        def on_snapshot(self):
            targets = []
            for c in self._ticked_cameras():
                row = c["row"]
                targets.append({"dev": c["dev"], "creds": c["creds"], "channel": c["channel"],
                                "name": row.get("Camera Name", ""), "serial": row.get("Serial Number", c["dev"].ip),
                                "multi": c["multi"], "main_res": row.get("Main Resolution", "")})
            if not targets:
                messagebox.showinfo("Take snapshot", "Tick at least one verified camera (green row) first.\n"
                                                     "Run 'Login & Fetch' if the rows are not green yet.")
                return
            folder = self._ask_directory("Choose the folder for the snapshots", self.snap_dir)
            if not folder:
                return
            self.snap_dir = folder
            self.settings["snap_dir"] = folder
            save_settings(self.settings)
            self.note(f"Taking snapshots of {len(targets)} camera(s) ...")

            def work():
                ok, fail = take_snapshots(targets, folder, self._cb)
                self.q.put(("snapdone", (folder, ok, fail)))
            self._run(work, "snapshot")

        def _sync_done(self, summary):
            if summary["warn"] or summary["fail"]:
                messagebox.showwarning(
                    "Sync PC time",
                    f"{summary['ok']} camera(s) are in sync with the PC.\n"
                    f"{summary['warn'] + summary['fail']} need attention:\n\n"
                    + "\n".join(summary["problems"][:10]) + "\n\nFull details are in the Log.")

        def _snap_done(self, folder, ok, fail):
            self.note(f"Snapshots finished: {ok} saved, {fail} failed -> {folder}")
            if ok and messagebox.askyesno("Snapshots saved", f"{ok} snapshot(s) saved to:\n{folder}\n\nOpen the folder?"):
                open_folder(folder)

        # ------------------------------------------------------------ export
        def on_export(self):
            rows = []
            for res in self.results.values():
                if res["state"] == "ok":
                    rows += [r for r in res["rows"] if self.grp.checked.get(f"{r['IP Address']}|{r['Channel']}")]
            if not rows:
                messagebox.showinfo("Nothing to export", "No verified Dahua IP camera is ticked.\n"
                                                         "Run 'Login & Fetch' and tick the cameras to export.")
                return
            excluded = [r["excl"] for r in self.results.values() if r["state"] != "ok"]
            path = self._ask_save_path("Save the Excel file", f"HK_cameras_{datetime.now():%Y%m%d_%H%M}.xlsx",
                                       ".xlsx", (("Excel workbook", "*.xlsx"),), self.export_dir)
            if path:
                try:
                    cols = None
                    if self.settings.get("excel_visible_only"):
                        cols = {"IP Address"} | set(self.visible)
                    export_xlsx(rows, excluded, self.scanned, path, cols)
                    self.export_dir = os.path.dirname(os.path.abspath(path))
                    self.settings["export_dir"] = self.export_dir
                    save_settings(self.settings)
                    self.note(f"Exported {len(rows)} row(s) to {path}")
                    messagebox.showinfo("Exported", f"Saved:\n{path}")
                except Exception as e:
                    LOG.exception("Export failed")
                    messagebox.showerror("Export failed", str(e))

        # ------------------------------------------------------------ settings page
        def open_settings(self):
            p = self.p
            dlg = tk.Toplevel(self)
            dlg.title(f"Settings - {APP_NAME}")
            dlg.configure(bg=p["bg"])
            dlg.transient(self)
            w = min(1180, self.winfo_screenwidth() - 60)
            h = min(720, self.winfo_screenheight() - 100)
            dlg.geometry(f"{w}x{h}+{self.winfo_x() + 40}+{self.winfo_y() + 30}")
            dlg.grab_set()
            ttk.Label(dlg, text="Settings", style="Title.TLabel").pack(anchor="w", padx=16, pady=(12, 0))
            ttk.Label(dlg, text="Choose which fields are shown in the device table (the Status and Web columns are always at the end). "
                                "Scan options (extra ranges, ports) are in the General box below.",
                      style="Sub.TLabel").pack(anchor="w", padx=16, pady=(0, 8))

            tools = ttk.Frame(dlg)
            tools.pack(fill="x", padx=16)
            vars_ = {f: tk.BooleanVar(value=f in self.visible) for f in TABLE_FIELDS}
            ttk.Button(tools, text="Select all", command=lambda: [v.set(True) for v in vars_.values()]
                       ).pack(side="left")
            ttk.Button(tools, text="Deselect all", command=lambda: [v.set(False) for v in vars_.values()]
                       ).pack(side="left", padx=6)
            ttk.Button(tools, text="Reset to default",
                       command=lambda: [v.set(f in DEFAULT_VISIBLE) for f, v in vars_.items()]).pack(side="left")

            area = ttk.Frame(dlg, style="Card.TFrame")
            area.pack(fill="both", expand=True, padx=16, pady=8)
            area.rowconfigure(0, weight=1)
            area.columnconfigure(0, weight=1)
            cv = tk.Canvas(area, highlightthickness=0, bd=0, bg=p["card"])
            sb = ModernScrollbar(area, "vertical", cv.yview, p)
            cv.configure(yscrollcommand=sb.set)
            cv.grid(row=0, column=0, sticky="nsew")
            sb.grid(row=0, column=1, sticky="ns")
            inner = ttk.Frame(cv, style="Card.TFrame")
            cv.create_window((0, 0), window=inner, anchor="nw")
            inner.bind("<Configure>", lambda e: cv.configure(scrollregion=cv.bbox("all")))
            cv.bind_all("<MouseWheel>", lambda e: cv.yview_scroll(int(-e.delta / 120), "units"))
            dlg.bind("<Destroy>", lambda e: cv.unbind_all("<MouseWheel>") if e.widget is dlg else None)
            for i, (title, fields) in enumerate(FIELD_GROUPS):
                grp = ttk.LabelFrame(inner, text=f" {title} ", padding=8)
                grp.grid(row=i // 4, column=i % 4, sticky="nsew", padx=8, pady=8)
                for f in fields:
                    TickBox(grp, f, vars_[f], None, p).pack(anchor="w", pady=1)

            gen = ttk.LabelFrame(dlg, text=" General ", padding=8)
            gen.pack(fill="x", padx=16, pady=(0, 8))
            v_excel = tk.BooleanVar(value=bool(self.settings.get("excel_visible_only")))
            TickBox(gen, "Excel export contains only the visible fields (off = all fields)", v_excel, None, p
                    ).grid(row=0, column=0, columnspan=4, sticky="w")
            v_snap = tk.StringVar(value=self.snap_dir)
            ttk.Label(gen, text="Snapshot folder", style="Card.TLabel").grid(row=1, column=0, sticky="w", pady=(8, 0))
            ttk.Entry(gen, textvariable=v_snap, width=60).grid(row=1, column=1, padx=8, pady=(8, 0))
            ttk.Button(gen, text="Browse...", command=lambda: v_snap.set(
                self._ask_directory("Choose the snapshot folder", v_snap.get(), parent=dlg, use_default=False)
                or v_snap.get())
                       ).grid(row=1, column=2, pady=(8, 0))
            ttk.Button(gen, text="Open logs folder", command=lambda: open_folder(log_dir())
                       ).grid(row=1, column=3, padx=(16, 0), pady=(8, 0))
            ttk.Label(gen, text=f"Settings & logs are stored in: {data_dir()}", style="Muted.TLabel"
                      ).grid(row=2, column=0, columnspan=4, sticky="w", pady=(6, 0))
            v_http = tk.BooleanVar(value=bool(self.settings.get("log_http")))
            TickBox(gen, "Detailed logging: record every request sent to a camera (larger log files - "
                         "switch on when a problem is being investigated)", v_http, None, p
                    ).grid(row=3, column=0, columnspan=4, sticky="w", pady=(8, 0))

            def save_bundle():
                path = self._ask_save_path("Save diagnostic bundle", f"HK_diagnostics_{datetime.now():%Y%m%d_%H%M}.zip",
                                           ".zip", (("Zip file", "*.zip"),), self.export_dir)
                if not path:
                    return
                try:
                    build_diagnostic_bundle(path, self._screen_info(), self.settings)
                    messagebox.showinfo("Diagnostic bundle", f"Saved:\n{path}\n\nSend this file when you report a "
                                        "problem. It contains device IPs, models and serial numbers, but no passwords.",
                                        parent=dlg)
                except Exception as e:
                    LOG.exception("Diagnostic bundle failed")
                    messagebox.showerror("Diagnostic bundle", str(e), parent=dlg)
            ttk.Button(gen, text="Save diagnostic bundle...", command=save_bundle
                       ).grid(row=4, column=0, sticky="w", pady=(8, 0))

            v_extra = tk.StringVar(value=self.v_extra.get())
            v_ports = tk.StringVar(value=self.v_ports.get())
            ttk.Label(gen, text="Extra ranges (optional)", style="Card.TLabel").grid(row=5, column=0, sticky="w", pady=(10, 0))
            ttk.Entry(gen, textvariable=v_extra, width=60).grid(row=5, column=1, padx=8, pady=(10, 0))
            ttk.Label(gen, text="e.g. 192.168.5.0/24 or 10.0.0.1-10.0.0.50 (comma separated)", style="Muted.TLabel"
                      ).grid(row=5, column=2, columnspan=2, sticky="w", pady=(10, 0))
            ttk.Label(gen, text="Ports", style="Card.TLabel").grid(row=6, column=0, sticky="w", pady=(6, 0))
            ttk.Entry(gen, textvariable=v_ports, width=24).grid(row=6, column=1, sticky="w", padx=8, pady=(6, 0))
            ttk.Label(gen, text=f"HTTP/HTTPS ports to scan (default {DEFAULT_PORTS})", style="Muted.TLabel"
                      ).grid(row=6, column=2, columnspan=2, sticky="w", pady=(6, 0))

            btns = ttk.Frame(dlg)
            btns.pack(fill="x", padx=16, pady=(0, 12))

            def apply(close):
                self.v_extra.set(v_extra.get().strip())
                self.v_ports.set(v_ports.get().strip() or DEFAULT_PORTS)
                self.visible = [f for f in TABLE_FIELDS if vars_[f].get()]
                self.settings["excel_visible_only"] = v_excel.get()
                self.snap_dir = v_snap.get() or self.snap_dir
                self.settings["snap_dir"] = self.snap_dir
                self.settings["log_http"] = v_http.get()
                set_http_trace(v_http.get())
                self.apply_visible()
                LOG.info("Settings saved: %d visible fields, excel_visible_only=%s, snapshot folder=%s",
                         len(self.visible), v_excel.get(), self.snap_dir)
                self._paint_clock()
                if close:
                    dlg.destroy()
            ttk.Button(btns, text="Save & close", style="Accent.TButton", command=lambda: apply(True)
                       ).pack(side="right")
            ttk.Button(btns, text="Apply", command=lambda: apply(False)).pack(side="right", padx=8)
            ttk.Button(btns, text="Cancel", command=dlg.destroy).pack(side="right")

        # ------------------------------------------------------------ helpers for the settings dialogs
        def _bg(self, widget, fn, done):
            """Run fn() in a thread; call done(result, error_text) on the UI thread when it has finished."""
            box = {}

            def work():
                try:
                    box["res"] = fn()
                except Exception as e:
                    LOG.exception("Background task failed")
                    box["err"] = str(e) or type(e).__name__
            threading.Thread(target=work, daemon=True).start()

            def poll():
                if "res" in box or "err" in box:
                    done(box.get("res"), box.get("err"))
                else:
                    widget.after(120, poll)
            widget.after(120, poll)

        def _refresh_cameras(self, devs):
            """(worker thread) re-read the given devices so the table shows the new values."""
            groups = {}
            for d in devs:
                if d.ip in self.creds:
                    groups.setdefault(self.creds[d.ip], []).append(d)
            for creds, group in groups.items():
                rows, excluded = fetch_all(group, creds[0], creds[1], lambda *a: None)
                self.q.put(("results", (group, rows, excluded, creds)))

        def _screen_info(self):
            try:
                return [f"Screen: {self.winfo_screenwidth()}x{self.winfo_screenheight()} | "
                        f"Tk {self.tk.call('info', 'patchlevel')} | scaling {float(self.tk.call('tk', 'scaling')):.2f}"]
            except tk.TclError:
                return []

        # ------------------------------------------------------------ edit one camera (names)
        def on_edit_camera(self):
            cams = self._ticked_cameras(list(self.tree.selection()) or None)
            LOG.info("Action: Edit Camera (%d usable row(s))", len(cams))
            if len(cams) != 1:
                messagebox.showinfo("Edit camera", "Highlight (or tick) exactly ONE verified camera (green row) first.")
                return
            self._edit_dialog(cams[0])

        def on_edit_camera_selected(self):
            cams = self._ticked_cameras(list(self.tree.selection()))
            if len(cams) == 1:
                self._edit_dialog(cams[0])

        def _edit_dialog(self, cam):
            p, row, dev = self.p, cam["row"], cam["dev"]
            dlg = tk.Toplevel(self)
            dlg.title(f"Edit camera - {dev.ip}")
            dlg.configure(bg=p["bg"])
            dlg.transient(self)
            dlg.geometry(f"600x370+{self.winfo_x() + 90}+{self.winfo_y() + 90}")
            dlg.grab_set()
            ttk.Label(dlg, text="Edit camera", style="Title.TLabel").pack(anchor="w", padx=16, pady=(12, 0))
            chan = f"  \u00b7  channel {cam['channel']}" if cam["multi"] else ""
            ttk.Label(dlg, text=f"{dev.ip}  \u00b7  {row.get('Model', '')}  \u00b7  {row.get('Serial Number', '')}{chan}",
                      style="Sub.TLabel").pack(anchor="w", padx=16, pady=(0, 8))
            box = ttk.LabelFrame(dlg, text=" Names ", padding=10)
            box.pack(fill="x", padx=16)
            v_cam = tk.StringVar(value=row.get("Camera Name", ""))
            v_dev = tk.StringVar(value=row.get("Device Name", ""))
            ttk.Label(box, text="Camera name (on-screen title)", style="Card.TLabel").grid(row=0, column=0, sticky="w")
            ttk.Entry(box, textvariable=v_cam, width=44).grid(row=0, column=1, padx=10, pady=4)
            ttk.Label(box, text="Device name", style="Card.TLabel").grid(row=1, column=0, sticky="w")
            ttk.Entry(box, textvariable=v_dev, width=44).grid(row=1, column=1, padx=10, pady=4)
            ttk.Label(box, text="Only fields you change are written. Every change is read back from the camera "
                                "to confirm it, and the old and new values are written to the log.",
                      style="Muted.TLabel", wraplength=520, justify="left").grid(row=2, column=0, columnspan=2,
                                                                                  sticky="w", pady=(6, 0))
            v_status = tk.StringVar()
            ttk.Label(dlg, textvariable=v_status, style="Sub.TLabel", wraplength=560, justify="left"
                      ).pack(anchor="w", padx=16, pady=10)
            btns = ttk.Frame(dlg)
            btns.pack(fill="x", padx=16, pady=(0, 12), side="bottom")
            b_apply = ttk.Button(btns, text="Apply", style="Accent.TButton")
            b_apply.pack(side="right")
            ttk.Button(btns, text="Close", command=dlg.destroy).pack(side="right", padx=8)

            def apply():
                new_cam, new_dev = v_cam.get().strip(), v_dev.get().strip()
                jobs = {}
                if new_cam != row.get("Camera Name", ""):
                    jobs["camera_name"] = new_cam
                if new_dev != row.get("Device Name", ""):
                    jobs["device_name"] = new_dev
                if not jobs:
                    v_status.set("Nothing to change.")
                    return
                for k, what in (("camera_name", "Camera name"), ("device_name", "Device name")):
                    if k in jobs:
                        jobs[k], problem = check_name(jobs[k], what)
                        if problem:
                            v_status.set(problem)
                            return
                LOG.info("Action: Edit camera %s ch%s %s", dev.ip, cam["channel"], jobs)
                v_status.set("Saving and checking ...")
                b_apply.state(["disabled"])
                self._bg(dlg, lambda: rename_camera(cam, **jobs), finished)

            def finished(results, err):
                b_apply.state(["!disabled"])
                if err:
                    v_status.set(f"Error: {err}")
                    return
                lines = []
                for what, ok, msg in results:
                    lines.append(f"{'\u2713' if ok else '\u2717'} {what}: {msg}")
                    if ok:
                        value = v_cam.get().strip() if what == "Camera name" else v_dev.get().strip()
                        if what == "Camera name":
                            row["Camera Name"] = value
                        else:
                            for r in self.results.get(dev.ip, {}).get("rows", []):
                                r["Device Name"] = value
                v_status.set("\n".join(lines))
                self._rebuild_table()
            b_apply.configure(command=apply)
            dlg._api = {"camera": v_cam, "device": v_dev, "apply": apply, "status": v_status}

        # ------------------------------------------------------------ stream settings in bulk
        def on_stream_settings(self):
            cams = self._ticked_cameras()
            LOG.info("Action: Stream Settings (%d verified channel(s) ticked)", len(cams))
            if not cams:
                messagebox.showinfo("Stream settings", "Tick at least one verified camera (green row) first.")
                return
            self._stream_dialog(cams)

        def _stream_dialog(self, cams):
            p = self.p
            targets = [{"dev": c["dev"], "creds": c["creds"], "channel": c["channel"],
                        "name": c["row"].get("Camera Name", ""), "multi": c["multi"]} for c in cams]
            dlg = tk.Toplevel(self)
            dlg.title(f"Stream settings - {APP_NAME}")
            dlg.configure(bg=p["bg"])
            dlg.transient(self)
            w = min(1120, self.winfo_screenwidth() - 60)
            h = min(780, self.winfo_screenheight() - 100)
            dlg.geometry(f"{w}x{h}+{self.winfo_x() + 30}+{self.winfo_y() + 20}")
            dlg.grab_set()
            ttk.Label(dlg, text="Stream settings", style="Title.TLabel").pack(anchor="w", padx=16, pady=(12, 0))
            ttk.Label(dlg, text=f"{len(targets)} camera channel(s) ticked. Tick the settings to change (typing a value "
                                "ticks it), click Preview, check the result, then Apply. Nothing is written before Apply.",
                      style="Sub.TLabel", wraplength=w - 60, justify="left").pack(anchor="w", padx=16)
            ttk.Label(dlg, text="\u26a0 Changing stream settings can interrupt live video and recording, and cameras that "
                                "are recorded by an NVR may be affected. Try one camera first.",
                      style="Sub.TLabel", wraplength=w - 60, justify="left").pack(anchor="w", padx=16, pady=(2, 8))

            nb = ttk.Notebook(dlg)
            nb.pack(fill="x", padx=16)
            vars_ = {}
            presets = {"Resolution": ["3840x2160", "2688x1520", "2560x1440", "1920x1080", "1280x720", "704x576",
                                      "640x480", "352x288"],
                       "Codec": ["H.264", "H.265", "MJPG"], "Bitrate Mode": ["CBR", "VBR"]}
            hints = {"Resolution": "width x height, e.g. 1920x1080", "FPS": "frames per second", "Bitrate (kbps)":
                     "e.g. 2048", "Codec": "", "Bitrate Mode": "", "GOP": "1 - 100"}
            for slot, title in (("Main", "Main stream"), ("Sub1", "Sub stream 1"), ("Sub2", "Sub stream 2"),
                                ("Sub3", "Sub stream 3")):
                tab = ttk.Frame(nb, style="Card.TFrame", padding=12)
                nb.add(tab, text=title)
                for r, field in enumerate(STREAM_FIELDS_API):
                    tv, vv = tk.BooleanVar(value=False), tk.StringVar()
                    TickBox(tab, "Change", tv, None, p).grid(row=r, column=0, sticky="w", padx=(0, 14), pady=3)
                    ttk.Label(tab, text=field, style="Card.TLabel", width=16).grid(row=r, column=1, sticky="w")
                    if field in presets:
                        widget = ttk.Combobox(tab, textvariable=vv, values=presets[field], width=22,
                                              state="readonly" if field == "Bitrate Mode" else "normal")
                    else:
                        widget = ttk.Entry(tab, textvariable=vv, width=24)
                    widget.grid(row=r, column=2, sticky="w", pady=3)
                    ttk.Label(tab, text=hints[field], style="Muted.TLabel").grid(row=r, column=3, sticky="w", padx=10)
                    vv.trace_add("write", lambda *_, tv=tv, vv=vv: tv.set(True) if vv.get().strip() else None)
                    vars_[(slot, field)] = (tv, vv)

            bar = ttk.Frame(dlg)
            bar.pack(fill="x", padx=16, pady=8)
            b_prev = ttk.Button(bar, text="Preview", style="Accent.TButton")
            b_apply = ttk.Button(bar, text="Apply", style="Accent.TButton", state="disabled")
            b_undo = ttk.Button(bar, text="Undo last change",
                                state="normal" if self.last_stream_change else "disabled")
            b_prev.pack(side="left")
            b_apply.pack(side="left", padx=8)
            b_undo.pack(side="left")
            ttk.Button(bar, text="Close", command=dlg.destroy).pack(side="right")
            v_status = tk.StringVar()
            ttk.Label(dlg, textvariable=v_status, style="Sub.TLabel", wraplength=w - 60, justify="left"
                      ).pack(anchor="w", padx=16)

            cols = [("Camera", "Camera", 250), ("Stream", "Stream", 70), ("Setting", "Setting", 120),
                    ("Current", "Current", 110), ("New", "New", 110), ("Result", "Result", 470)]
            wrap, tree = self._make_tree(dlg, cols, 8)
            wrap.pack(fill="both", expand=True, padx=16, pady=(6, 14))
            for tag, key in (("ok", "pend"), ("same", "pend"), ("bad", "bad"), ("done", "ok"),
                             ("adjusted", "pend"), ("fail", "bad")):
                tree.tag_configure(tag, background=p[key])
            plan = {"rows": []}
            all_buttons = (b_prev, b_apply, b_undo)

            def label(r):
                suffix = f" ch{r['channel']}" if any(t["multi"] and t["dev"].ip == r["ip"] for t in targets) else ""
                return f"{r['ip']}{suffix}  \u00b7  {r['name']}".strip(" \u00b7")

            def result_text(r):
                return {"ok": "ready to apply", "same": "already set - skipped", "done": "\u2713 applied and confirmed",
                        "adjusted": "\u26a0 " + r["detail"], "fail": "\u2717 " + r["detail"]}.get(r["status"], r["detail"])

            def fill(rows):
                tree.delete(*tree.get_children())
                for i, r in enumerate(rows):
                    tree.insert("", "end", iid=str(i), tags=(r["status"],),
                                values=[label(r), r["slot"], r["field"], r["old"], r["send"] or r["new"], result_text(r)])

            def busy(on):
                for b in all_buttons:
                    b.state(["disabled"] if on else ["!disabled"])
                if not on:
                    b_apply.state(["!disabled"] if any(r["status"] == "ok" for r in plan["rows"]) else ["disabled"])
                    b_undo.state(["!disabled"] if self.last_stream_change else ["disabled"])

            def gather():
                wanted = {}
                for (slot, field), (tv, vv) in vars_.items():
                    if tv.get():
                        value = vv.get().strip()
                        if not value:
                            raise ValueError(f"Enter a value for {slot} - {field} (or untick it).")
                        wanted.setdefault(slot, {})[field] = value
                if not wanted:
                    raise ValueError("Tick at least one setting to change.")
                return wanted

            def do_preview():
                try:
                    wanted = gather()
                except ValueError as e:
                    v_status.set(str(e))
                    return
                LOG.info("Action: Stream preview for %d channel(s): %s", len(targets), wanted)
                v_status.set("Reading the cameras' capabilities and current settings ...")
                busy(True)
                self._bg(dlg, lambda: preview_stream_changes(targets, wanted), on_preview)

            def on_preview(rows, err):
                if err:
                    plan["rows"] = []
                    v_status.set(f"Error: {err}")
                else:
                    plan["rows"] = rows
                    fill(rows)
                    n = lambda s: sum(r["status"] == s for r in rows)
                    v_status.set(f"{n('ok')} change(s) ready, {n('same')} already set, {n('bad')} not possible. "
                                 "Rows marked red cannot be applied - the reason is shown.")
                busy(False)

            def do_apply():
                rows = plan["rows"]
                n_ok = sum(r["status"] == "ok" for r in rows)
                n_cam = len({(r["ip"], r["channel"]) for r in rows if r["status"] == "ok"})
                if not n_ok or not messagebox.askyesno(
                        "Apply stream settings",
                        f"Apply {n_ok} change(s) to {n_cam} camera channel(s)?\n\nVideo and recording can be interrupted "
                        "briefly. The previous values are kept so you can undo.", parent=dlg):
                    return
                LOG.info("Action: Apply stream settings (%d change(s), %d channel(s))", n_ok, n_cam)
                v_status.set("Applying and checking ...")
                busy(True)

                def work():
                    undo = apply_stream_changes(targets, rows)
                    self._refresh_cameras([t["dev"] for t in targets])
                    return undo
                self._bg(dlg, work, on_applied)

            def on_applied(undo, err):
                if err:
                    v_status.set(f"Error: {err}")
                else:
                    self.last_stream_change = {"entries": undo, "targets": targets} if undo else None
                    fill(plan["rows"])
                    n = lambda s: sum(r["status"] == s for r in plan["rows"])
                    v_status.set(f"Done: {n('done')} confirmed, {n('adjusted')} adjusted by the camera, "
                                 f"{n('fail')} failed. The table in the main window was refreshed.")
                    for r in plan["rows"]:
                        if r["status"] == "ok":
                            r["status"] = "same"
                busy(False)

            def do_undo():
                last = self.last_stream_change
                if not last or not messagebox.askyesno(
                        "Undo", f"Restore the previous values of {len(last['entries'])} setting(s)?", parent=dlg):
                    return
                LOG.info("Action: Undo last stream change (%d value(s))", len(last["entries"]))
                v_status.set("Restoring the previous values ...")
                busy(True)

                def work():
                    res = undo_stream_changes(last["targets"], last["entries"])
                    self._refresh_cameras([t["dev"] for t in last["targets"]])
                    return res
                self._bg(dlg, work, on_undone)

            def on_undone(res, err):
                if err:
                    v_status.set(f"Error: {err}")
                else:
                    ok, bad = res
                    self.last_stream_change = None
                    plan["rows"] = []
                    tree.delete(*tree.get_children())
                    v_status.set(f"Restored {ok} value(s); {bad} could not be restored.")
                busy(False)
            b_prev.configure(command=do_preview)
            b_apply.configure(command=do_apply)
            b_undo.configure(command=do_undo)
            dlg._api = {"vars": vars_, "preview": do_preview, "apply": do_apply, "undo": do_undo, "plan": plan,
                        "status": v_status, "tree": tree}      # (used by the automatic tests)

        # ------------------------------------------------------------ shutdown
        def on_close(self):
            self.settings.update({"ports": self.v_ports.get(), "user": self.v_user.get(),
                                  "sync_tz": self.v_sync_tz.get(),
                                  "extra": self.v_extra.get(), "snap_dir": self.snap_dir,
                                  "visible": list(self.visible), "theme": "dark" if self.dark else "light"})
            save_settings(self.settings)
            LOG.info("%s closed", APP_NAME)
            self.destroy()

    App().mainloop()


# --------------------------------------------------------------------------- #
# CLI
# --------------------------------------------------------------------------- #
def run_cli(args):
    password = args.password or os.environ.get("DAHUA_PASSWORD") or getpass.getpass("Camera password: ")
    ports = parse_ports(args.ports)

    def cb(kind, *a):
        if kind == "log":
            print(a[0], flush=True)

    print(f"{APP_NAME} v{__version__}")
    adapters = [a for a in list_adapters() if args.include_virtual or not a.virtual]
    if args.adapter:
        adapters = [a for a in adapters if args.adapter.lower() in a.name.lower()]
    if args.targets:
        adapters = []
    for a in adapters:
        print("Adapter:", a.describe())
    host_map = build_scan_plan(adapters, args.targets or "")
    if not host_map:
        print("Nothing to scan - no active adapters (use --targets to give a range).")
        return 1
    scanned = [{"label": a.label, "range": a.scan_range} for a in adapters]
    if args.targets:
        scanned.append({"label": "Manual range", "range": args.targets})

    devices = scan_network(host_map, ports, cb)
    if not devices:
        print("No Dahua devices found.")
        return 1
    rows, excluded = fetch_all(devices, args.user, password, cb)
    out = args.out or f"HK_cameras_{datetime.now():%Y%m%d_%H%M}.xlsx"
    export_xlsx(rows, excluded, scanned, out)
    if args.snapshot_dir:
        by_ip = {d.ip: d for d in devices}
        count = Counter(r["IP Address"] for r in rows)
        targets = [{"dev": by_ip[r["IP Address"]], "creds": (args.user, password), "channel": int(r["Channel"]),
                    "name": r["Camera Name"], "serial": r["Serial Number"], "multi": count[r["IP Address"]] > 1,
                    "main_res": r["Main Resolution"]} for r in rows]
        ok, fail = take_snapshots(targets, args.snapshot_dir, cb)
        print(f"Snapshots: {ok} saved, {fail} failed -> {args.snapshot_dir}")
    print(f"\nExported {len({r['IP Address'] for r in rows})} Dahua IP camera(s); "
          f"{len(excluded)} other device(s) excluded -> {out}")
    return 0


def main():
    ap = argparse.ArgumentParser(description=f"{APP_NAME}: find Dahua IP cameras on this PC's network adapters and export their details to Excel.")
    ap.add_argument("--user", help="camera username (enables CLI mode)")
    ap.add_argument("--password", help="camera password (or env DAHUA_PASSWORD, or prompt)")
    ap.add_argument("--version", action="version", version=f"{APP_NAME} {__version__}")
    ap.add_argument("--list-adapters", action="store_true", help="show this PC's network adapters and exit")
    ap.add_argument("--adapter", help="only scan adapters whose name contains this text")
    ap.add_argument("--include-virtual", action="store_true", help="also scan virtual/VPN adapters")
    ap.add_argument("--targets", help="scan ONLY these ranges instead of the adapters, e.g. 192.168.1.0/24,10.0.0.5")
    ap.add_argument("--ports", default=DEFAULT_PORTS)
    ap.add_argument("--out", help="output .xlsx path")
    ap.add_argument("--snapshot-dir", help="also save a main-stream snapshot of every camera to this folder")
    ap.add_argument("--debug-http", action="store_true", help="log every request sent to a camera")
    args = ap.parse_args()
    history = tail_log(120)
    setup_logging()
    set_http_trace(args.debug_http)
    if args.list_adapters:
        for a in list_adapters():
            print(a.describe())
        return
    if args.user:
        sys.exit(run_cli(args))
    run_gui(history)


if __name__ == "__main__":
    main()
