HK's IP Camera Settings  v1.6.2  (64-bit, portable)
Start: double-click HK_IP_Camera_Settings.exe  (Windows 10/11, 64-bit).
Logs and settings are stored in the "data" folder beside the program because portable.txt is present.
Windows SmartScreen may warn while the program is unsigned: More info -> Run anyway.
